SECTION 4 V2 - FINAL COLLECTIVE-CATALOGUE FIX
=============================================

This version changes only the Section-3 UPO input selection.

The previous clean Section-4 script read N=2,4,6,8 from
N*/selected_independent_upos.csv and used the final collective catalogue only
for N=10.  The corrected Section-3 V2 audit showed that this is not safe:
microscopically distinct selected UPOs can collapse to the same collective
family (observed for N=2).

This V2 script therefore reads, for EVERY N=2,4,6,8,10:
  COLLECTIVE_COMPLETION/N{N}_SEARCH/N{N}_collective_representatives.csv

It requires exactly four final collective representatives per N and otherwise
keeps the same manuscript protocol:
  24 near trajectories; 48 matched controls; 20T; 60 points/T;
  360 phase points; perturbation 1e-4; 2000 bootstrap resamples;
  raw one-sided Mann-Whitney p < 0.05 as the final significance criterion.
