#!/usr/bin/env python3
"""
Final per-N Section 6.1 production pipeline for the central-bias (epsilon=1) robustness test.

Design goals:
  * same energy density and N={2,4,6,8,10} as the epsilon=0 reference study;
  * central bias epsilon=1, environment remains homogeneous Ei=0;
  * exact collective reduction is preserved and audited;
  * parity P/PT are NOT used because central bias breaks them;
  * search stops only after four genuinely distinct COLLECTIVE UPO families are
    found and each is hyperbolic in the fixed invariant sector (rho>1.05);
  * no localization metric enters orbit selection;
  * expensive standard metrics are checkpointed per UPO;
  * fixed-sector FTLE is computed with 24 samples per UPO and convergence values
    at t=60,120,180 in the same integrations;
  * final DONE marker is written only after structural, numerical, invariant,
    independence, Floquet, sample-count and hypothesis-test audits all pass.
"""

import argparse
import csv
import hashlib
import importlib.util
import json
import math
import os
import signal
import sys
import time
import traceback
from pathlib import Path

import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import minimize_scalar


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, str(Path(path).resolve()))
    if spec is None or spec.loader is None:
        raise ImportError(path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def ensure(p):
    Path(p).mkdir(parents=True, exist_ok=True)


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_csv(path, rows, fields=None):
    path = Path(path)
    ensure(path.parent)
    if fields is None:
        fields = []
        for r in rows:
            for k in r:
                if k not in fields:
                    fields.append(k)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader(); w.writerows(rows)
    os.replace(tmp, path)


def jdump(path, obj):
    def san(x):
        if isinstance(x, dict): return {str(k): san(v) for k, v in x.items()}
        if isinstance(x, (list, tuple)): return [san(v) for v in x]
        if isinstance(x, np.ndarray): return san(x.tolist())
        if isinstance(x, np.generic): return san(x.item())
        if isinstance(x, float) and not np.isfinite(x): return None
        return x
    path = Path(path); ensure(path.parent)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(san(obj), f, indent=2, allow_nan=False)
    os.replace(tmp, path)


def fsha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()


def as_float(x, default=np.nan):
    try:
        y = float(x)
        return y if np.isfinite(y) else default
    except Exception:
        return default


# ---------------------------------------------------------------------------
# Reduced collective dynamics and fixed-sector Floquet
# ---------------------------------------------------------------------------

def cross_matrix(a):
    ax, ay, az = map(float, a)
    return np.array([[0., -az, ay], [az, 0., -ax], [-ay, ax, 0.]], float)


def reduced_rhs(core, t, y):
    r = np.asarray(y[:3], float)
    S = np.asarray(y[3:6], float)
    B0 = np.array([-2.*core.delta, 0., 2.*core.epsilon + core.Lambda*S[2]])
    Be = np.array([-2.*core.Di, 0., 2.*core.Ei + core.Lambda*r[2]])
    return np.concatenate([np.cross(B0, r), np.cross(Be, S)])


def reduced_jacobian(core, y):
    r = np.asarray(y[:3], float)
    S = np.asarray(y[3:6], float)
    B0 = np.array([-2.*core.delta, 0., 2.*core.epsilon + core.Lambda*S[2]])
    Be = np.array([-2.*core.Di, 0., 2.*core.Ei + core.Lambda*r[2]])
    ez = np.array([0., 0., 1.])
    J = np.zeros((6,6), float)
    J[:3,:3] = cross_matrix(B0)
    J[3:,3:] = cross_matrix(Be)
    J[:3,5] = core.Lambda*np.cross(ez, r)
    J[3:,2] = core.Lambda*np.cross(ez, S)
    return J


def tangent_pair(v):
    v = np.asarray(v, float)
    n = v/np.linalg.norm(v)
    axes = np.eye(3)
    a = axes[int(np.argmin(np.abs(axes@n)))]
    e1 = np.cross(n, a); e1 /= np.linalg.norm(e1)
    e2 = np.cross(n, e1); e2 /= np.linalg.norm(e2)
    return e1, e2


def collective_tangent_basis(r, S):
    e1,e2 = tangent_pair(r); f1,f2 = tangent_pair(S)
    B = np.zeros((6,4), float)
    B[:3,0]=e1; B[:3,1]=e2; B[3:,2]=f1; B[3:,3]=f2
    return B


def induced_symplectic_form(B, r, S):
    s = float(np.linalg.norm(S))
    Om = np.zeros((4,4), float)
    for i in range(4):
        ur, us = B[:3,i], B[3:,i]
        for j in range(4):
            vr, vs = B[:3,j], B[3:,j]
            Om[i,j] = -float(np.dot(r, np.cross(ur,vr))) \
                      -float(np.dot(S, np.cross(us,vs)))/max(s*s,1e-300)
    return Om


def reciprocal_pair_error(eigvals):
    a=np.abs(np.asarray(eigvals,complex)); a=a[np.isfinite(a)&(a>1e-300)]
    if len(a)<2:return np.nan
    logs=np.sort(np.log(a)); return float(np.max(np.abs(logs+logs[::-1])))


def fixed_sector_floquet(core, metrics, orbit, rtol=1.5e-11, atol=1.5e-13):
    R0=np.asarray(orbit["R0"],float); T=float(orbit["T"])
    r0=metrics.central_vector(core,R0); S0=metrics.env_collective(core,R0)
    sn=float(np.linalg.norm(S0))
    if sn<1e-9: raise RuntimeError("collective |S| too small")
    y0=np.concatenate([r0,S0]); Y0=np.concatenate([y0,np.eye(6).ravel()])
    def vrhs(t,Y):
        y=Y[:6]; M=Y[6:].reshape(6,6)
        return np.concatenate([reduced_rhs(core,t,y),(reduced_jacobian(core,y)@M).ravel()])
    sol=solve_ivp(vrhs,(0,T),Y0,method="DOP853",rtol=rtol,atol=atol)
    if not sol.success: raise RuntimeError(sol.message)
    yf=sol.y[:,-1]; yT=yf[:6]; M6=yf[6:].reshape(6,6)
    B=collective_tangent_basis(r0,S0); M4=B.T@M6@B
    eig=np.linalg.eigvals(M4)
    neutral_idx=np.argsort(np.abs(eig-1.0))[:2]
    active_idx=np.array([i for i in range(4) if i not in set(neutral_idx)],int)
    neutral=eig[neutral_idx]; active=eig[active_idx]
    rho=float(np.max(np.abs(active)))
    lam=0.0 if rho<=1+1e-7 else float(np.log(rho)/T)
    omega=2*np.pi/T
    pos=np.log(np.abs(active[np.abs(active)>1+1e-7]))/T
    lsum=float(np.sum(pos)) if len(pos) else 0.0
    Om=induced_symplectic_form(B,r0,S0)
    sym=float(np.linalg.norm(M4.T@Om@M4-Om,ord="fro")/max(np.linalg.norm(Om,ord="fro"),1e-300))
    return {
        "restricted_return_D":float(np.linalg.norm(yT-y0)),
        "restricted_rho":rho,
        "restricted_lambda":lam,
        "restricted_lambda_over_omega":float(lam/omega),
        "restricted_lambda_plus_sum":lsum,
        "restricted_heller_sum_over_2pi":float(lsum/omega),
        "restricted_det":float(np.linalg.det(M4)),
        "restricted_symplectic_error":sym,
        "restricted_reciprocal_pair_error":reciprocal_pair_error(eig),
        "restricted_n_positive":int(len(pos)),
        "restricted_hyperbolic_rho_gt_1p05":bool(rho>1.05),
        "restricted_neutral_pair_max_abs_mu_minus_1":float(np.max(np.abs(neutral-1))),
        "restricted_nonneutral_abs_json":json.dumps([float(abs(z)) for z in active]),
        "restricted_eigvals_json":json.dumps([[float(z.real),float(z.imag)] for z in eig]),
        "restricted_norm_error_central":float(abs(np.linalg.norm(yT[:3])-1.0)),
        "restricted_norm_error_collective":float(abs(np.linalg.norm(yT[3:])-sn)),
    }


def floquet_is_numerically_sound(rf):
    deterr=abs(math.log(max(abs(float(rf["restricted_det"])),1e-300)))
    return (float(rf["restricted_return_D"])<2e-5 and deterr<1e-2 and
            float(rf["restricted_symplectic_error"])<1e-2 and
            float(rf["restricted_reciprocal_pair_error"])<2e-3 and
            float(rf["restricted_norm_error_central"])<1e-7 and
            float(rf["restricted_norm_error_collective"])<1e-7)


# ---------------------------------------------------------------------------
# Collective equivalence: phase + T only (P/PT broken for epsilon=1)
# ---------------------------------------------------------------------------

SYMS=("I","T")

def collective_phase(core, metrics, orbit, points):
    tr=core.phase_grid(orbit,points)
    out=np.empty((len(tr),6),float)
    for k,R in enumerate(tr):
        out[k,:3]=metrics.central_vector(core,R); out[k,3:]=metrics.env_collective(core,R)
    return out


def apply_sym(A,sym):
    A=np.asarray(A,float).copy().reshape(-1,2,3)
    if sym=="T":
        A=A[::-1].copy(); A[:,:,1]*=-1
    elif sym!="I": raise ValueError(sym)
    return A.reshape(-1,6)


def periodic_interp(A,phases):
    A=np.asarray(A,float); P=len(A); x=(np.asarray(phases)%1.0)*P
    i0=np.floor(x).astype(int)%P; a=x-np.floor(x); i1=(i0+1)%P
    return (1-a)[:,None]*A[i0]+a[:,None]*A[i1]


def dist_shift(A,B,shift,snorm):
    P=len(A); Br=periodic_interp(B,np.arange(P)/P+shift)
    A2=A.copy(); B2=Br.copy(); A2[:,3:]/=max(snorm,1e-12); B2[:,3:]/=max(snorm,1e-12)
    d=A2-B2; blocks=d.reshape(P,2,3)
    return float(np.sqrt(np.mean(d*d))), float(np.max(np.linalg.norm(blocks,axis=2)))


def collective_alignment(core,metrics,a,b,points=720,period_rel_tol=2e-4,S_rel_tol=5e-5,
                         rms_tol=8e-4,max_tol=4e-3):
    Ta,Tb=float(a["T"]),float(b["T"]); relT=abs(Ta-Tb)/max(min(Ta,Tb),1e-12)
    sa=float(np.linalg.norm(metrics.env_collective(core,a["R0"]))); sb=float(np.linalg.norm(metrics.env_collective(core,b["R0"])))
    relS=abs(sa-sb)/max(sa,sb,1e-12)
    if relT>period_rel_tol or relS>S_rel_tol:
        return {"equivalent":False,"period_rel_diff":relT,"S_rel_diff":relS,"rms":np.nan,"max":np.nan,"phase_shift":np.nan,"symmetry":""}
    A=collective_phase(core,metrics,a,points); B0=collective_phase(core,metrics,b,points); s=.5*(sa+sb)
    best=(np.inf,np.inf,np.nan,"")
    for sym in SYMS:
        B=apply_sym(B0,sym); scores=[]
        for k in range(points):
            r,_=dist_shift(A,B,k/points,s); scores.append((r,k))
        _,k=min(scores); center=k/points; half=1.5/points
        res=minimize_scalar(lambda u:dist_shift(A,B,u,s)[0],bounds=(center-half,center+half),method="bounded",options={"xatol":2e-10})
        sh=float(res.x%1.0); rms,mx=dist_shift(A,B,sh,s)
        if rms<best[0]: best=(rms,mx,sh,sym)
    return {"equivalent":bool(best[0]<rms_tol and best[1]<max_tol),"period_rel_diff":relT,"S_rel_diff":relS,
            "rms":float(best[0]),"max":float(best[1]),"phase_shift":float(best[2]),"symmetry":best[3]}


def final_pair_audit(core,metrics,a,b):
    # Same-family copies must agree at BOTH resolutions; thresholds reproduce
    # the strengthened audit that caught the hidden collective near-duplicate.
    pre=collective_alignment(core,metrics,a,b,points=1080,period_rel_tol=1e-5,S_rel_tol=1e-5,rms_tol=5e-4,max_tol=3e-3)
    if not pre["equivalent"]:
        pre["equivalent_2160"]=False; return pre
    hi=collective_alignment(core,metrics,a,b,points=2160,period_rel_tol=1e-5,S_rel_tol=1e-5,rms_tol=5e-4,max_tol=3e-3)
    out=dict(pre); out.update({"equivalent":bool(pre["equivalent"] and hi["equivalent"]),
                              "equivalent_2160":bool(hi["equivalent"]),"rms_2160":hi["rms"],"max_2160":hi["max"],
                              "symmetry_2160":hi["symmetry"]})
    return out


def collapse_final(core,metrics,reps,outdir,prefix):
    n=len(reps); parent=list(range(n)); pairs=[]
    def find(i):
        while parent[i]!=i: parent[i]=parent[parent[i]]; i=parent[i]
        return i
    def union(a,b):
        a,b=find(a),find(b)
        if a!=b: parent[b]=a
    for i in range(n):
        for j in range(i+1,n):
            d=final_pair_audit(core,metrics,reps[i],reps[j]); pairs.append({"i":i,"j":j,**d})
            if d["equivalent"]: union(i,j)
    groups={}
    for i in range(n):groups.setdefault(find(i),[]).append(i)
    classes=list(groups.values())
    uniq=[]; rows=[]
    for cid,ids in enumerate(classes):
        # representative chosen only on numerical quality, never scar outcome
        rep=min(ids,key=lambda i:(reps[i].get("return_D",np.inf),reps[i].get("reciprocal_pair_error",np.inf)))
        uniq.append(reps[rep])
        for i in ids:
            rows.append({"class":cid,"member":i,"representative":i==rep,"T":reps[i]["T"],"source":reps[i].get("source","")})
    write_csv(Path(outdir)/f"{prefix}_pairs.csv",pairs); write_csv(Path(outdir)/f"{prefix}_classes.csv",rows)
    return uniq,classes


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------

def candidate_key(core,epoch,idx,c):
    if hasattr(core,"_candidate_hash"):
        return f"{epoch}:{idx}:{core._candidate_hash(c)}"
    A=np.asarray(c["A"],float); h=hashlib.sha1(np.concatenate([np.round(A,7),[round(float(c["T"]),6)]]).tobytes()).hexdigest()[:20]
    return f"{epoch}:{idx}:{h}"


def reorder_candidates(core,metrics,cands,reps):
    if not reps:return list(cands)
    repS=np.array([np.linalg.norm(metrics.env_collective(core,o["R0"])) for o in reps]); repT=np.array([o["T"] for o in reps])
    scored=[]
    for c in cands:
        try:
            R=core.A_to_bloch(c["A"]); s=np.linalg.norm(metrics.env_collective(core,R)); t=float(c["T"]); D=max(float(c.get("D",1)),1e-14)
            dS=float(np.min(np.abs(repS-s))/max(core.N,1)); dT=float(np.min(np.abs(repT-t)/np.maximum(repT,1e-9)))
            score=math.log10(D)-0.45*min(dS,.5)-0.20*min(dT,1.)
        except Exception:score=1e9
        scored.append((score,c))
    scored.sort(key=lambda x:x[0]); return [c for _,c in scored]


def search_four(core,metrics,N,target,ndir,args):
    search=Path(ndir)/"SEARCH"; ensure(search)
    pool=search/"collective_representatives.csv"; proc=search/"processed_candidates.csv"; state=search/"search_state.json"
    reps=core.load_orbits(pool) if pool.exists() else []
    cfg=core.config_for_n(N,quick=False,required_upos=20)
    # More generous period ceiling for the biased model; this costs only when a
    # long recurrence is actually present.
    cfg["T_MAX"]={2:320.,4:420.,6:520.,8:620.,10:720.}[N]
    # Revalidate checkpointed reps and fixed-sector stability.
    kept=[]
    for o in reps:
        v=core.validate_orbit(o,target,cfg)
        if v is None:continue
        try:
            rf=fixed_sector_floquet(core,metrics,v)
            if rf["restricted_rho"]>args.restricted_rho_min and floquet_is_numerically_sound(rf): kept.append(v)
        except Exception:pass
    reps=kept
    if reps:
        reps,_=collapse_final(core,metrics,reps,search,"resume_highres_audit")
    core.save_orbits(pool,reps)
    processed_rows=read_csv(proc) if proc.exists() else []; processed={r.get("candidate_key","") for r in processed_rows}
    epoch=0
    if state.exists():
        try:epoch=int(json.load(open(state))["epoch"])
        except Exception:epoch=0
    t0=time.perf_counter(); budget=args.search_budget_hours*3600.
    while True:
        # High-resolution acceptance gate. If four are found but two collapse,
        # continue automatically rather than finishing with a hidden duplicate.
        if len(reps)>=4:
            uniq,classes=collapse_final(core,metrics,reps,search,"FINAL_DOUBLE_RESOLUTION_AUDIT")
            reps=uniq; core.save_orbits(pool,reps)
            if len(reps)>=4:
                reps=reps[:4]
                # Final independent Floquet revalidation at production tolerances.
                okay=True
                for o in reps:
                    rf=fixed_sector_floquet(core,metrics,o)
                    if rf["restricted_rho"]<=args.restricted_rho_min or not floquet_is_numerically_sound(rf): okay=False; break
                if okay:
                    core.save_orbits(pool,reps); jdump(search/"SEARCH_COMPLETE.json",{"N":N,"n":4,"periods":[float(o["T"]) for o in reps]})
                    return reps,cfg
                # Extremely unlikely numerical failure: remove offending reps and continue.
                reps=[o for o in reps if (lambda rf:rf["restricted_rho"]>args.restricted_rho_min and floquet_is_numerically_sound(rf))(fixed_sector_floquet(core,metrics,o))]
                core.save_orbits(pool,reps)
        if time.perf_counter()-t0>budget:
            core.save_orbits(pool,reps); jdump(search/"SEARCH_NEEDS_RESUME.json",{"N":N,"epoch":epoch,"families":len(reps),"target":4})
            raise RuntimeError("SEARCH_BUDGET_REACHED_SAFE_RESUME")
        print("\n"+"="*92,flush=True); print(f"EPS1 N={N} SEARCH EPOCH {epoch}: {len(reps)}/4 final collective hyperbolic families",flush=True); print("="*92,flush=True)
        cands=reorder_candidates(core,metrics,core._generate_epoch_candidates(cfg,target,search,epoch,args.seed+10000*N),reps)
        for ci,c in enumerate(cands):
            key=candidate_key(core,epoch,ci,c)
            if key in processed:continue
            if time.perf_counter()-t0>budget:
                core.save_orbits(pool,reps); jdump(state,{"epoch":epoch}); jdump(search/"SEARCH_NEEDS_RESUME.json",{"N":N,"epoch":epoch,"candidate":ci,"families":len(reps)})
                raise RuntimeError("SEARCH_BUDGET_REACHED_SAFE_RESUME")
            print(f"N={N} candidate {ci+1}/{len(cands)} D0={float(c.get('D',np.nan)):.3e} T0={float(c.get('T',np.nan)):.6f}",flush=True)
            o,status=core._refine_candidate_final(c,cfg,target)
            row={"candidate_key":key,"epoch":epoch,"candidate_index":ci,"D0":c.get("D",np.nan),"T0":c.get("T",np.nan),"refine_status":status}
            if o is None:
                row["decision"]="reject_refinement_or_validation"
            else:
                row.update({"T":o["T"],"return_D":o["return_D"],"rho_full":o["rho"]})
                try:
                    rf=fixed_sector_floquet(core,metrics,o); row.update(rf)
                    if rf["restricted_rho"]<=args.restricted_rho_min:row["decision"]="reject_not_fixed_sector_hyperbolic"
                    elif not floquet_is_numerically_sound(rf):row["decision"]="reject_fixed_sector_numerical_audit"
                    else:
                        dup=None
                        for j,q in enumerate(reps):
                            al=collective_alignment(core,metrics,q,o,points=720)
                            if al["equivalent"]:dup=(j,al);break
                        if dup:
                            row["decision"]="reject_existing_collective_family"; row["duplicate_of"]=dup[0]; row["equiv_rms"]=dup[1]["rms"]; row["equiv_max"]=dup[1]["max"]
                        else:
                            oo=dict(o); oo["source"]=f"eps1_N{N}_epoch{epoch}_candidate{ci}"; reps.append(oo); core.save_orbits(pool,reps)
                            row["decision"]="ACCEPT_NEW_COLLECTIVE_FAMILY"; row["new_count"]=len(reps)
                            print(f"*** ACCEPTED #{len(reps)}: T={o['T']:.10f}, rho_full={o['rho']:.6g}, rho_sec={rf['restricted_rho']:.6g}, chi_sec={rf['restricted_lambda_over_omega']:.6g}",flush=True)
                except Exception as exc:
                    row["decision"]="reject_fixed_sector_error"; row["error"]=f"{type(exc).__name__}: {exc}"
            processed_rows.append(row); processed.add(key); write_csv(proc,processed_rows)
            if len(reps)>=4:break
        epoch+=1; jdump(state,{"epoch":epoch})


# ---------------------------------------------------------------------------
# Fixed-sector FTLE with in-run convergence
# ---------------------------------------------------------------------------

def project_tangent_energy(core,y,v):
    y=np.asarray(y,float); v=np.asarray(v,float).copy(); r,S=y[:3],y[3:]
    v[:3]-=np.dot(v[:3],r)/max(np.dot(r,r),1e-300)*r
    v[3:]-=np.dot(v[3:],S)/max(np.dot(S,S),1e-300)*S
    g=np.array([-2*core.delta,0.,2*core.epsilon+core.Lambda*S[2],-2*core.Di,0.,2*core.Ei+core.Lambda*r[2]],float)
    g[:3]-=np.dot(g[:3],r)/max(np.dot(r,r),1e-300)*r
    g[3:]-=np.dot(g[3:],S)/max(np.dot(S,S),1e-300)*S
    gg=np.dot(g,g)
    if gg>1e-20:v-=np.dot(v,g)/gg*g
    return v


def one_sector_ftle(core,y0,rng,total=180.,dt=2.):
    y=np.asarray(y0,float).copy(); v=project_tangent_energy(core,y,rng.normal(size=6)); v/=np.linalg.norm(v)
    acc=0.; t=0.; checkpoints={60.:None,120.:None,180.:None}
    while t<total-1e-12:
        h=min(dt,total-t)
        def rhs(tt,Y):
            yy=Y[:6]; vv=Y[6:]
            return np.concatenate([reduced_rhs(core,tt,yy),reduced_jacobian(core,yy)@vv])
        sol=solve_ivp(rhs,(t,t+h),np.concatenate([y,v]),method="DOP853",rtol=3e-9,atol=2e-11)
        if not sol.success:raise RuntimeError(sol.message)
        y=sol.y[:6,-1]; v=project_tangent_energy(core,y,sol.y[6:,-1]); n=np.linalg.norm(v)
        if not np.isfinite(n) or n<1e-300:raise RuntimeError("degenerate FTLE tangent")
        acc+=math.log(n); v/=n; t+=h
        for cp in list(checkpoints):
            if checkpoints[cp] is None and t>=cp-1e-9:checkpoints[cp]=acc/t
    return {"ftle_60":float(checkpoints[60.]),"ftle_120":float(checkpoints[120.]),"ftle_180":float(checkpoints[180.])}


def sector_ftle_bundle(core,metrics,orbit,target,outdir,rng,nsamples):
    path=Path(outdir)/"fixed_sector_ftle_samples.csv"; rows=read_csv(path) if path.exists() else []; done={int(r["sample"]) for r in rows}
    for i in range(nsamples):
        if i in done:continue
        R=metrics.sample_microcanonical_sector_state(core,orbit["R0"],target,rng)
        y=np.concatenate([metrics.central_vector(core,R),metrics.env_collective(core,R)])
        vals=one_sector_ftle(core,y,rng)
        rows.append({"sample":i,"energy":core.energy_bloch(R),**vals}); write_csv(path,rows)
        print(f"    sector FTLE {i+1}/{nsamples}: lambda180={vals['ftle_180']:+.6e}",flush=True)
    if len(rows)<nsamples:raise RuntimeError("incomplete sector FTLE samples")
    rows=sorted(rows,key=lambda r:int(r["sample"]))[:nsamples]
    out={"sector_ftle_n":nsamples}
    for cp in (60,120,180):
        v=np.array([float(r[f"ftle_{cp}"]) for r in rows])
        out.update({f"sector_ftle_mean_{cp}":float(np.mean(v)),f"sector_ftle_median_{cp}":float(np.median(v)),f"sector_ftle_std_{cp}":float(np.std(v,ddof=1))})
    den=max(abs(out["sector_ftle_median_180"]),1e-12)
    out["sector_ftle_median_relchange_120_to_180"]=float(abs(out["sector_ftle_median_180"]-out["sector_ftle_median_120"])/den)
    out["sector_ftle_positive_fraction_180"]=float(np.mean([float(r["ftle_180"])>0 for r in rows]))
    return out


# ---------------------------------------------------------------------------
# Preflight numerical self-tests
# ---------------------------------------------------------------------------

def finite_diff_jac(fun,x,J,h=2e-7):
    x=np.asarray(x,float); num=np.zeros_like(J)
    for j in range(len(x)):
        xp=x.copy(); xm=x.copy(); xp[j]+=h; xm[j]-=h
        num[:,j]=(fun(xp)-fun(xm))/(2*h)
    return float(np.max(np.abs(num-J))), float(np.linalg.norm(num-J)/max(np.linalg.norm(num),1e-12))


def preflight(core,metrics,N,target,ndir,seed):
    out=Path(ndir)/"PREFLIGHT.json"
    if out.exists():
        data=json.load(open(out));
        if data.get("PASS"):return data
    core.set_model(N); rng=np.random.default_rng(seed+N*919)
    if abs(core.epsilon-1.0)>1e-14 or abs(core.Ei)>1e-14:raise RuntimeError("wrong model parameters")
    emin,emax,zstar=core.classical_energy_bounds(N)
    if not (emin<target<emax):raise RuntimeError(f"target energy outside bounds {emin},{emax}")
    # Exact sampler audit.
    eerr=[]; normerr=[]
    states=[]
    for _ in range(60):
        A=core.random_same_energy_A(rng,target); R=core.A_to_bloch(A); states.append(R)
        eerr.append(abs(core.energy_bloch(R)-target)); rr=R.reshape(core.M,3); normerr.append(float(np.max(np.abs(np.linalg.norm(rr,axis=1)-1))))
    # Exact fixed-sector sampler/control audit (common SO(3) environment rotation).
    sector_energy_err=[]; sector_inv_err=[]
    base=states[0]
    for _ in range(20):
        Rc=metrics.sample_microcanonical_sector_state(core,base,target,rng,max_attempts=5000)
        sector_energy_err.append(abs(core.energy_bloch(Rc)-target))
        dd=metrics.invariant_difference(core,base,Rc)
        sector_inv_err.append(max(dd["gram_max_abs_diff"],dd["triple_max_abs_diff"],dd["S_norm_abs_diff"]))
    Rnear=metrics.make_near_same_sector(core,base,target,rng,1e-4)
    ddn=metrics.invariant_difference(core,base,Rnear)
    near_sector_error=max(abs(core.energy_bloch(Rnear)-target),ddn["gram_max_abs_diff"],ddn["triple_max_abs_diff"],ddn["S_norm_abs_diff"])
    # Full Jacobian finite-difference audit.
    R=states[0]; jabs,jrel=finite_diff_jac(lambda q:core.bloch_rhs(0,q),R,core.bloch_jacobian(R))
    # Reduced Jacobian finite-difference audit.
    y=np.concatenate([metrics.central_vector(core,R),metrics.env_collective(core,R)])
    rabs,rrel=finite_diff_jac(lambda q:reduced_rhs(core,0,q),y,reduced_jacobian(core,y))
    # Active symmetry + explicitly broken P/PT audit.
    symerr=core.validate_exact_symmetries(ndir,np.random.default_rng(seed+N*991),ntrials=12)
    # Dynamic collective/invariant audit over multiple states.
    ed=[]; gd=[]; rd=[]
    for R0 in states[:4]:
        tt,tr=core.integrate_grid(R0,8.,161,rtol=2e-10,atol=2e-12)
        drift,_,_=core.energy_drift(tr); inv=metrics.invariant_drift(core,tr); red=metrics.collective_reduction_audit(core,R0,tt,tr)
        ed.append(drift); gd.append(max(inv["gram_drift"],inv["triple_drift"],inv["S_norm_drift"],inv["collective_rhs_residual"],inv["collective_energy_residual"]))
        rd.append(red["collective_reduction_max_error"])
    data={"PASS":True,"N":N,"epsilon":core.epsilon,"target_energy":target,"energy_density":target/(N+1),"Emin":emin,"Emax":emax,
          "target_xi":(target-emin)/(emax-emin),"max_sampler_energy_error":max(eerr),"max_norm_error":max(normerr),
          "max_fixed_sector_sampler_energy_error":max(sector_energy_err),"max_fixed_sector_invariant_error":max(sector_inv_err),"near_fixed_sector_error":near_sector_error,
          "full_jacobian_max_abs_error":jabs,"full_jacobian_rel_error":jrel,"reduced_jacobian_max_abs_error":rabs,"reduced_jacobian_rel_error":rrel,
          "active_symmetry_worst_error":symerr,"max_energy_drift_short":max(ed),"max_invariant_or_collective_residual_short":max(gd),"max_collective_reduction_error_short":max(rd)}
    limits={"sampler_energy":1e-8,"norm":1e-10,"jac_abs":2e-5,"jac_rel":2e-5,"sym":5e-10,"energy_drift":2e-7,"invariant":2e-7,"reduction":5e-8}
    bad=[]
    if data["max_sampler_energy_error"]>limits["sampler_energy"]:bad.append("sampler_energy")
    if data["max_norm_error"]>limits["norm"]:bad.append("norm")
    if data["max_fixed_sector_sampler_energy_error"]>1e-8 or data["max_fixed_sector_invariant_error"]>1e-8 or data["near_fixed_sector_error"]>1e-8:bad.append("fixed_sector_sampler")
    if jabs>limits["jac_abs"] or jrel>limits["jac_rel"]:bad.append("full_jacobian")
    if rabs>limits["jac_abs"] or rrel>limits["jac_rel"]:bad.append("reduced_jacobian")
    if symerr>limits["sym"]:bad.append("symmetry")
    if max(ed)>limits["energy_drift"]:bad.append("energy_drift")
    if max(gd)>limits["invariant"]:bad.append("invariants")
    if max(rd)>limits["reduction"]:bad.append("collective_reduction")
    data["limits"]=limits; data["failed_checks"]=bad; data["PASS"]=not bad; jdump(out,data)
    if bad:raise RuntimeError(f"preflight failed: {bad}")
    return data


# ---------------------------------------------------------------------------
# Production per-N driver
# ---------------------------------------------------------------------------

def metrics_args():
    class A:pass
    a=A(); a.near=24; a.controls=48; a.periods=20; a.ppp=60; a.phase_points=360; a.renyi_stride=6
    a.reference_points=1800; a.renyi_reference_sizes=[600,1200,1800]; a.renyi_convergence_reps=5
    a.near_amplitude=1e-4; a.control_max_tube=.20; a.bootstrap=2000; a.collective_phase_points=1080; a.quick=False
    return a


def validate_finished_N(core,metrics,N,ndir,reps,summary_rows,args):
    problems=[]
    if len(reps)!=4:problems.append(f"representative_count={len(reps)}")
    uniq,classes=collapse_final(core,metrics,reps,Path(ndir)/"FINAL_VALIDATION","INDEPENDENCE_1080_2160")
    if len(uniq)!=4 or any(len(c)!=1 for c in classes):problems.append(f"collective_classes={classes}")
    if len(summary_rows)!=4:problems.append(f"summary_count={len(summary_rows)}")
    for oid,o in enumerate(reps):
        rf=fixed_sector_floquet(core,metrics,o)
        if rf["restricted_rho"]<=args.restricted_rho_min:problems.append(f"UPO{oid}_not_sector_hyperbolic")
        if not floquet_is_numerically_sound(rf):problems.append(f"UPO{oid}_floquet_numerics")
        ud=Path(ndir)/"STANDARD_METRICS"/f"UPO{oid}"
        tests=read_csv(ud/"hypothesis_tests_raw.csv") if (ud/"hypothesis_tests_raw.csv").exists() else []
        prim=[r for r in tests if r.get("family")=="primary"]
        if len(prim)!=10:problems.append(f"UPO{oid}_primary_tests={len(prim)}")
        ft=read_csv(Path(ndir)/"FIXED_SECTOR_FTLE"/f"UPO{oid}"/"fixed_sector_ftle_samples.csv")
        if len(ft)<args.sector_ftle_samples:problems.append(f"UPO{oid}_sector_ftle={len(ft)}")
        ic=read_csv(ud/"initial_conditions_and_invariant_match.csv") if (ud/"initial_conditions_and_invariant_match.csv").exists() else []
        if len(ic)!=(24+48):problems.append(f"UPO{oid}_initial_conditions={len(ic)}")
        # Strong invariant/energy audit on generated near/control initial states.
        for r in ic:
            for k,tol in [("energy_abs_diff",5e-8),("gram_max_abs_diff",5e-8),("triple_max_abs_diff",5e-8),("S_norm_abs_diff",5e-8)]:
                if k in r and np.isfinite(as_float(r[k])) and abs(as_float(r[k]))>tol:problems.append(f"UPO{oid}_{k}_bad"); break
    return problems


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",required=True); ap.add_argument("--core",required=True); ap.add_argument("--metrics",required=True)
    ap.add_argument("--N",type=int,required=True,choices=[2,4,6,8,10]); ap.add_argument("--search-budget-hours",type=float,default=118.)
    ap.add_argument("--restricted-rho-min",type=float,default=1.05); ap.add_argument("--sector-ftle-samples",type=int,default=24)
    ap.add_argument("--seed",type=int,default=20261001)
    args=ap.parse_args()
    root=Path(args.root).resolve(); ndir=root/f"N{args.N}"; ensure(ndir)
    done=ndir/"DONE.json"
    core=load_module("eps1_core",args.core); metrics=load_module("eps1_metrics",args.metrics); core.set_model(args.N)
    if done.exists():
        print(f"N={args.N} already COMPLETE: {done}",flush=True); return 0
    target=core.target_energy_for_n(args.N)
    jdump(ndir/"RUN_CONFIG.json",{"N":args.N,"epsilon":core.epsilon,"Ei":core.Ei,"delta":core.delta,"Di":core.Di,"Lambda":core.Lambda,
          "target_energy":target,"energy_density":target/(args.N+1),"core_sha256":fsha(args.core),"metrics_sha256":fsha(args.metrics),
          "search_budget_hours":args.search_budget_hours,"restricted_rho_min":args.restricted_rho_min,"sector_ftle_samples":args.sector_ftle_samples,"seed":args.seed})
    def sig(signum,frame):
        jdump(ndir/"INTERRUPTED.json",{"signal":signum,"time":time.time()}); raise KeyboardInterrupt
    signal.signal(signal.SIGTERM,sig); signal.signal(signal.SIGINT,sig)
    try:
        print("\n"+"#"*96,flush=True); print(f"EPSILON=1 PRODUCTION DATASET N={args.N}",flush=True); print("#"*96,flush=True)
        preflight(core,metrics,args.N,target,ndir,args.seed)
        cfg=core.config_for_n(args.N,quick=False,required_upos=20)
        # broad full-state shell chaos: complementary diagnostic, not fixed-sector proof
        core.stage_chaos(cfg,target,ndir,np.random.default_rng(args.seed+1000*args.N))
        reps,cfg=search_four(core,metrics,args.N,target,ndir,args)
        # Canonical files expected by standard-metrics ecosystem.
        core.save_orbits(ndir/"selected_independent_upos.csv",reps); core.save_orbits(ndir/"independent_clear_upos.csv",reps)
        # Fixed-sector Floquet table.
        frows=[]
        for oid,o in enumerate(reps):
            rf=fixed_sector_floquet(core,metrics,o); fp=metrics.invariant_fingerprint(core,o["R0"])
            frows.append({"N":args.N,"orbit":oid,"T":o["T"],"rho_full":o["rho"],**fp,**rf})
        write_csv(ndir/"FIXED_SECTOR_FLOQUET_4.csv",frows)
        # Standard metrics + independent fixed-sector FTLE.
        ma=metrics_args(); stdroot=ndir/"STANDARD_METRICS"; ensure(stdroot); summaries=[]
        for oid,o in enumerate(reps):
            print("\n"+"-"*92,flush=True); print(f"N={args.N} UPO{oid}: COMPLETE STANDARD METRICS + FIXED-SECTOR FTLE",flush=True); print("-"*92,flush=True)
            rng=np.random.default_rng(args.seed+100000*args.N+oid)
            # Because the selected set is already final-collective-independent, class id = orbit id.
            sm=metrics.analyze_upo(core,args.N,oid,o,target,stdroot,ma,rng,oid)
            ft=sector_ftle_bundle(core,metrics,o,target,ndir/"FIXED_SECTOR_FTLE"/f"UPO{oid}",np.random.default_rng(args.seed+700000*args.N+oid),args.sector_ftle_samples)
            row=dict(sm); row.update({k:v for k,v in frows[oid].items() if k not in row}); row.update(ft); summaries.append(row)
            write_csv(ndir/"EPS1_UPO_SUMMARIES_PARTIAL.csv",summaries)
        write_csv(ndir/"EPS1_UPO_SUMMARIES.csv",summaries)
        problems=validate_finished_N(core,metrics,args.N,ndir,reps,summaries,args)
        validation={"N":args.N,"PASS":not problems,"problems":problems,"n_upos":len(reps),"n_summaries":len(summaries),
                    "periods":[float(o["T"]) for o in reps],"restricted_rhos":[float(r["restricted_rho"]) for r in frows]}
        jdump(ndir/"FINAL_N_VALIDATION.json",validation)
        if problems:raise RuntimeError("final N validation failed: "+"; ".join(problems))
        jdump(done,{"status":"COMPLETE","N":args.N,"epsilon":1.0,"completed":time.time(),"n_collective_families":4,"validation":"PASS"})
        if (ndir/"INTERRUPTED.json").exists():(ndir/"INTERRUPTED.json").unlink()
        print(f"\nN={args.N} EPSILON=1 COMPLETE AND FULLY VALIDATED",flush=True); return 0
    except RuntimeError as exc:
        if "SEARCH_BUDGET_REACHED_SAFE_RESUME" in str(exc):
            jdump(ndir/"NEEDS_RESUME.json",{"N":args.N,"message":str(exc),"instruction":"re-submit identical task; checkpoints prevent recalculation"})
            print("SAFE RESUME REQUIRED; no completed work will be repeated",flush=True); return 75
        jdump(ndir/"FATAL_ERROR.json",{"type":type(exc).__name__,"message":str(exc),"traceback":traceback.format_exc()}); raise
    except Exception as exc:
        jdump(ndir/"FATAL_ERROR.json",{"type":type(exc).__name__,"message":str(exc),"traceback":traceback.format_exc()}); raise

if __name__=="__main__":
    raise SystemExit(main())
