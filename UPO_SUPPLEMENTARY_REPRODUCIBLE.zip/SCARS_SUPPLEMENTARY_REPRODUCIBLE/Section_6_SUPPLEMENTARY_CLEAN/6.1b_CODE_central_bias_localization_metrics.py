#!/usr/bin/env python3
"""
scar_final_standard_metrics.py
==============================
FINAL literature-aligned diagnostics for the already-computed nonlinear-TLS
UPO/scarring dataset N=2,4,6,8,10.

This script is an ADD-ON: it imports the validated core model/search code and
reuses ARTICLE_EPS1_N246810/N*/selected_independent_upos.csv. It does not redo
UPO searches or stationary-state enumeration.

WHY THIS SCRIPT EXISTS
----------------------
The core pipeline establishes chaotic same-energy shells, exact-symmetry-
inequivalent hyperbolic UPOs, canonical Floquet validation, and custom C/R
phase-memory diagnostics. This add-on adds the observables most directly
comparable with the UPO/quantum-scar literature while respecting a crucial
feature of this specific model: the identical environment TLSs have exact
constants of motion that partition a fixed-energy shell into dynamically
inaccessible sectors.

For central epsilon=1, E_i=0, delta=D_i=Lambda_i=1, all environmental Bloch vectors still obey

    rdot_i = B(Z) x r_i,       B(Z)=(-2,0,Z),

so every pairwise dot product r_i.r_j and every oriented triple product
r_i.(r_j x r_k) is conserved. The whole environment is a rigid configuration
under one common SO(3) rotation. Its collective vector S=sum_i r_i obeys the
same precession equation, and the backreaction on the central TLS depends only
on S_z. Therefore the full central+environment dynamics reduces exactly to
central r_0 plus collective S, with |S| fixed. N changes the set of available
collective sectors and the microscopic product-state geometry, but it does NOT
simply add active classical dynamical degrees of freedom. The script audits and
reports this explicitly so the manuscript cannot overclaim a dimensionality
scaling that the equations do not support.

LITERATURE-ALIGNED METRICS
--------------------------
A. Chaotic/UPO backbone
   * same-shell FTLE (read from core dataset)
   * complete Floquet multipliers
   * lambda_max/omega = lambda_max*T/(2*pi) (Heller-style criterion)
   * sum of positive Floquet exponents Lambda_+
   * Lambda_+*T/(2*pi), number of unstable directions, reciprocal-pair audit

B. Tube/Husimi UPO projection
   * exact product-state Husimi overlap for pure TLS product states
       Q(R,R') = prod_k [1+r_k.r'_k]/2
   * phase-averaged tube projection Q_O(t)
   * time-averaged scar measure relative to an invariant-matched delocalized
     control ensemble, analogous to the standard periodic-orbit tube measure
   * phase-max tube overlap retained as a secondary diagnostic

C. Dynamical return / revivals
   * product-state return fidelity F(t)=Q(R(t),R(0))
   * revival peak heights around nT, n=1..20
   * peak timing offsets (t_peak-nT)/T
   * revival contrast over off-period background
   * Fourier weight at 1/T and first harmonics, for F(t), Q_O(t), and Z(t)

D. Phase-space localization
   * microcanonical invariant-sector Renyi occupations L_1, L_2, L_4
   * IPR-equivalent 1/L_2
   * explicit reference-size convergence at multiple reference sizes and
     multiple random subsets, with convergence flags

E. Controls / statistics
   * controls preserve the full environmental configuration by a common Haar
     SO(3) rotation, hence Gram matrix AND handedness, and satisfy the exact
     target energy by solving the central-spin energy circle
   * near-UPO states are generated in the same exact invariant sector
   * energy, Gram, oriented-triple and |S| drift audits
   * Mann-Whitney tests, Cliff's delta/AUC effect size, bootstrap 95% CIs
   * Benjamini-Hochberg FDR both globally for preregistered primary metrics and
     within each metric across UPOs
   * exact permutation Spearman p values for N-level trends (n=5)

F. Model-specific but useful secondary diagnostics
   * existing C/R phase-lock metrics, now compared with invariant-matched
     controls
   * collective-reduction integration audit
   * FTLE versus collective-sector label |S|/N
   * full-state UPO families versus COLLECTIVE dynamical families, preventing
     pseudoreplication when different microscopic invariant sectors realize the
     same reduced central+S orbit

IMPORTANT INTERPRETATION LIMIT
------------------------------
This nonlinear state-dependent mean-field evolution is not a fixed linear
many-body Hamiltonian eigenspectrum. The script therefore does NOT manufacture
ETH, level statistics, entanglement entropy, LDOS combs, or scarred eigenstate
claims. Use terminology such as "dynamical UPO-associated localization/scarring
in a nonlinear quantum mean-field model" unless a separate fixed linear
Hamiltonian construction is introduced.

Primary literature that motivated the metric set (for manuscript citation;
this script does not download anything):
  * Pilatowsky-Cameo et al., New J. Phys. 23, 033045 (2021): time-averaged
    Husimi/tube overlap around periodic orbits and survival-probability revivals.
  * Villasenor et al., Phys. Rev. E 103, 052214 (2021), and Pilatowsky-Cameo
    et al., Quantum 6, 644 (2022): phase-space localization / Renyi occupations.
  * Hummel, Richter & Schlagheck, Phys. Rev. Lett. 130, 250402 (2023): unstable
    periodic mean-field modes and high-dimensional scar dynamics.
  * Pizzi et al., Nature Communications 16, 6722 (2025): UPO return projection,
    cross/return probabilities, lambda/omega criterion, and system-size trends.

A generic command-line invocation is printed by --help. CPU only, checkpointed per
(N,UPO). Re-running the same command skips complete UPOs and rebuilds global
statistics/figures.
"""

import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

import argparse
import csv
import hashlib
import importlib.util
import itertools
import json
import math
import time
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
from scipy.optimize import minimize_scalar
from scipy.stats import mannwhitneyu, spearmanr

# ---------------------------------------------------------------------------
# Constants / conventions
# ---------------------------------------------------------------------------
EPS = 1e-300
PRIMARY_METRICS = (
    "tube_P_2_20",
    "tube_P_10_16",
    "tube_P_16_20",
    "return_peak_1_5",
    "return_peak_6_10",
    "return_timing_1_5",
    "F_harmonic_power",
    "tube_harmonic_power",
    "Renyi_L2",
    "Renyi_L4",
)
STANDARD_WINDOWS = ((2, 6), (6, 10), (10, 16))
FINE_WINDOWS = tuple((a, a + 2) for a in range(2, 20, 2))
SYMS = ("I", "T")

# ---------------------------------------------------------------------------
# I/O and statistics
# ---------------------------------------------------------------------------
def load_core(path):
    path = str(Path(path).resolve())
    spec = importlib.util.spec_from_file_location("scar_core_final", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def ensure(path):
    Path(path).mkdir(parents=True, exist_ok=True)


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_csv(path, rows, fields=None):
    path = Path(path)
    ensure(path.parent)
    if fields is None:
        fields = []
        for r in rows:
            for k in r:
                if k not in fields:
                    fields.append(k)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    os.replace(tmp, path)


def _san(obj):
    if isinstance(obj, dict):
        return {str(k): _san(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_san(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return _san(obj.tolist())
    if isinstance(obj, np.generic):
        return _san(obj.item())
    if isinstance(obj, float) and not np.isfinite(obj):
        return None
    return obj


def write_json(path, obj):
    path = Path(path)
    ensure(path.parent)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(_san(obj), f, indent=2, allow_nan=False)
    os.replace(tmp, path)


def as_float(x, default=np.nan):
    try:
        y = float(x)
        return y if np.isfinite(y) else default
    except Exception:
        return default


def bh_adjust(pvals):
    p = np.asarray(pvals, float)
    q = np.full(len(p), np.nan)
    ok = np.isfinite(p)
    idx = np.flatnonzero(ok)
    if not len(idx):
        return q
    vals = p[idx]
    order = np.argsort(vals)
    ranked = vals[order]
    m = len(ranked)
    adj = ranked * m / np.arange(1, m + 1)
    adj = np.minimum.accumulate(adj[::-1])[::-1]
    adj = np.clip(adj, 0, 1)
    q[idx[order]] = adj
    return q


def cliff_delta(x, y):
    """Cliff's delta P(X>Y)-P(X<Y), O(nm), small samples only."""
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    x = x[np.isfinite(x)]
    y = y[np.isfinite(y)]
    if not len(x) or not len(y):
        return np.nan
    d = 0
    for a in x:
        d += int(np.sum(a > y)) - int(np.sum(a < y))
    return float(d / (len(x) * len(y)))


def mwu_bundle(x, y, alternative="greater"):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    x = x[np.isfinite(x)]
    y = y[np.isfinite(y)]
    if len(x) < 2 or len(y) < 2:
        return {"p": np.nan, "cliff_delta": np.nan, "auc": np.nan}
    try:
        res = mannwhitneyu(x, y, alternative=alternative, method="auto")
        # AUC based on U for X > Y; for less we still report geometric AUC X>Y.
        u_greater = mannwhitneyu(x, y, alternative="greater", method="auto").statistic
        auc = float(u_greater / (len(x) * len(y)))
        return {"p": float(res.pvalue), "cliff_delta": cliff_delta(x, y), "auc": auc}
    except Exception:
        return {"p": np.nan, "cliff_delta": np.nan, "auc": np.nan}


def bootstrap_two_sample(x, y, rng, statistic="ratio", nboot=2000, level=0.95):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    x = x[np.isfinite(x)]
    y = y[np.isfinite(y)]
    if not len(x) or not len(y):
        return (np.nan, np.nan, np.nan)

    def stat(a, b):
        ma, mb = float(np.mean(a)), float(np.mean(b))
        if statistic == "ratio":
            return ma / (mb + EPS)
        if statistic == "difference":
            return ma - mb
        if statistic == "log_ratio":
            return math.log((ma + EPS) / (mb + EPS))
        raise ValueError(statistic)

    point = stat(x, y)
    vals = np.empty(nboot, float)
    for k in range(nboot):
        a = x[rng.integers(0, len(x), len(x))]
        b = y[rng.integers(0, len(y), len(y))]
        vals[k] = stat(a, b)
    alpha = (1.0 - level) / 2.0
    return point, float(np.quantile(vals, alpha)), float(np.quantile(vals, 1 - alpha))


def exact_permutation_spearman(x, y):
    """Two-sided exact permutation p for n<=8; asymptotic fallback otherwise."""
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    mask = np.isfinite(x) & np.isfinite(y)
    x, y = x[mask], y[mask]
    n = len(x)
    if n < 3:
        return {"rho": np.nan, "p_exact": np.nan, "n": n}
    obs = float(spearmanr(x, y).statistic)
    if n <= 8:
        count = 0
        total = 0
        for perm in itertools.permutations(y.tolist()):
            rr = float(spearmanr(x, np.asarray(perm)).statistic)
            total += 1
            if abs(rr) >= abs(obs) - 1e-15:
                count += 1
        p = count / total
    else:
        p = float(spearmanr(x, y).pvalue)
    return {"rho": obs, "p_exact": float(p), "n": n}


# ---------------------------------------------------------------------------
# Exact invariant sector and collective reduction
# ---------------------------------------------------------------------------
def env_vectors(core, R):
    return np.asarray(R, float).reshape(core.M, 3)[1:]


def central_vector(core, R):
    return np.asarray(R, float).reshape(core.M, 3)[0]


def gram_env(core, R):
    E = env_vectors(core, R)
    return E @ E.T


def env_collective(core, R):
    return np.sum(env_vectors(core, R), axis=0)


def triple_products_env(core, R):
    E = env_vectors(core, R)
    if core.N < 3:
        return np.array([], float)
    vals = []
    for i in range(core.N - 2):
        for j in range(i + 1, core.N - 1):
            for k in range(j + 1, core.N):
                vals.append(float(np.dot(E[i], np.cross(E[j], E[k]))))
    return np.asarray(vals, float)


def invariant_fingerprint(core, R):
    E = env_vectors(core, R)
    G = E @ E.T
    iu = np.triu_indices(core.N, 1)
    pairs = G[iu] if core.N > 1 else np.array([])
    triples = triple_products_env(core, R)
    S = np.sum(E, axis=0)
    ev = np.linalg.eigvalsh(G)
    payload = (
        np.round(G, 12).tobytes()
        + np.round(triples, 12).tobytes()
        + np.round(S @ S, 12).tobytes()
    )
    return {
        "S_norm": float(np.linalg.norm(S)),
        "S_per_spin": float(np.linalg.norm(S) / core.N),
        "pair_dot_mean": float(np.mean(pairs)) if len(pairs) else 1.0,
        "pair_dot_std": float(np.std(pairs)) if len(pairs) else 0.0,
        "pair_dot_min": float(np.min(pairs)) if len(pairs) else 1.0,
        "pair_dot_max": float(np.max(pairs)) if len(pairs) else 1.0,
        "triple_mean": float(np.mean(triples)) if len(triples) else 0.0,
        "triple_std": float(np.std(triples)) if len(triples) else 0.0,
        "triple_abs_max": float(np.max(np.abs(triples))) if len(triples) else 0.0,
        "gram_eigs_json": json.dumps([float(v) for v in ev]),
        "sector_sha256": hashlib.sha256(payload).hexdigest(),
    }


def invariant_difference(core, A, B):
    GA, GB = gram_env(core, A), gram_env(core, B)
    ta, tb = triple_products_env(core, A), triple_products_env(core, B)
    sa, sb = np.linalg.norm(env_collective(core, A)), np.linalg.norm(env_collective(core, B))
    return {
        "gram_max_abs_diff": float(np.max(np.abs(GA - GB))),
        "triple_max_abs_diff": float(np.max(np.abs(ta - tb))) if len(ta) else 0.0,
        "S_norm_abs_diff": float(abs(sa - sb)),
        "energy_abs_diff": float(abs(core.energy_bloch(A) - core.energy_bloch(B))),
    }


def invariant_drift(core, traj):
    traj = np.asarray(traj, float)
    G0 = gram_env(core, traj[0])
    t0 = triple_products_env(core, traj[0])
    s0 = np.linalg.norm(env_collective(core, traj[0]))
    gd = sd = td = cres = hres = 0.0
    for R in traj:
        gd = max(gd, float(np.max(np.abs(gram_env(core, R) - G0))))
        trp = triple_products_env(core, R)
        if len(t0):
            td = max(td, float(np.max(np.abs(trp - t0))))
        S = env_collective(core, R)
        sd = max(sd, abs(np.linalg.norm(S) - s0))
        F = core.bloch_rhs(0, R).reshape(core.M, 3)
        Z = np.asarray(R).reshape(core.M, 3)[0, 2]
        Be = np.array([-2.0*core.Di, 0.0, 2.0*core.Ei + core.Lambda*Z])
        cres = max(cres, float(np.linalg.norm(np.sum(F[1:], axis=0) - np.cross(Be, S))))
        rr = np.asarray(R).reshape(core.M, 3)
        Hcoll = (-2.0*core.delta*rr[0,0] + 2.0*core.epsilon*rr[0,2]
                 -2.0*core.Di*S[0] + 2.0*core.Ei*S[2]
                 + core.Lambda*rr[0,2]*S[2])
        hres = max(hres, abs(core.energy_bloch(R) - Hcoll))
    return {
        "gram_drift": gd,
        "triple_drift": td,
        "S_norm_drift": sd,
        "collective_rhs_residual": cres,
        "collective_energy_residual": hres,
    }


def collective_rhs_core(core, t, y):
    y = np.asarray(y, float)
    r = y[:3]
    S = y[3:]
    B0 = np.array([-2.0*core.delta, 0.0, 2.0*core.epsilon + core.Lambda*S[2]])
    Be = np.array([-2.0*core.Di, 0.0, 2.0*core.Ei + core.Lambda*r[2]])
    return np.concatenate([np.cross(B0, r), np.cross(Be, S)])


def collective_state(core, R):
    return np.concatenate([central_vector(core, R), env_collective(core, R)])


def collective_reduction_audit(core, R0, times, full_traj):
    y0 = collective_state(core, R0)
    sol = solve_ivp(
        lambda t, y: collective_rhs_core(core, t, y),
        (float(times[0]), float(times[-1])),
        y0,
        t_eval=times,
        rtol=2e-10,
        atol=2e-12,
        method="DOP853",
    )
    if not sol.success:
        return {"collective_reduction_max_error": np.nan, "collective_reduction_rms_error": np.nan}
    reduced = sol.y.T
    full_coll = np.array([collective_state(core, R) for R in full_traj])
    diff = full_coll - reduced
    return {
        "collective_reduction_max_error": float(np.max(np.linalg.norm(diff, axis=1))),
        "collective_reduction_rms_error": float(np.sqrt(np.mean(diff * diff))),
    }


def sector_energy_bounds(core, Snorm):
    """Exact reduced-sector energy bounds for fixed |S|."""
    s = float(Snorm)
    def coll_norm(z):
        return math.sqrt((2.0*core.Di)**2 + (2.0*core.Ei + core.Lambda*z)**2)
    def emax_z(z):
        z=float(np.clip(z,-1,1))
        return (2.0*core.delta*math.sqrt(max(0.0,1-z*z)) + 2.0*core.epsilon*z
                + s*coll_norm(z))
    def emin_z(z):
        z=float(np.clip(z,-1,1))
        return (-2.0*core.delta*math.sqrt(max(0.0,1-z*z)) + 2.0*core.epsilon*z
                - s*coll_norm(z))
    rmax=minimize_scalar(lambda z:-emax_z(z),bounds=(-1,1),method="bounded",options={"xatol":1e-13})
    rmin=minimize_scalar(emin_z,bounds=(-1,1),method="bounded",options={"xatol":1e-13})
    return float(rmin.fun), float(-rmax.fun)


def sector_Emax(core, Snorm):
    return sector_energy_bounds(core, Snorm)[1]


# ---------------------------------------------------------------------------
# SO(3) controls constrained to the exact invariant sector and energy
# ---------------------------------------------------------------------------
def rodrigues(axis, angle):
    a = np.asarray(axis, float)
    a /= np.linalg.norm(a)
    x, y, z = a
    K = np.array([[0, -z, y], [z, 0, -x], [-y, x, 0]], float)
    return np.eye(3) * math.cos(angle) + (1 - math.cos(angle)) * np.outer(a, a) + math.sin(angle) * K


def random_rotation(rng):
    q = rng.normal(size=4)
    q /= np.linalg.norm(q)
    w, x, y, z = q
    return np.array([
        [1 - 2 * (y*y + z*z), 2 * (x*y - z*w), 2 * (x*z + y*w)],
        [2 * (x*y + z*w), 1 - 2 * (x*x + z*z), 2 * (y*z - x*w)],
        [2 * (x*z - y*w), 2 * (y*z + x*w), 1 - 2 * (x*x + y*y)],
    ], float)


def energy_circle_for_central(core, env, target_energy):
    S = np.sum(env, axis=0)
    a = np.array([-2.0*core.delta, 0.0, 2.0*core.epsilon + core.Lambda*S[2]], float)
    an = np.linalg.norm(a)
    Henv = -2.0*core.Di*S[0] + 2.0*core.Ei*S[2]
    c = float(target_energy - Henv)
    if an < 1e-14:
        return None
    d = c / an
    if abs(d) > 1 + 1e-11:
        return None
    d = float(np.clip(d, -1, 1))
    n = a / an
    rad = math.sqrt(max(0.0, 1 - d*d))
    return n, d, rad


def central_on_energy(core, env, target_energy, rng, target=None, delta_angle=None):
    ec = energy_circle_for_central(core, env, target_energy)
    if ec is None:
        return None
    n, d, rad = ec
    if target is not None:
        q = np.asarray(target, float) - np.dot(target, n) * n
        if np.linalg.norm(q) < 1e-12:
            tmp = np.array([1., 0., 0.]) if abs(n[0]) < .8 else np.array([0., 1., 0.])
            q = tmp - np.dot(tmp, n) * n
        u = q / np.linalg.norm(q)
        v = np.cross(n, u)
        v /= np.linalg.norm(v)
        ang = float(delta_angle or 0.0)
    else:
        tmp = np.array([1., 0., 0.]) if abs(n[0]) < .8 else np.array([0., 1., 0.])
        u = tmp - np.dot(tmp, n) * n
        u /= np.linalg.norm(u)
        v = np.cross(n, u)
        v /= np.linalg.norm(v)
        ang = float(rng.uniform(0, 2*np.pi))
    r = d * n + rad * (math.cos(ang) * u + math.sin(ang) * v)
    return r / np.linalg.norm(r)


def compose_state(c, env):
    return np.vstack([c, env]).reshape(-1)


def max_tube_overlap(core, R, phase):
    rr = np.asarray(R, float).reshape(core.M, 3)
    pp = np.asarray(phase, float).reshape(len(phase), core.M, 3)
    q = np.ones(len(phase), float)
    for k in range(core.M):
        q *= .5 * (1 + np.clip(pp[:, k, :] @ rr[k], -1, 1))
    return float(np.max(q))


def sample_microcanonical_sector_state(core, base, target_energy, rng, max_attempts=20000):
    """
    Sample the fixed-energy manifold inside one exact environment sector.

    The environment is rotated with Haar SO(3). For a fixed rotated environment,
    H = a.r0 - 2 Sx with a=(-2,0,Sz). The central-spin sphere constrained
    by delta(E-H) is a circle. Integrating the surface delta function over that
    circle gives a weight proportional to 1/|a|. Since |a|>=2, rejection with
    probability 2/|a| samples the corresponding microcanonical sector measure;
    the angle on the allowed circle is uniform.
    """
    rr = np.asarray(base, float).reshape(core.M, 3)
    env0 = rr[1:]
    for _ in range(max_attempts):
        env = env0 @ random_rotation(rng).T
        ec = energy_circle_for_central(core, env, target_energy)
        if ec is None:
            continue
        S = np.sum(env, axis=0)
        an = math.sqrt((2.0*core.delta)**2 + (2.0*core.epsilon + core.Lambda*S[2])**2)
        lower = max(1e-12, 2.0*abs(core.delta))
        if rng.random() > min(1.0, lower / an):
            continue
        c = central_on_energy(core, env, target_energy, rng, target=None)
        if c is None:
            continue
        out = compose_state(c, env)
        if abs(core.energy_bloch(out) - target_energy) < 2e-10:
            return out
    raise RuntimeError("failed microcanonical same-sector sampling")


def make_near_same_sector(core, base, target_energy, rng, amp):
    rr = np.asarray(base, float).reshape(core.M, 3)
    c0, env0 = rr[0], rr[1:]
    for _ in range(500):
        axis = rng.normal(size=3)
        axis /= np.linalg.norm(axis)
        Rm = rodrigues(axis, float(rng.normal(scale=amp)))
        env = env0 @ Rm.T
        c = central_on_energy(core, env, target_energy, rng, target=c0, delta_angle=float(rng.normal(scale=amp)))
        if c is None:
            continue
        out = compose_state(c, env)
        if abs(core.energy_bloch(out) - target_energy) < 2e-10:
            return out
    raise RuntimeError("failed exact-sector near-state generation")


def make_away_same_sector(core, base, target_energy, rng, phase, max_overlap=0.20):
    best = None
    best_q = np.inf
    for _ in range(12000):
        out = sample_microcanonical_sector_state(core, base, target_energy, rng, max_attempts=200)
        q = max_tube_overlap(core, out, phase)
        if q < best_q:
            best_q, best = q, out.copy()
        if q <= max_overlap:
            return out
    # Robust fallback: return the furthest microcanonical state found and record
    # its initial tube overlap in initial_conditions_and_invariant_match.csv.
    if best is not None:
        return best
    raise RuntimeError("failed exact-sector away-control generation")


# ---------------------------------------------------------------------------
# Exact product-state overlaps and standard scar observables
# ---------------------------------------------------------------------------
def survival_fidelity(core, traj, R0):
    rr0 = np.asarray(R0, float).reshape(core.M, 3)
    tr = np.asarray(traj, float).reshape(len(traj), core.M, 3)
    F = np.ones(len(tr), float)
    for k in range(core.M):
        F *= .5 * (1 + np.clip(tr[:, k, :] @ rr0[k], -1, 1))
    return np.clip(F, 0, 1)


def pair_overlap_matrix(core, A, B, chunk=256):
    A = np.asarray(A, float)
    B = np.asarray(B, float)
    out = np.empty((len(A), len(B)), float)
    bb = B.reshape(len(B), core.M, 3)
    for s in range(0, len(A), chunk):
        aa = A[s:s+chunk].reshape(-1, core.M, 3)
        Q = np.ones((len(aa), len(B)), float)
        for k in range(core.M):
            Q *= .5 * (1 + np.clip(aa[:, k, :] @ bb[:, k, :].T, -1, 1))
        out[s:s+len(aa)] = np.clip(Q, 0, 1)
    return out


def tube_time_series(core, traj, phase):
    Q = pair_overlap_matrix(core, traj, phase)
    return np.mean(Q, axis=1), np.max(Q, axis=1), Q


def renyi_occupations(profile):
    q = np.clip(np.asarray(profile, float), EPS, 1.0)
    m1 = float(np.mean(q))
    out = {}
    for a in (2.0, 4.0):
        ma = float(np.mean(q**a))
        out[f"L{int(a)}"] = float((ma / (m1**a)) ** (1.0 / (1.0 - a))) if m1 > 0 and ma > 0 else np.nan
    mql = float(np.mean(q * np.log(q)))
    out["L1"] = float(m1 * np.exp(-mql / m1)) if m1 > 0 else np.nan
    out["IPR2_norm"] = float(1.0 / out["L2"]) if out["L2"] > 0 else np.nan
    return out


def trajectory_husimi_profile(core, snapshots, reference):
    # Time-averaged Husimi probability on an microcanonical same-invariant-sector
    # reference set. This is a model-adapted analogue of an energy-shell Husimi
    # distribution, not an eigenstate Husimi distribution of a linear H.
    Q = pair_overlap_matrix(core, snapshots, reference)
    return np.mean(Q, axis=0)


def renyi_convergence(profile, sizes, reps, rng):
    q = np.asarray(profile, float)
    rows = []
    for size in sizes:
        m = min(int(size), len(q))
        if m < 20:
            continue
        for rep in range(reps):
            idx = rng.choice(len(q), size=m, replace=False) if m < len(q) else np.arange(len(q))
            rr = renyi_occupations(q[idx])
            rows.append({"reference_size": m, "replicate": rep, **rr})
    return rows


def revival_metrics(F, T, times, coreM, window_frac=.12, max_n=20):
    F = np.asarray(F, float)
    times = np.asarray(times, float)
    peaks = []
    exact = []
    peak_t = []
    offsets = []
    abs_offsets = []
    for n in range(1, max_n + 1):
        lo, hi = (n - window_frac) * T, (n + window_frac) * T
        mask = (times >= lo) & (times <= hi)
        if np.any(mask):
            inds = np.flatnonzero(mask)
            j = inds[int(np.argmax(F[mask]))]
            pv = float(F[j])
            pt = float(times[j])
        else:
            pv, pt = np.nan, np.nan
        peaks.append(pv)
        peak_t.append(pt)
        off = (pt - n*T) / T if np.isfinite(pt) else np.nan
        offsets.append(off)
        abs_offsets.append(abs(off) if np.isfinite(off) else np.nan)
        exact.append(float(F[np.argmin(np.abs(times - n*T))]))

    phase = np.mod(times / T, 1.0)
    offperiod = (times >= 2*T) & (np.minimum(phase, 1 - phase) > window_frac)
    bg = F[offperiod] if np.any(offperiod) else F[times >= 2*T]
    bg_med = float(np.median(bg)) if len(bg) else float(np.median(F))
    bg_mad = float(np.median(np.abs(bg - np.median(bg)))) if len(bg) else np.nan
    bg_sigma = 1.4826 * bg_mad if np.isfinite(bg_mad) else np.nan
    mean15 = float(np.nanmean(peaks[:5]))
    contrast = (mean15 - bg_med) / (bg_sigma + 1e-15) if np.isfinite(bg_sigma) else np.nan
    root = np.power(np.clip(F, EPS, 1), 1.0 / coreM)
    return {
        "revival_peak_1": peaks[0],
        "mean_peak_1_5": mean15,
        "mean_peak_6_10": float(np.nanmean(peaks[5:10])),
        "mean_peak_11_20": float(np.nanmean(peaks[10:20])),
        "mean_exact_1_5": float(np.nanmean(exact[:5])),
        "mean_abs_timing_offset_1_5": float(np.nanmean(abs_offsets[:5])),
        "mean_abs_timing_offset_6_10": float(np.nanmean(abs_offsets[5:10])),
        "background_median": bg_med,
        "background_robust_sigma": bg_sigma,
        "revival_contrast_1_5": float(contrast),
        "revival_enhancement_1_5": float(mean15 / (bg_med + EPS)),
        "late_mean_F": float(np.mean(F[times >= 10*T])),
        "late_mean_F_root_perTLS": float(np.mean(root[times >= 10*T])),
        "peaks_json": json.dumps(peaks),
        "peak_times_over_T_json": json.dumps([pt/T if np.isfinite(pt) else None for pt in peak_t]),
        "timing_offsets_json": json.dumps(offsets),
        "exact_json": json.dumps(exact),
    }


def spectral_metrics(sig, times, T):
    sig = np.asarray(sig, float)
    times = np.asarray(times, float)
    mask = times >= T
    x = sig[mask]
    tt = times[mask]
    if len(x) < 32:
        return {
            "fundamental_power_fraction": np.nan,
            "harmonic_power_fraction": np.nan,
            "dominant_frequency_times_T": np.nan,
            "fundamental_frequency_mismatch": np.nan,
        }
    x = x - np.mean(x)
    x = x * np.hanning(len(x))
    dt = float(np.mean(np.diff(tt)))
    P = np.abs(np.fft.rfft(x))**2
    f = np.fft.rfftfreq(len(x), dt)
    if len(P):
        P[0] = 0
    den = np.sum(P) + EPS
    parts = []
    for h in range(1, 5):
        target = h / T
        k = int(np.argmin(np.abs(f - target)))
        a, b = max(0, k - 1), min(len(P), k + 2)
        parts.append(float(np.sum(P[a:b]) / den))
    kd = int(np.argmax(P)) if len(P) else 0
    dom = float(f[kd] * T) if len(f) else np.nan
    target = 1.0 / T
    k1 = int(np.argmin(np.abs(f - target)))
    mismatch = float(abs(f[k1] - target) * T)
    return {
        "fundamental_power_fraction": parts[0],
        "harmonic_power_fraction": float(sum(parts)),
        "harmonic_parts_json": json.dumps(parts),
        "dominant_frequency_times_T": dom,
        "fundamental_frequency_mismatch": mismatch,
    }


def stability_metrics(orbit):
    eig = np.asarray(orbit.get("eigvals", []), complex)
    T = float(orbit["T"])
    abs_mu = np.abs(eig)
    abs_mu = abs_mu[np.isfinite(abs_mu) & (abs_mu > EPS)]
    logs = np.log(abs_mu)
    # Neutral numerical noise is excluded. Hamiltonian reciprocal pairs then
    # contribute one positive exponent per unstable direction.
    positive = logs[logs > 1e-5] / T
    lam_sum = float(np.sum(positive))
    lam_max = float(np.max(positive)) if len(positive) else 0.0
    omega = 2 * np.pi / T
    return {
        "n_positive_floquet": int(len(positive)),
        "lambda_plus_sum": lam_sum,
        "lambda_plus_sum_T": lam_sum * T,
        "heller_sum_over_2pi": float(lam_sum / omega),
        "classical_return_damping_per_period": float(np.exp(-lam_sum * T)),
        "lambda_max_from_spectrum": lam_max,
        "lambda_max_over_omega": float(lam_max / omega),
        "lyapunov_time_over_period": float(1.0 / (lam_max*T)) if lam_max > 0 else np.inf,
        "heller_lambda_over_omega_lt_1": bool((lam_max / omega) < 1.0) if lam_max > 0 else False,
        "floquet_abs_json": json.dumps([float(x) for x in sorted(abs_mu, reverse=True)]),
    }


# ---------------------------------------------------------------------------
# Collective UPO family classification
# ---------------------------------------------------------------------------
def _apply_collective_symmetry(traj, sym):
    a = np.asarray(traj, float).copy().reshape(-1, 2, 3)
    reverse = sym in ("T", "PT")
    if reverse:
        a = a[::-1].copy()
    if sym == "P":
        a[:, :, 1] *= -1
        a[:, :, 2] *= -1
    elif sym == "T":
        a[:, :, 1] *= -1
    elif sym == "PT":
        a[:, :, 2] *= -1
    return a.reshape(-1, 6)


def _collective_phase(core, orbit, points):
    ph = core.phase_grid(orbit, points)
    out = []
    for R in ph:
        r0 = central_vector(core, R)
        S = env_collective(core, R)
        out.append(np.concatenate([r0, S]))
    return np.asarray(out)


def collective_pair_alignment(core, oa, ob, points=360):
    Ta, Tb = float(oa["T"]), float(ob["T"])
    relT = abs(Ta - Tb) / max(min(Ta, Tb), 1e-12)
    sa = np.linalg.norm(env_collective(core, oa["R0"]))
    sb = np.linalg.norm(env_collective(core, ob["R0"]))
    relS = abs(sa - sb) / max(sa, sb, 1e-12)
    if relT > 5e-4 or relS > 5e-5:
        return {"equivalent": False, "period_rel_diff": relT, "S_rel_diff": relS,
                "rms": np.nan, "max": np.nan, "shift": -1, "sym": ""}
    A = _collective_phase(core, oa, points)
    B0 = _collective_phase(core, ob, points)
    # Balance central and environment direction while still including |S| as
    # a separately checked invariant above.
    A2 = A.copy(); Bbase = B0.copy()
    A2[:, 3:] /= max(sa, 1e-12)
    Bbase[:, 3:] /= max(sb, 1e-12)
    best = (np.inf, np.inf, -1, "")
    for sym in SYMS:
        B = _apply_collective_symmetry(Bbase, sym)
        for shift in range(points):
            Br = np.roll(B, shift, axis=0)
            d = A2 - Br
            rms = float(np.sqrt(np.mean(d*d)))
            mx = float(np.max(np.linalg.norm(d.reshape(points, 2, 3), axis=2)))
            if rms < best[0]:
                best = (rms, mx, shift, sym)
    eq = best[0] < 8e-4 and best[1] < 4e-3
    return {"equivalent": bool(eq), "period_rel_diff": relT, "S_rel_diff": relS,
            "rms": best[0], "max": best[1], "shift": best[2], "sym": best[3]}


def classify_collective_families(core, upos, outdir, points=360):
    n = len(upos)
    pairs = []
    parent = list(range(n))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    for i in range(n):
        for j in range(i + 1, n):
            d = collective_pair_alignment(core, upos[i], upos[j], points=points)
            pairs.append({"i": i, "j": j, **d})
            if d["equivalent"]:
                union(i, j)
    roots = {}
    cls = []
    for i in range(n):
        r = find(i)
        if r not in roots:
            roots[r] = len(roots)
        cid = roots[r]
        fp = invariant_fingerprint(core, upos[i]["R0"])
        cls.append({"orbit": i, "collective_class": cid, "T": float(upos[i]["T"]),
                    "rho": float(upos[i]["rho"]), "S_norm": fp["S_norm"],
                    "sector_sha256": fp["sector_sha256"]})
    counts = {}
    for r in cls:
        counts[r["collective_class"]] = counts.get(r["collective_class"], 0) + 1
    for r in cls:
        r["collective_class_size"] = counts[r["collective_class"]]
    write_csv(Path(outdir) / "collective_equivalence_pairs.csv", pairs)
    write_csv(Path(outdir) / "collective_family_classes.csv", cls)
    return {int(r["orbit"]): int(r["collective_class"]) for r in cls}, pairs, cls


# ---------------------------------------------------------------------------
# Per-trajectory and per-UPO analysis
# ---------------------------------------------------------------------------
def integrate_for_periods(core, R0, T, periods, ppp):
    total = periods * T
    nt = periods * ppp + 1
    return core.integrate_grid(R0, total, nt, rtol=2e-9, atol=1e-11)


def window_slice(ppp, a, b):
    return slice(int(a*ppp), int(b*ppp) + 1)


def trajectory_scalar_metrics(core, traj, times, phase, T, ppp):
    F = survival_fidelity(core, traj, traj[0])
    tube_mean, tube_max, Q = tube_time_series(core, traj, phase)
    rm = revival_metrics(F, T, times, core.M)
    sf = spectral_metrics(F, times, T)
    st = spectral_metrics(tube_mean, times, T)
    sz = spectral_metrics(np.asarray(traj)[:, 2], times, T)
    out = {**rm}
    out.update({f"F_{k}": v for k, v in sf.items()})
    out.update({f"tube_{k}": v for k, v in st.items()})
    out.update({f"Z_{k}": v for k, v in sz.items()})
    for a, b in ((2, 20), (10, 16), (16, 20)):
        sl = window_slice(ppp, a, b)
        q = np.clip(tube_mean[sl], EPS, 1)
        qm = np.clip(tube_max[sl], EPS, 1)
        out[f"tube_mean_{a}_{b}"] = float(np.mean(q))
        out[f"tube_max_{a}_{b}"] = float(np.mean(qm))
        out[f"tube_log_perTLS_{a}_{b}"] = float(np.mean(np.log(q)) / core.M)
    return out, F, tube_mean, tube_max, Q


def summarize_comparison(near, ctrl, key, rng, direction="greater", ci_stat="ratio", nboot=2000):
    near = np.asarray(near, float)
    ctrl = np.asarray(ctrl, float)
    near = near[np.isfinite(near)]
    ctrl = ctrl[np.isfinite(ctrl)]
    mb = mwu_bundle(near, ctrl, alternative=direction)
    if ci_stat == "ratio":
        point, lo, hi = bootstrap_two_sample(near, ctrl, rng, "ratio", nboot=nboot)
    else:
        point, lo, hi = bootstrap_two_sample(near, ctrl, rng, "difference", nboot=nboot)
    return {
        f"near_{key}": float(np.mean(near)) if len(near) else np.nan,
        f"control_{key}": float(np.mean(ctrl)) if len(ctrl) else np.nan,
        f"effect_{key}": point,
        f"effect_ci_low_{key}": lo,
        f"effect_ci_high_{key}": hi,
        f"p_{key}": mb["p"],
        f"cliff_delta_{key}": mb["cliff_delta"],
        f"auc_{key}": mb["auc"],
    }


def analyze_upo(core, N, oid, orbit, target_energy, outdir, args, rng, collective_class):
    od = Path(outdir) / f"UPO{oid}"
    ensure(od)
    done = od / "DONE.json"
    if done.exists() and (od / "summary.csv").exists():
        return read_csv(od / "summary.csv")[0]

    T = float(orbit["T"])
    phase = core.phase_grid(orbit, args.phase_points)
    fp = invariant_fingerprint(core, orbit["R0"])
    stab = stability_metrics(orbit)
    emin_sector, emax_sector = sector_energy_bounds(core, fp["S_norm"])

    t_upo, upo_tr = core.integrate_grid(orbit["R0"], T, max(360, args.phase_points), rtol=2e-10, atol=2e-12)
    inv_audit = invariant_drift(core, upo_tr)
    red_audit = collective_reduction_audit(core, orbit["R0"], t_upo, upo_tr)
    audit = {
        "N": N, "orbit": oid, "collective_class": collective_class,
        "T": T, "rho": float(orbit["rho"]), **fp, **stab, **inv_audit, **red_audit,
        "target_energy": target_energy,
        "sector_Emin": emin_sector,
        "sector_Emax": emax_sector,
        "target_E_over_sector_Emax": float(target_energy / emax_sector),
        "target_sector_xi": float((target_energy-emin_sector)/(emax_sector-emin_sector)),
        "lambda_max_original": float(orbit.get("lambda", np.nan)),
    }
    write_json(od / "invariant_collective_stability_audit.json", audit)

    controls = []
    near_states = []
    ctrl_sparse = []
    near_sparse = []
    dynrows = []
    icrows = []
    phase_rows = []
    time_series = {"control": [], "near": []}

    # -------- invariant-matched away controls --------
    for s in range(args.controls):
        base = phase[int(rng.integers(0, len(phase)))]
        R = make_away_same_sector(core, base, target_energy, rng, phase, args.control_max_tube)
        times, tr = integrate_for_periods(core, R, T, args.periods, args.ppp)
        inv = invariant_drift(core, tr[::max(1, args.ppp//2)])
        vals, F, tube_mean, tube_max, Q = trajectory_scalar_metrics(core, tr, times, phase, T, args.ppp)
        row = {"kind": "control", "sample": s, "energy": float(core.energy_bloch(R)), **inv, **vals}
        dynrows.append(row)
        diff = invariant_difference(core, orbit["R0"], R)
        icrows.append({"kind": "control", "sample": s, "R_json": json.dumps(R.tolist()),
                       "max_initial_tube": max_tube_overlap(core, R, phase), **diff})
        ctrl_sparse.append(tr[2*args.ppp::args.renyi_stride].copy())
        controls.append(R)
        time_series["control"].append(np.column_stack([F, tube_mean, tube_max, tr[:, 2]]))
        for a, b in STANDARD_WINDOWS + FINE_WINDOWS:
            C, Rc = core.phase_lock_metrics(Q, times, T, a*args.ppp, b*args.ppp + 1)
            phase_rows.append({"kind": "control", "sample": s, "window_start": a, "window_end": b, "C": C, "R": Rc})
        print(f"N={N} UPO={oid} invariant-matched control {s+1}/{args.controls}", flush=True)

    # Independent microcanonical same-sector reference. It is NOT built from the
    # hypothesis-test controls, avoiding reference leakage/self-inclusion bias.
    ref = np.array([
        sample_microcanonical_sector_state(core, orbit["R0"], target_energy, rng)
        for _ in range(args.reference_points)
    ], float)
    np.savez_compressed(od / "invariant_sector_microcanonical_reference.npz", reference=ref)

    # -------- near-UPO states in exactly the same invariant sector --------
    for s in range(args.near):
        base = phase[int(rng.integers(0, len(phase)))]
        R = make_near_same_sector(core, base, target_energy, rng, args.near_amplitude)
        times, tr = integrate_for_periods(core, R, T, args.periods, args.ppp)
        inv = invariant_drift(core, tr[::max(1, args.ppp//2)])
        vals, F, tube_mean, tube_max, Q = trajectory_scalar_metrics(core, tr, times, phase, T, args.ppp)
        row = {"kind": "near", "sample": s, "energy": float(core.energy_bloch(R)), **inv, **vals}
        dynrows.append(row)
        diff = invariant_difference(core, orbit["R0"], R)
        icrows.append({"kind": "near", "sample": s, "R_json": json.dumps(R.tolist()),
                       "max_initial_tube": max_tube_overlap(core, R, phase), **diff})
        near_sparse.append(tr[2*args.ppp::args.renyi_stride].copy())
        near_states.append(R)
        time_series["near"].append(np.column_stack([F, tube_mean, tube_max, tr[:, 2]]))
        for a, b in STANDARD_WINDOWS + FINE_WINDOWS:
            C, Rc = core.phase_lock_metrics(Q, times, T, a*args.ppp, b*args.ppp + 1)
            phase_rows.append({"kind": "near", "sample": s, "window_start": a, "window_end": b, "C": C, "R": Rc})
        print(f"N={N} UPO={oid} exact-sector near {s+1}/{args.near}", flush=True)

    # Save compressed time series: [sample, time, (F,tube_mean,tube_max,Z)].
    np.savez_compressed(
        od / "standard_time_series.npz",
        times=times,
        control=np.asarray(time_series["control"], float),
        near=np.asarray(time_series["near"], float),
        columns=np.array(["return_fidelity", "tube_mean", "tube_max", "Z"]),
    )

    # -------- Renyi occupations + convergence --------
    renyi_rows = []
    conv_rows = []
    ref_sizes = [x for x in args.renyi_reference_sizes if x <= len(ref)]
    if len(ref) not in ref_sizes:
        ref_sizes.append(len(ref))
    ref_sizes = sorted(set(ref_sizes))
    for kind, collections in (("control", ctrl_sparse), ("near", near_sparse)):
        for s, snaps in enumerate(collections):
            prof = trajectory_husimi_profile(core, snaps, ref)
            rr = renyi_occupations(prof)
            renyi_rows.append({"kind": kind, "sample": s, **rr, "mean_husimi": float(np.mean(prof))})
            cr = renyi_convergence(prof, ref_sizes, args.renyi_convergence_reps, rng)
            for r in cr:
                conv_rows.append({"kind": kind, "sample": s, **r})

    write_csv(od / "dynamics_raw.csv", dynrows)
    write_csv(od / "initial_conditions_and_invariant_match.csv", icrows)
    write_csv(od / "renyi_occupation_raw.csv", renyi_rows)
    write_csv(od / "renyi_convergence_raw.csv", conv_rows)
    write_csv(od / "matched_phase_windows_raw.csv", phase_rows)

    def vals(kind, key):
        return np.array([as_float(r.get(key)) for r in dynrows if r["kind"] == kind], float)

    def renvals(kind, key):
        return np.array([as_float(r.get(key)) for r in renyi_rows if r["kind"] == kind], float)

    summary = {**audit}
    hypothesis_rows = []

    def add_metric(name, near, ctrl, direction="greater", ci="ratio", primary=False):
        bundle = summarize_comparison(near, ctrl, name, rng, direction=direction, ci_stat=ci, nboot=args.bootstrap)
        summary.update(bundle)
        hypothesis_rows.append({
            "N": N, "orbit": oid, "collective_class": collective_class,
            "metric": name, "family": "primary" if primary else "secondary",
            "direction": direction, "raw_p": bundle[f"p_{name}"],
            "cliff_delta": bundle[f"cliff_delta_{name}"],
            "auc": bundle[f"auc_{name}"],
            "near_mean": bundle[f"near_{name}"], "control_mean": bundle[f"control_{name}"],
            "effect": bundle[f"effect_{name}"], "effect_ci_low": bundle[f"effect_ci_low_{name}"],
            "effect_ci_high": bundle[f"effect_ci_high_{name}"],
        })

    # Explicit literature-style tube scar measure P = near/control.
    add_metric("tube_P_2_20", vals("near", "tube_mean_2_20"), vals("control", "tube_mean_2_20"), primary=True)
    add_metric("tube_P_10_16", vals("near", "tube_mean_10_16"), vals("control", "tube_mean_10_16"), primary=True)
    add_metric("tube_P_16_20", vals("near", "tube_mean_16_20"), vals("control", "tube_mean_16_20"), primary=True)
    add_metric("tube_max_16_20", vals("near", "tube_max_16_20"), vals("control", "tube_max_16_20"))

    # Return / revival signatures.
    add_metric("return_peak_1_5", vals("near", "mean_peak_1_5"), vals("control", "mean_peak_1_5"), primary=True)
    add_metric("return_peak_6_10", vals("near", "mean_peak_6_10"), vals("control", "mean_peak_6_10"), primary=True)
    # Smaller timing error is better: test near < control; effect is difference near-control.
    add_metric("return_timing_1_5", vals("near", "mean_abs_timing_offset_1_5"), vals("control", "mean_abs_timing_offset_1_5"), direction="less", ci="difference", primary=True)
    add_metric("return_contrast_1_5", vals("near", "revival_contrast_1_5"), vals("control", "revival_contrast_1_5"))

    # Frequency locking.
    add_metric("F_fundamental_power", vals("near", "F_fundamental_power_fraction"), vals("control", "F_fundamental_power_fraction"))
    add_metric("F_harmonic_power", vals("near", "F_harmonic_power_fraction"), vals("control", "F_harmonic_power_fraction"), primary=True)
    add_metric("tube_harmonic_power", vals("near", "tube_harmonic_power_fraction"), vals("control", "tube_harmonic_power_fraction"), primary=True)
    add_metric("Z_harmonic_power", vals("near", "Z_harmonic_power_fraction"), vals("control", "Z_harmonic_power_fraction"))

    # Renyi: smaller L_alpha = stronger localization, so control > near.
    for key in ("L1", "L2", "L4"):
        nv, cv = renvals("near", key), renvals("control", key)
        # Test control > near while still storing near/control columns under a consistent name.
        bundle = summarize_comparison(cv, nv, f"Renyi_{key}", rng, direction="greater", ci_stat="ratio", nboot=args.bootstrap)
        # Re-label semantic means for readability: localization ratio = control/near.
        summary[f"control_{key}"] = float(np.mean(cv))
        summary[f"near_{key}"] = float(np.mean(nv))
        summary[f"localization_ratio_{key}"] = bundle[f"effect_Renyi_{key}"]
        summary[f"localization_ratio_ci_low_{key}"] = bundle[f"effect_ci_low_Renyi_{key}"]
        summary[f"localization_ratio_ci_high_{key}"] = bundle[f"effect_ci_high_Renyi_{key}"]
        summary[f"p_localized_{key}"] = bundle[f"p_Renyi_{key}"]
        summary[f"cliff_delta_localized_{key}"] = bundle[f"cliff_delta_Renyi_{key}"]
        hypothesis_rows.append({
            "N": N, "orbit": oid, "collective_class": collective_class,
            "metric": f"Renyi_{key}", "family": "primary" if key in ("L2", "L4") else "secondary",
            "direction": "control>near", "raw_p": bundle[f"p_Renyi_{key}"],
            "cliff_delta": bundle[f"cliff_delta_Renyi_{key}"], "auc": bundle[f"auc_Renyi_{key}"],
            "near_mean": float(np.mean(nv)), "control_mean": float(np.mean(cv)),
            "effect": bundle[f"effect_Renyi_{key}"],
            "effect_ci_low": bundle[f"effect_ci_low_Renyi_{key}"],
            "effect_ci_high": bundle[f"effect_ci_high_Renyi_{key}"],
        })
    # IPR higher = more localized.
    add_metric("IPR2_norm", renvals("near", "IPR2_norm"), renvals("control", "IPR2_norm"))

    # Existing C/R retained as secondary matched-control metrics.
    for a, b in STANDARD_WINDOWS:
        for key in ("C", "R"):
            nv = np.array([as_float(r[key]) for r in phase_rows if r["kind"] == "near" and int(r["window_start"]) == a], float)
            cv = np.array([as_float(r[key]) for r in phase_rows if r["kind"] == "control" and int(r["window_start"]) == a], float)
            add_metric(f"{key}_{a}_{b}", nv, cv)

    # Renyi convergence summary using localization ratio control/near at each size.
    conv_summary = []
    for size in sorted(set(int(r["reference_size"]) for r in conv_rows)):
        for key in ("L2", "L4"):
            near_m = []
            ctrl_m = []
            # average convergence replicates within each trajectory, then across trajectories
            for kind, bucket in (("near", near_m), ("control", ctrl_m)):
                samples = sorted(set(int(r["sample"]) for r in conv_rows if r["kind"] == kind and int(r["reference_size"]) == size))
                for s in samples:
                    vv = [as_float(r[key]) for r in conv_rows if r["kind"] == kind and int(r["reference_size"]) == size and int(r["sample"]) == s]
                    bucket.append(float(np.nanmean(vv)))
            ratio = float(np.nanmean(ctrl_m) / (np.nanmean(near_m) + EPS))
            conv_summary.append({"reference_size": size, "metric": key,
                                 "near_mean": float(np.nanmean(near_m)), "control_mean": float(np.nanmean(ctrl_m)),
                                 "localization_ratio": ratio})
    write_csv(od / "renyi_convergence_summary.csv", conv_summary)
    for key in ("L2", "L4"):
        rr = [r for r in conv_summary if r["metric"] == key]
        rr = sorted(rr, key=lambda r: int(r["reference_size"]))
        if len(rr) >= 2:
            prev, last = float(rr[-2]["localization_ratio"]), float(rr[-1]["localization_ratio"])
            rel = abs(last - prev) / (abs(last) + EPS)
        else:
            rel = np.nan
        summary[f"renyi_{key}_last_reference_relative_change"] = rel
        summary[f"renyi_{key}_converged_5pct"] = bool(np.isfinite(rel) and rel <= 0.05)

    write_csv(od / "hypothesis_tests_raw.csv", hypothesis_rows)
    write_csv(od / "summary.csv", [summary])

    # Main diagnostic figures for this UPO.
    tnorm = times / T
    for col, ylabel, fname in [
        (0, "Product-state return fidelity", "return_fidelity_vs_time.png"),
        (1, "Phase-averaged tube projection", "tube_projection_vs_time.png"),
    ]:
        near_arr = np.asarray(time_series["near"], float)[:, :, col]
        ctrl_arr = np.asarray(time_series["control"], float)[:, :, col]
        plt.figure(figsize=(7, 4.8))
        for arr, label in ((ctrl_arr, "Invariant-matched control"), (near_arr, "Near UPO")):
            m = np.mean(arr, axis=0)
            se = np.std(arr, axis=0, ddof=1) / math.sqrt(max(1, len(arr)))
            plt.plot(tnorm, m, label=label)
            plt.fill_between(tnorm, m-se, m+se, alpha=.18)
        plt.xlabel(r"$t/T$")
        plt.ylabel(ylabel)
        plt.legend()
        plt.tight_layout()
        plt.savefig(od / fname, dpi=300)
        plt.close()

    # Revival timing plot.
    def parse_json_series(kind, key):
        rows = [r for r in dynrows if r["kind"] == kind]
        return np.array([json.loads(r[key]) for r in rows], float)
    pn = parse_json_series("near", "peaks_json")
    pc = parse_json_series("control", "peaks_json")
    plt.figure(figsize=(7, 4.8))
    ns = np.arange(1, min(20, pn.shape[1]) + 1)
    plt.plot(ns, np.nanmean(pc[:, :len(ns)], axis=0), marker="o", label="Invariant-matched control")
    plt.plot(ns, np.nanmean(pn[:, :len(ns)], axis=0), marker="o", label="Near UPO")
    plt.xlabel("Revival number n")
    plt.ylabel(r"Peak return fidelity near $nT$")
    plt.legend()
    plt.tight_layout()
    plt.savefig(od / "revival_peaks_vs_n.png", dpi=300)
    plt.close()

    # Renyi convergence plot.
    if conv_summary:
        plt.figure(figsize=(7, 4.8))
        for key in ("L2", "L4"):
            rr = sorted([r for r in conv_summary if r["metric"] == key], key=lambda r: int(r["reference_size"]))
            plt.plot([int(r["reference_size"]) for r in rr], [float(r["localization_ratio"]) for r in rr], marker="o", label=key)
        plt.axhline(1.0, ls="--")
        plt.xlabel("Invariant-sector reference points")
        plt.ylabel("Localization ratio (control / near)")
        plt.legend()
        plt.tight_layout()
        plt.savefig(od / "renyi_reference_convergence.png", dpi=300)
        plt.close()

    write_json(done, {"complete": True, "N": N, "orbit": oid, "time": time.time()})
    return {k: str(v) if isinstance(v, (dict, list)) else v for k, v in summary.items()}


# ---------------------------------------------------------------------------
# FTLE sector audit
# ---------------------------------------------------------------------------
def ftle_sector_audit(core, N, ndir):
    f = Path(ndir) / "chaos_ftle.csv"
    if not f.exists():
        return []
    rows = []
    for r in read_csv(f):
        try:
            A = [float(r["Z0"]), float(r["Phi0"])]
            A += [float(r[f"z{i+1}_0"]) for i in range(N)]
            A += [float(r[f"phi{i+1}_0"]) for i in range(N)]
            R = core.A_to_bloch(np.array(A, float))
            fp = invariant_fingerprint(core, R)
            rows.append({"N": N, "sample": int(r["sample"]), "ftle": float(r["ftle"]),
                         "S_norm": fp["S_norm"], "S_per_spin": fp["S_per_spin"],
                         "pair_dot_mean": fp["pair_dot_mean"], "sector_sha256": fp["sector_sha256"]})
        except Exception:
            pass
    write_csv(Path(ndir) / "chaos_ftle_with_collective_sector.csv", rows)
    if rows:
        x = np.array([r["S_per_spin"] for r in rows], float)
        y = np.array([r["ftle"] for r in rows], float)
        sp = spearmanr(x, y)
        write_json(Path(ndir) / "chaos_ftle_sector_correlation.json",
                   {"N": N, "rho": float(sp.statistic), "p_asymptotic": float(sp.pvalue), "n": len(rows)})
        plt.figure(figsize=(6.5, 4.5))
        plt.scatter(x, y)
        plt.xlabel(r"Collective environment length $|S|/N$")
        plt.ylabel("FTLE")
        plt.tight_layout()
        plt.savefig(Path(ndir) / "ftle_vs_collective_sector.png", dpi=300)
        plt.close()
    return rows


# ---------------------------------------------------------------------------
# Multiple testing + global aggregation
# ---------------------------------------------------------------------------
def apply_fdr(stdroot, Ns):
    tests = []
    for N in Ns:
        nd = Path(stdroot) / f"N{N}"
        for f in sorted(nd.glob("UPO*/hypothesis_tests_raw.csv")):
            tests.extend(read_csv(f))
    if not tests:
        return []
    p = np.array([as_float(r["raw_p"]) for r in tests], float)
    primary_mask = np.array([r["family"] == "primary" for r in tests])
    q_global = np.full(len(tests), np.nan)
    q_secondary = np.full(len(tests), np.nan)
    q_global[primary_mask] = bh_adjust(p[primary_mask])
    q_secondary[~primary_mask] = bh_adjust(p[~primary_mask])
    # Within each metric across all UPOs.
    q_metric = np.full(len(tests), np.nan)
    for metric in sorted(set(r["metric"] for r in tests)):
        idx = np.array([i for i, r in enumerate(tests) if r["metric"] == metric], int)
        q_metric[idx] = bh_adjust(p[idx])
    for i, r in enumerate(tests):
        r["q_global_family"] = q_global[i] if r["family"] == "primary" else q_secondary[i]
        r["q_within_metric"] = q_metric[i]
        r["significant_q05_global_family"] = bool(np.isfinite(r["q_global_family"]) and float(r["q_global_family"]) < .05)
        r["significant_q05_within_metric"] = bool(np.isfinite(r["q_within_metric"]) and float(r["q_within_metric"]) < .05)
    comp = Path(stdroot) / "COMPARISON"
    ensure(comp)
    write_csv(comp / "ALL_HYPOTHESIS_TESTS_FDR.csv", tests)
    write_csv(comp / "PRIMARY_HYPOTHESIS_TESTS_FDR.csv", [r for r in tests if r["family"] == "primary"])
    return tests


def _mean(rows, key):
    vals = np.array([as_float(r.get(key)) for r in rows], float)
    vals = vals[np.isfinite(vals)]
    return float(np.mean(vals)) if len(vals) else np.nan


def aggregate(root, stdroot, Ns, all_summaries, sector_rows, class_maps):
    comp = Path(stdroot) / "COMPARISON"
    ensure(comp)
    write_csv(comp / "STANDARD_METRICS_UPO_SECTOR_LEVEL.csv", all_summaries)
    write_csv(comp / "CHAOS_FTLE_SECTOR_ALL.csv", sector_rows)

    # Collective-family aggregation removes pseudoreplication from microscopic
    # invariant sectors realizing the same reduced central+S periodic mode.
    cf_rows = []
    for N in Ns:
        rr = [r for r in all_summaries if int(r["N"]) == N]
        classes = sorted(set(int(float(r["collective_class"])) for r in rr))
        for cid in classes:
            cc = [r for r in rr if int(float(r["collective_class"])) == cid]
            row = {"N": N, "collective_class": cid, "n_sector_realizations": len(cc)}
            keys = [
                "T", "S_norm", "S_per_spin", "lambda_max_over_omega", "heller_sum_over_2pi",
                "near_tube_P_2_20", "control_tube_P_2_20", "effect_tube_P_2_20",
                "near_tube_P_16_20", "control_tube_P_16_20", "effect_tube_P_16_20",
                "near_return_peak_1_5", "control_return_peak_1_5", "effect_return_peak_1_5",
                "near_F_harmonic_power", "control_F_harmonic_power", "effect_F_harmonic_power",
                "near_L2", "control_L2", "localization_ratio_L2",
                "near_L4", "control_L4", "localization_ratio_L4",
            ]
            for k in keys:
                row[k] = _mean(cc, k)
            cf_rows.append(row)
    write_csv(comp / "STANDARD_METRICS_COLLECTIVE_FAMILY_LEVEL.csv", cf_rows)

    # N-level: report BOTH sector-weighted and collective-family-weighted means.
    nrows = []
    for N in Ns:
        sr = [r for r in all_summaries if int(r["N"]) == N]
        cr = [r for r in cf_rows if int(r["N"]) == N]
        if not sr:
            continue
        row = {
            "N": N,
            "n_sector_upos": len(sr),
            "n_collective_families": len(cr),
            "mean_S_per_spin_sector": _mean(sr, "S_per_spin"),
            "mean_lambda_over_omega_collective": _mean(cr, "lambda_max_over_omega"),
            "mean_heller_sum_over_2pi_collective": _mean(cr, "heller_sum_over_2pi"),
            "mean_tube_P_16_20_sector": _mean(sr, "effect_tube_P_16_20"),
            "mean_tube_P_16_20_collective": _mean(cr, "effect_tube_P_16_20"),
            "mean_return_peak_1_5_collective": _mean(cr, "effect_return_peak_1_5"),
            "mean_F_harmonic_enh_collective": _mean(cr, "effect_F_harmonic_power"),
            "mean_Renyi_L2_localization_collective": _mean(cr, "localization_ratio_L2"),
            "mean_Renyi_L4_localization_collective": _mean(cr, "localization_ratio_L4"),
            "fraction_Renyi_L2_converged": float(np.mean([str(r.get("renyi_L2_converged_5pct", "False")).lower() == "true" for r in sr])),
        }
        nrows.append(row)
    write_csv(comp / "STANDARD_METRICS_N_LEVEL.csv", nrows)

    # FDR summary.
    tests = apply_fdr(stdroot, Ns)
    sig_rows = []
    for N in Ns:
        tt = [r for r in tests if int(r["N"]) == N and r["family"] == "primary"]
        by_metric = {}
        for r in tt:
            by_metric.setdefault(r["metric"], []).append(r)
        for metric, rr in sorted(by_metric.items()):
            sig = [str(r["significant_q05_global_family"]).lower() == "true" for r in rr]
            sig_rows.append({"N": N, "metric": metric, "n_tests": len(rr), "fraction_significant_global_FDR": float(np.mean(sig))})
    write_csv(comp / "PRIMARY_FDR_SIGNIFICANCE_BY_N.csv", sig_rows)

    # Exact N-level trend statistics; five N points are not treated with a
    # misleading asymptotic p-value.
    trends = {}
    xN = np.array([r["N"] for r in nrows], float)
    for key in (
        "mean_heller_sum_over_2pi_collective",
        "mean_tube_P_16_20_collective",
        "mean_return_peak_1_5_collective",
        "mean_Renyi_L2_localization_collective",
    ):
        y = np.array([as_float(r[key]) for r in nrows], float)
        trends[key] = exact_permutation_spearman(xN, y)
    write_json(comp / "N_LEVEL_EXACT_PERMUTATION_TRENDS.json", trends)

    # Orbit-level descriptive correlations, with explicit pseudoreplication caveat.
    corr = {}
    if cf_rows:
        for xk, yk, name in [
            ("lambda_max_over_omega", "effect_tube_P_16_20", "instability_vs_tube_localization"),
            ("lambda_max_over_omega", "effect_return_peak_1_5", "instability_vs_revival"),
            ("S_per_spin", "effect_tube_P_16_20", "collective_sector_vs_tube_localization"),
        ]:
            x = np.array([as_float(r.get(xk)) for r in cf_rows], float)
            y = np.array([as_float(r.get(yk)) for r in cf_rows], float)
            ok = np.isfinite(x) & np.isfinite(y)
            if np.sum(ok) >= 3:
                sp = spearmanr(x[ok], y[ok])
                corr[name] = {"rho": float(sp.statistic), "p_asymptotic": float(sp.pvalue), "n_collective_families": int(np.sum(ok)),
                              "caveat": "collective-family samples are not independent system sizes"}
    write_json(comp / "COLLECTIVE_FAMILY_CORRELATIONS.json", corr)

    # Core cross-N figures.
    plots = [
        ("mean_heller_sum_over_2pi_collective", r"Mean $\Lambda_+T/(2\pi)$", "heller_generalized_vs_N.png"),
        ("mean_tube_P_16_20_collective", "Invariant-matched tube scar measure (16-20T)", "tube_scar_measure_vs_N.png"),
        ("mean_return_peak_1_5_collective", "Return-revival enhancement (1-5T)", "return_revival_vs_N.png"),
        ("mean_Renyi_L2_localization_collective", r"$L_2$ localization ratio (control/near)", "renyi_L2_vs_N.png"),
    ]
    for key, ylabel, fn in plots:
        plt.figure(figsize=(6.5, 4.5))
        plt.plot([r["N"] for r in nrows], [as_float(r[key]) for r in nrows], marker="o")
        plt.xlabel("Environment size N")
        plt.ylabel(ylabel)
        plt.tight_layout()
        plt.savefig(comp / fn, dpi=300)
        plt.close()

    # Heatmap of primary FDR significance fractions.
    metrics = list(PRIMARY_METRICS)
    mat = np.full((len(Ns), len(metrics)), np.nan)
    for i, N in enumerate(Ns):
        for j, m in enumerate(metrics):
            rr = [r for r in sig_rows if int(r["N"]) == N and r["metric"] == m]
            if rr:
                mat[i, j] = as_float(rr[0]["fraction_significant_global_FDR"])
    plt.figure(figsize=(12, 4.5))
    im = plt.imshow(mat, aspect="auto", vmin=0, vmax=1)
    plt.yticks(range(len(Ns)), [str(n) for n in Ns])
    plt.xticks(range(len(metrics)), metrics, rotation=55, ha="right")
    plt.xlabel("Preregistered primary metric")
    plt.ylabel("N")
    plt.colorbar(im, label="Fraction of UPO-sector realizations significant after global primary FDR")
    plt.tight_layout()
    plt.savefig(comp / "primary_standard_metrics_FDR_heatmap.png", dpi=300)
    plt.close()

    # Human-readable report.
    report = []
    report.append("FINAL LITERATURE-ALIGNED UPO-SCARRING DIAGNOSTICS\n\n")
    report.append("This analysis uses invariant-matched controls. Generic same-energy controls are not the primary baseline because homogeneous environment TLSs have an exactly conserved rigid internal configuration.\n\n")
    report.append("CRUCIAL MODEL STRUCTURE: the environment reduces exactly to a collective vector S for the active dynamics; internal pairwise and oriented-triple relations are constants of motion. Therefore N should not be described as simply increasing the number of active classical degrees of freedom. The manuscript should discuss finite-environment / collective-sector dependence, and should aggregate repeated microscopic sectors that realize the same collective UPO family.\n\n")
    report.append("Primary literature-aligned metrics: Heller lambda/omega and generalized Floquet instability; phase-averaged periodic-orbit tube projection normalized to invariant-matched controls; product-state return-fidelity revivals and peak timing at nT; Fourier weight at the UPO frequency/harmonics; microcanonical invariant-sector Renyi occupations L2/L4 with convergence tests. Existing C/R metrics remain secondary.\n\n")
    report.append("Multiple testing: all preregistered primary UPO-level tests are Benjamini-Hochberg corrected together; within-metric q values are also provided. Use q values, effect sizes, and bootstrap CIs in the manuscript rather than raw p values alone.\n\n")
    report.append("Do not call these conventional scarred eigenstates unless a separate fixed linear Hamiltonian/eigenspectrum is constructed. Recommended framing: dynamical UPO-associated localization/scarring in a nonlinear quantum mean-field model.\n\n")
    report.append("N-LEVEL COLLECTIVE-FAMILY-WEIGHTED SUMMARY\n")
    for r in nrows:
        report.append(json.dumps(_san(r), sort_keys=True) + "\n")
    report.append("\nEXACT N-LEVEL PERMUTATION SPEARMAN TESTS\n")
    report.append(json.dumps(_san(trends), indent=2) + "\n")
    with open(comp / "FINAL_STANDARD_METRICS_REPORT.txt", "w", encoding="utf-8") as f:
        f.writelines(report)

    # Methods metadata for reproducibility.
    write_json(comp / "METRIC_DEFINITIONS.json", {
        "tube_projection": "Q_O(t)=mean_phase prod_k[(1+r_k(t).r_k^O(phi))/2]",
        "tube_scar_measure": "P_matched=<Q_O>_near/<Q_O>_invariant-matched-control",
        "return_fidelity": "F(t)=prod_k[(1+r_k(0).r_k(t))/2]",
        "renyi_occupation": "L_alpha=(<q^alpha>/<q>^alpha)^(1/(1-alpha)); L1 is alpha->1 limit; reference points are independently sampled from the exact fixed-energy invariant-sector microcanonical measure",
        "heller_lambda_over_omega": "lambda_max/(2*pi/T)",
        "generalized_heller": "sum_positive_lambda/(2*pi/T)",
        "control_sector": "same full environment configuration up to common SO(3), exact target energy with central epsilon included",
        "FDR": "Benjamini-Hochberg across all preregistered primary UPO-level hypotheses, plus within-metric BH",
    })


def manifest(root):
    root = Path(root)
    rows = []
    for f in sorted(root.rglob("*")):
        if f.is_file() and f.name != "MANIFEST_SHA256.csv":
            try:
                h = hashlib.sha256()
                with open(f, "rb") as fh:
                    for chunk in iter(lambda: fh.read(1024*1024), b""):
                        h.update(chunk)
                rows.append({"relative_path": str(f.relative_to(root)), "bytes": f.stat().st_size, "sha256": h.hexdigest()})
            except Exception:
                pass
    write_csv(root / "MANIFEST_SHA256.csv", rows)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description="Literature-aligned, invariant-matched scar diagnostics for the epsilon=1 N=2,4,6,8,10 dataset.",
        epilog="""Example:\n  python3 6.1b_CODE_central_bias_localization_metrics.py --root /path/to/SECTION61_RESULTS --core /path/to/6.1a_CODE_central_bias_core.py\n""",
    )
    ap.add_argument("--root", required=True)
    ap.add_argument("--core", required=True)
    ap.add_argument("--Ns", default="2,4,6,8,10")
    ap.add_argument("--near", type=int, default=24)
    ap.add_argument("--controls", type=int, default=48)
    ap.add_argument("--periods", type=int, default=20)
    ap.add_argument("--ppp", type=int, default=60)
    ap.add_argument("--phase-points", type=int, default=360)
    ap.add_argument("--renyi-stride", type=int, default=6)
    ap.add_argument("--reference-points", type=int, default=1800)
    ap.add_argument("--renyi-reference-sizes", default="600,1200,1800")
    ap.add_argument("--renyi-convergence-reps", type=int, default=5)
    ap.add_argument("--near-amplitude", type=float, default=1e-4)
    ap.add_argument("--control-max-tube", type=float, default=.20)
    ap.add_argument("--bootstrap", type=int, default=2000)
    ap.add_argument("--collective-phase-points", type=int, default=360)
    ap.add_argument("--seed", type=int, default=927311)
    ap.add_argument("--quick", action="store_true")
    args = ap.parse_args()

    args.renyi_reference_sizes = [int(x) for x in str(args.renyi_reference_sizes).split(",") if x.strip()]
    if args.quick:
        args.near = 1
        args.controls = 2
        args.periods = 20
        args.ppp = 6
        args.phase_points = 40
        args.renyi_stride = 4
        args.reference_points = 40
        args.renyi_reference_sizes = [20, 40]
        args.renyi_convergence_reps = 2
        args.bootstrap = 50
        args.control_max_tube = .65
        args.collective_phase_points = 60
    elif args.periods < 20:
        raise ValueError("Full analysis requires at least 20 periods")

    root = Path(args.root)
    core = load_core(args.core)
    Ns = [int(x) for x in str(args.Ns).split(",")]
    stdroot = root / "FINAL_STANDARD_METRICS"
    ensure(stdroot)

    all_summaries = []
    sector_rows = []
    class_maps = {}

    for N in Ns:
        print("\n" + "="*82)
        print(f"N={N}: FINAL LITERATURE-ALIGNED / INVARIANT-MATCHED ANALYSIS")
        print("="*82, flush=True)
        core.set_model(N)
        ndir = root / f"N{N}"
        out = stdroot / f"N{N}"
        ensure(out)
        upopath = ndir / "selected_independent_upos.csv"
        if not upopath.exists():
            raise FileNotFoundError(upopath)
        upos = core.load_orbits(upopath)
        if len(upos) < 4:
            raise RuntimeError(f"N={N}: expected >=4 selected UPOs, found {len(upos)}")
        upos = upos[:4]
        target = core.target_energy_for_n(N)

        # Collective-family classification BEFORE treating UPO rows as samples.
        cmap, _, _ = classify_collective_families(core, upos, out, points=args.collective_phase_points)
        class_maps[N] = cmap
        sector_rows.extend(ftle_sector_audit(core, N, ndir))

        for oid, orbit in enumerate(upos):
            rng = np.random.default_rng(args.seed + 100000*N + oid)
            row = analyze_upo(core, N, oid, orbit, target, out, args, rng, cmap[oid])
            all_summaries.append(row)

    aggregate(root, stdroot, Ns, all_summaries, sector_rows, class_maps)
    write_json(stdroot / "RUN_CONFIG.json", vars(args))
    manifest(stdroot)
    print("\nFINAL STANDARD METRICS ANALYSIS COMPLETE", flush=True)
    print("Report:", stdroot / "COMPARISON" / "FINAL_STANDARD_METRICS_REPORT.txt", flush=True)
    print("Manifest:", stdroot / "MANIFEST_SHA256.csv", flush=True)


if __name__ == "__main__":
    main()
