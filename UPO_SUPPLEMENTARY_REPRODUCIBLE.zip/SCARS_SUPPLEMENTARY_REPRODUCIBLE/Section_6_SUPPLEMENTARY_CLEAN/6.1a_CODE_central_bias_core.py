#!/usr/bin/env python3
"""
Numerical core for Section 6.1: central-bias robustness test.

Model used by the final Section 6.1 analysis:
    central epsilon = 1,
    environmental Ei = 0,
    delta = Di = Lambda = 1,
    N = 2, 4, 6, 8, 10,
    fixed energy density E/(N+1) = 2.511352169911679/3.

This file provides the full-system dynamics, tangent dynamics, energy-shell
sampling, periodic-orbit search/refinement and common numerical utilities used
by the production driver.  It is a library component of the final pipeline;
the publication workflow is launched through
6.1c_CODE_central_bias_perN_pipeline.py.

For epsilon=1, parity P and PT are broken and are not admitted as orbit
equivalences in the final production driver.  Final UPO independence is audited
in the exact collective reduction using continuous phase alignment and time
reversal only (plus the physically redundant permutations of identical
environment TLSs at the microscopic level).
"""

# Thread limits must be set before importing NumPy/BLAS.
import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

import argparse
import csv
import hashlib
import json
import math
import platform
import shutil
import signal
import sys
import time
import traceback
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from itertools import product
from pathlib import Path

import numpy as np
import scipy
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from scipy.integrate import solve_ivp
from scipy.optimize import brentq, least_squares, linear_sum_assignment, minimize_scalar
from scipy.spatial import cKDTree
from scipy.stats import wilcoxon, mannwhitneyu, spearmanr


# ============================================================================
# GLOBAL MODEL / NUMERICAL CONSTANTS
# ============================================================================

epsilon = 1.0
delta = 1.0
Ei = 0.0
Di = 1.0
Lambda = 1.0

REFERENCE_N2_ENERGY = 2.511352169911679
REFERENCE_ENERGY_DENSITY = REFERENCE_N2_ENERGY / 3.0
ALPHA = 0.05
MASTER_SEED = 20260923

# These are changed by set_model(N) before every N-specific stage.
N = None
M = None
BLOCH_DIM = None
PHYS_DIM = None

STANDARD_WINDOWS = [(2, 6), (6, 10), (10, 16)]
FINE_WINDOWS = [(2,4), (4,6), (6,8), (8,10), (10,12), (12,14),
                (14,16), (16,18), (18,20)]
PERTURBATION_SCALES = [1e-5, 1e-4, 1e-3]


class CandidateAbort(RuntimeError):
    pass


_INTERRUPTION_FILE = None


def utcnow():
    return datetime.now(timezone.utc).isoformat()


def p(*args):
    print(*args, flush=True)


def set_model(n):
    global N, M, BLOCH_DIM, PHYS_DIM
    N = int(n)
    M = N + 1
    BLOCH_DIM = 3 * M
    PHYS_DIM = 2 * M


def target_energy_for_n(n):
    return REFERENCE_ENERGY_DENSITY * (int(n) + 1)


def ensure_dir(path):
    Path(path).mkdir(parents=True, exist_ok=True)


def _json_sanitize(obj):
    if isinstance(obj, dict):
        return {str(k): _json_sanitize(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_json_sanitize(v) for v in obj]
    if isinstance(obj, np.generic):
        obj = obj.item()
    if isinstance(obj, float) and not np.isfinite(obj):
        return None
    return obj

def write_json(path, obj):
    path = Path(path)
    ensure_dir(path.parent)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(_json_sanitize(obj), f, indent=2, allow_nan=False)
    os.replace(tmp, path)


def read_json(path, default=None):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def stage_marker(outdir, stage):
    return Path(outdir) / f".{stage}.done.json"


def mark_stage(outdir, stage, payload=None):
    data = {"stage": stage, "completed_utc": utcnow()}
    if payload:
        data.update(payload)
    write_json(stage_marker(outdir, stage), data)


def stage_done(outdir, stage):
    return stage_marker(outdir, stage).exists()


def safe_wilcoxon(diff, alternative="greater"):
    diff = np.asarray(diff, dtype=float)
    diff = diff[np.isfinite(diff)]
    if len(diff) == 0 or np.all(np.abs(diff) < 1e-15):
        return 1.0
    try:
        return float(wilcoxon(diff, alternative=alternative, zero_method="wilcox").pvalue)
    except Exception:
        return 1.0


def safe_mannwhitney(x, y, alternative="greater"):
    x = np.asarray(x, float); y = np.asarray(y, float)
    x = x[np.isfinite(x)]; y = y[np.isfinite(y)]
    if len(x) == 0 or len(y) == 0:
        return 1.0
    try:
        return float(mannwhitneyu(x, y, alternative=alternative).pvalue)
    except Exception:
        return 1.0


def bootstrap_mean_ci(values, rng, nboot=2000, level=0.95):
    x = np.asarray(values, float)
    x = x[np.isfinite(x)]
    if len(x) == 0:
        return (np.nan, np.nan, np.nan)
    if len(x) == 1:
        return (float(x[0]), float(x[0]), float(x[0]))
    idx = rng.integers(0, len(x), size=(nboot, len(x)))
    means = x[idx].mean(axis=1)
    a = (1-level)/2
    return (float(np.mean(x)), float(np.quantile(means, a)),
            float(np.quantile(means, 1-a)))


def atomic_csv(path, fieldnames, rows):
    path = Path(path)
    ensure_dir(path.parent)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        for row in rows:
            w.writerow(row)
    os.replace(tmp, path)


def read_csv(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def interruption_handler(signum, frame):
    global _INTERRUPTION_FILE
    try:
        if _INTERRUPTION_FILE:
            write_json(_INTERRUPTION_FILE, {
                "interrupted_utc": utcnow(),
                "signal": int(signum),
                "message": "Safe interruption marker. Re-submit the same command to resume."
            })
    finally:
        raise SystemExit(128 + int(signum))


signal.signal(signal.SIGTERM, interruption_handler)
signal.signal(signal.SIGINT, interruption_handler)


# ============================================================================
# CONFIGURATION -- FINAL N=2,4,6,8,10 ARTICLE RUN
# ============================================================================

SCHEMA_VERSION = "N246810_EPS1_COLLECTIVE_V1"
REQUIRED_INDEPENDENT_UPOS_DEFAULT = 4


class SearchIncomplete(RuntimeError):
    """Raised only after all current search work is checkpointed safely."""


def config_for_n(n, quick=False, required_upos=REQUIRED_INDEPENDENT_UPOS_DEFAULT):
    n = int(n)
    if quick:
        return {
            "CHAOS_SAMPLES": 4, "FTLE_TIME": 10.0, "FTLE_CHUNKS": 10,
            "COARSE_TRAJECTORIES_PER_EPOCH": 2, "COARSE_TIME": 90.0, "COARSE_DT": 0.35,
            "T_MIN": 4.0, "T_MAX": 70.0, "COARSE_RADIUS": 1.25,
            "CANDIDATES_PER_TRAJECTORY": 8, "CANDIDATES_PER_EPOCH": 14,
            "MAX_NFEV": 35, "POLISH_NFEV": 20,
            "MAX_RESIDUAL_CALLS": 180, "STAGNATION_CALLS": 80,
            "PERIODIC_TOL": 2e-5, "ENERGY_TOL_ORBIT": 2e-6,
            "MIN_EXCURSION": 0.04, "REQUIRED_INDEPENDENT_UPOS": max(1, min(required_upos,2)),
            "CLEAR_UPO_RHO": 1.05, "SEARCH_BUDGET_HOURS": 0.12,
            "DEDUP_PHASE_POINTS": 180, "DEDUP_VERIFY_POINTS": 24,
            "DEDUP_COARSE_SHIFTS": 36, "DEDUP_PERIOD_REL_TOL": 5e-4,
            "DEDUP_RMS_TOL": 6e-2, "DEDUP_MAX_TOL": 1.8e-1,
            "N_NEAR": 3, "N_GENERIC": 4, "N_PERIODS": 6,
            "POINTS_PER_PERIOD": 20, "PHASE_POINTS": 90,
            "N_SURROGATES": 20, "PERTURBATION_SCALE": 1e-4,
            "ROBUSTNESS_SAMPLES": 2,
            "FLOQUET_DET_TOL": 5e-2, "FLOQUET_RECIP_TOL": 8e-2,
        }

    # Deliberately generous CPU budgets. The search exits only after the required
    # number of symmetry-inequivalent hyperbolic families is reached. If a Slurm
    # wall-time interrupts it, every accepted orbit and every processed candidate
    # is already checkpointed and the exact same command resumes the search.
    table = {
        2: dict(CHAOS_SAMPLES=48, COARSE_TRAJECTORIES_PER_EPOCH=18,
                COARSE_TIME=1700.0, COARSE_DT=0.16, T_MAX=260.0,
                CANDIDATES_PER_EPOCH=180, SEARCH_BUDGET_HOURS=18.0),
        4: dict(CHAOS_SAMPLES=56, COARSE_TRAJECTORIES_PER_EPOCH=22,
                COARSE_TIME=2300.0, COARSE_DT=0.18, T_MAX=320.0,
                CANDIDATES_PER_EPOCH=220, SEARCH_BUDGET_HOURS=24.0),
        6: dict(CHAOS_SAMPLES=64, COARSE_TRAJECTORIES_PER_EPOCH=28,
                COARSE_TIME=3100.0, COARSE_DT=0.20, T_MAX=390.0,
                CANDIDATES_PER_EPOCH=260, SEARCH_BUDGET_HOURS=36.0),
        8: dict(CHAOS_SAMPLES=72, COARSE_TRAJECTORIES_PER_EPOCH=34,
                COARSE_TIME=4100.0, COARSE_DT=0.22, T_MAX=470.0,
                CANDIDATES_PER_EPOCH=320, SEARCH_BUDGET_HOURS=52.0),
        10: dict(CHAOS_SAMPLES=80, COARSE_TRAJECTORIES_PER_EPOCH=42,
                 COARSE_TIME=5200.0, COARSE_DT=0.24, T_MAX=560.0,
                 CANDIDATES_PER_EPOCH=380, SEARCH_BUDGET_HOURS=84.0),
    }
    t = table[n].copy()
    t.update({
        "FTLE_TIME": 140.0, "FTLE_CHUNKS": 140,
        "T_MIN": 5.0, "COARSE_RADIUS": 1.10,
        "CANDIDATES_PER_TRAJECTORY": 55,
        "MAX_NFEV": 320, "POLISH_NFEV": 190,
        "MAX_RESIDUAL_CALLS": 1200 + 50*n,
        "STAGNATION_CALLS": 420 + 20*n,
        "PERIODIC_TOL": 2e-7, "ENERGY_TOL_ORBIT": 2e-8,
        "MIN_EXCURSION": 0.08,
        "REQUIRED_INDEPENDENT_UPOS": int(required_upos),
        "CLEAR_UPO_RHO": 1.05,
        # Equivalence is tested after exact symmetry validation. The period gate
        # is intentionally tight because P/T/permutation/phase copies have the
        # same fundamental period; same-period but geometrically distinct orbits
        # are still retained by the trajectory-distance test.
        "DEDUP_PHASE_POINTS": 720,
        "DEDUP_VERIFY_POINTS": 72,
        "DEDUP_COARSE_SHIFTS": 96,
        "DEDUP_PERIOD_REL_TOL": 1e-4,
        "DEDUP_RMS_TOL": 2.0e-2,
        "DEDUP_MAX_TOL": 6.0e-2,
        "N_NEAR": 24,
        "N_GENERIC": 48,
        "N_PERIODS": 20,
        "POINTS_PER_PERIOD": 60,
        "PHASE_POINTS": 360,
        "N_SURROGATES": 500,
        "PERTURBATION_SCALE": 1e-4,
        "ROBUSTNESS_SAMPLES": 10,
        "FLOQUET_DET_TOL": 2e-2,
        "FLOQUET_RECIP_TOL": 3e-2,
    })
    return t


def classical_energy_bounds(n):
    """Exact classical energy bounds for the current homogeneous model.

    For fixed central z=Z, the central x component and every identical
    environment spin can align independently with their local energy fields.
    This reduces the global minimum/maximum search to a one-dimensional
    bounded optimization in Z and remains valid for nonzero central epsilon.
    """
    n=int(n)
    def env_norm(z):
        return math.sqrt((2*Di)**2 + (2*Ei + Lambda*z)**2)
    def emax_at_z(z):
        s=max(0.0,1.0-z*z)**0.5
        return 2*delta*s + 2*epsilon*z + n*env_norm(z)
    def emin_at_z(z):
        s=max(0.0,1.0-z*z)**0.5
        return -2*delta*s + 2*epsilon*z - n*env_norm(z)
    rmax=minimize_scalar(lambda z:-emax_at_z(z),bounds=(-1.0,1.0),method="bounded",
                         options={"xatol":1e-14})
    rmin=minimize_scalar(emin_at_z,bounds=(-1.0,1.0),method="bounded",
                         options={"xatol":1e-14})
    return float(rmin.fun), float(-rmax.fun), float(rmax.x)


def energy_shell_diagnostics(n,target_energy):
    emin,emax,zstar=classical_energy_bounds(n)
    return {
        "N":int(n), "M":int(n)+1, "target_energy":float(target_energy),
        "energy_density":float(target_energy/(int(n)+1)),
        "Emin":emin, "Emax":emax, "E_over_Emax":float(target_energy/emax),
        "fraction_from_Emin":float((target_energy-emin)/(emax-emin)),
        "z_at_Emax":zstar,
    }

# ============================================================================
# MODEL: ACTION-ANGLE <-> BLOCH, EOM, JACOBIAN, ENERGY
# ============================================================================


def single_bloch(z, phi):
    s = np.sqrt(max(1.0 - z*z, 0.0))
    return np.array([s*np.cos(phi), s*np.sin(phi), z], dtype=float)


def A_to_bloch(A):
    R = list(single_bloch(A[0], A[1]))
    for i in range(N):
        R.extend(single_bloch(A[2+i], A[2+N+i]))
    return np.asarray(R, dtype=float)


def bloch_to_A(R):
    Z = float(R[2]); Phi = float(np.arctan2(R[1], R[0]))
    zs=[]; phis=[]
    for i in range(N):
        j=3+3*i
        zs.append(float(R[j+2]))
        phis.append(float(np.arctan2(R[j+1], R[j])))
    return np.array([Z,Phi,*zs,*phis],float)


def normalize_state(R):
    R=np.asarray(R,float).copy()
    for k in range(M):
        j=3*k; nr=np.linalg.norm(R[j:j+3])
        if nr < 1e-300:
            raise ValueError("zero Bloch vector")
        R[j:j+3] /= nr
    return R


def bloch_rhs(t,R):
    dR=np.zeros_like(R)
    x0,y0,Z=R[:3]
    env_z=np.array([R[3+3*i+2] for i in range(N)])
    Om0=2*epsilon + Lambda*np.sum(env_z)
    dR[0]=-Om0*y0
    dR[1]= Om0*x0 + 2*delta*Z
    dR[2]=-2*delta*y0
    for i in range(N):
        j=3+3*i; x,y,z=R[j:j+3]
        Omi=2*Ei + Lambda*Z
        dR[j]=-Omi*y
        dR[j+1]=Omi*x + 2*Di*z
        dR[j+2]=-2*Di*y
    return dR


def bloch_jacobian(R):
    J=np.zeros((BLOCH_DIM,BLOCH_DIM),float)
    x0,y0,Z=R[:3]
    env_z=np.array([R[3+3*i+2] for i in range(N)])
    Om0=2*epsilon + Lambda*np.sum(env_z)
    J[0,1]=-Om0
    J[1,0]= Om0; J[1,2]=2*delta
    J[2,1]=-2*delta
    for i in range(N):
        zi=3+3*i+2
        J[0,zi]=-Lambda*y0
        J[1,zi]= Lambda*x0
    for i in range(N):
        j=3+3*i; x,y,z=R[j:j+3]
        Omi=2*Ei + Lambda*Z
        J[j,j+1]=-Omi; J[j,2]=-Lambda*y
        J[j+1,j]=Omi; J[j+1,j+2]=2*Di; J[j+1,2]=Lambda*x
        J[j+2,j+1]=-2*Di
    return J


def energy_bloch(R):
    x0,y0,Z=R[:3]
    H=-2*delta*x0 + 2*epsilon*Z
    sz=0.0
    for i in range(N):
        j=3+3*i; x,y,z=R[j:j+3]
        H += -2*Di*x + 2*Ei*z
        sz += z
    H += Lambda*Z*sz
    return float(H)


def energy_A(A):
    return energy_bloch(A_to_bloch(A))


def energy_gradient(R):
    g=np.zeros_like(R); Z=R[2]
    env_z=np.array([R[3+3*i+2] for i in range(N)])
    g[0]=-2*delta; g[2]=2*epsilon + Lambda*np.sum(env_z)
    for i in range(N):
        j=3+3*i
        g[j]=-2*Di
        g[j+2]=2*Ei + Lambda*Z
    return g


def tangent_basis(R):
    B=np.zeros((BLOCH_DIM,PHYS_DIM),float)
    for k in range(M):
        j=3*k; r=R[j:j+3]/np.linalg.norm(R[j:j+3])
        ref=np.array([0.,0.,1.]) if abs(r[2])<0.9 else np.array([1.,0.,0.])
        e1=np.cross(ref,r); e1/=np.linalg.norm(e1)
        e2=np.cross(r,e1); e2/=np.linalg.norm(e2)
        B[j:j+3,2*k]=e1; B[j:j+3,2*k+1]=e2
    return B


def canonical_symplectic_matrix():
    S=np.zeros((PHYS_DIM,PHYS_DIM),float)
    J2=np.array([[0.,1.],[-1.,0.]])
    for k in range(M): S[2*k:2*k+2,2*k:2*k+2]=J2
    return S


# ============================================================================
# SAME-ENERGY SAMPLING
# ============================================================================


def _random_unit_vector(rng):
    v=rng.normal(size=3)
    n=np.linalg.norm(v)
    if n<1e-14:
        return _random_unit_vector(rng)
    return v/n


def central_energy_circle_for_environment(env,target_energy):
    """Return the central-spin energy circle for a fixed environment.

    With S=sum_i r_i, H_env=-2*Di*Sx+2*Ei*Sz and
    h0=(-2*delta,0,2*epsilon+Lambda*Sz), the constraint is h0.r0=c.
    The intersection with |r0|=1 is a circle whenever |c|<=|h0|.
    """
    env=np.asarray(env,float).reshape(N,3)
    S=np.sum(env,axis=0)
    h=np.array([-2*delta,0.0,2*epsilon+Lambda*S[2]],float)
    hn=float(np.linalg.norm(h))
    Henv=float(-2*Di*S[0]+2*Ei*S[2])
    c=float(target_energy-Henv)
    if hn<1e-14 or abs(c)>hn+2e-12:
        return None
    d=float(np.clip(c/hn,-1.0,1.0))
    n=h/hn
    rad=math.sqrt(max(0.0,1.0-d*d))
    return n,d,rad


def _point_on_energy_circle(env,target_energy,rng):
    ec=central_energy_circle_for_environment(env,target_energy)
    if ec is None:return None
    n,d,rad=ec
    # Stable orthonormal basis of the plane perpendicular to n.
    axes=np.eye(3); a=axes[int(np.argmin(np.abs(axes@n)))]
    u=a-np.dot(a,n)*n; u/=np.linalg.norm(u)
    v=np.cross(n,u); v/=np.linalg.norm(v)
    ang=float(rng.uniform(0,2*np.pi))
    r=d*n+rad*(math.cos(ang)*u+math.sin(ang)*v)
    return r/np.linalg.norm(r)


def roots_for_Z(zs,phis,target_energy,grid_points=260):
    """Legacy helper retained for refinement/debugging; not used by the sampler."""
    def f(Z):
        return energy_A(np.array([Z,0.0,*zs,*phis],float))-target_energy
    grid=np.linspace(-0.99,0.99,grid_points)
    vals=np.array([f(z) for z in grid])
    roots=[]
    for k in range(len(grid)-1):
        a,b=grid[k],grid[k+1]; fa,fb=vals[k],vals[k+1]
        if not np.isfinite(fa+fb): continue
        if abs(fa)<1e-11: roots.append(a)
        if fa*fb<0:
            try: roots.append(brentq(f,a,b,xtol=1e-13,rtol=1e-13))
            except Exception: pass
    uniq=[]
    for r in roots:
        if all(abs(r-u)>1e-7 for u in uniq): uniq.append(r)
    return uniq


def random_same_energy_A(rng,target_energy,max_attempts=20000):
    """Robust exact-energy sampler valid for epsilon != 0.

    Environment Bloch vectors are drawn isotropically. Conditional on the
    environment, the central state is drawn uniformly on the exact energy
    circle. This avoids the epsilon=0-specific Phi=0 root construction and
    gives machine-precision energy matching over all N used in the article.
    """
    for _ in range(max_attempts):
        env=np.array([_random_unit_vector(rng) for _ in range(N)],float)
        c=_point_on_energy_circle(env,target_energy,rng)
        if c is None:continue
        R=np.vstack([c,env]).reshape(-1)
        if abs(energy_bloch(R)-target_energy)<5e-10:
            return bloch_to_A(R)
    raise RuntimeError("could not sample requested energy shell with exact central energy circle")


# ============================================================================
# INTEGRATION / FTLE / ENERGY DRIFT
# ============================================================================


def integrate_final(R0,T,rtol=2e-10,atol=1e-11):
    sol=solve_ivp(bloch_rhs,(0,float(T)),R0,method="DOP853",rtol=rtol,atol=atol)
    return sol.y[:,-1] if sol.success else None


def integrate_grid(R0,total_time,nt,rtol=2e-9,atol=1e-11):
    tt=np.linspace(0,float(total_time),int(nt))
    sol=solve_ivp(bloch_rhs,(0,float(total_time)),R0,method="DOP853",
                  t_eval=tt,rtol=rtol,atol=atol)
    if not sol.success: raise RuntimeError(sol.message)
    return sol.t,sol.y.T


def energy_drift(traj):
    Es=np.array([energy_bloch(r) for r in traj])
    return float(np.max(np.abs(Es-Es[0]))), float(Es[0]), float(Es[-1])


def ftle_one_vector(R0,rng,total_time,chunks):
    B=tangent_basis(R0)
    v=B@ (lambda q:q/np.linalg.norm(q))(rng.normal(size=PHYS_DIM))
    R=R0.copy(); acc=0.0; dt=total_time/chunks
    def rhs(t,Y):
        rr=Y[:BLOCH_DIM]; vv=Y[BLOCH_DIM:]
        return np.concatenate([bloch_rhs(t,rr),bloch_jacobian(rr)@vv])
    for _ in range(chunks):
        sol=solve_ivp(rhs,(0,dt),np.concatenate([R,v]),method="DOP853",
                      rtol=2e-9,atol=1e-11)
        if not sol.success: return np.nan
        yf=sol.y[:,-1]; R=normalize_state(yf[:BLOCH_DIM]); v=yf[BLOCH_DIM:]
        for k in range(M):
            j=3*k; r=R[j:j+3]
            v[j:j+3]-=np.dot(v[j:j+3],r)*r
        nv=np.linalg.norm(v)
        if nv<1e-300: return -np.inf
        acc += np.log(nv); v/=nv
    return float(acc/total_time)


# ============================================================================
# FLOQUET -- canonical cross-check + Bloch fallback
# ============================================================================


def variational_rhs(t,Y):
    R=Y[:BLOCH_DIM]
    MM=Y[BLOCH_DIM:].reshape(BLOCH_DIM,BLOCH_DIM)
    return np.concatenate([bloch_rhs(t,R),(bloch_jacobian(R)@MM).ravel()])


def _canonical_from_bloch(R):
    u=np.empty(PHYS_DIM,float)
    for k in range(M):
        j=3*k
        u[2*k]=float(np.clip(R[j+2],-0.999999999999,0.999999999999))
        u[2*k+1]=float(np.arctan2(R[j+1],R[j]))
    return u


def _bloch_from_canonical(u):
    R=np.empty(BLOCH_DIM,float)
    for k in range(M):
        z=float(u[2*k]); ph=float(u[2*k+1]); s=math.sqrt(max(0.0,1-z*z))
        R[3*k:3*k+3]=(s*math.cos(ph),s*math.sin(ph),z)
    return R


def _canonical_rhs(t,u):
    du=np.zeros_like(u)
    Z,Phi=u[0],u[1]
    envz=np.array([u[2*(i+1)] for i in range(N)])
    s0=math.sqrt(max(1e-20,1-Z*Z))
    du[0]=-2*delta*s0*math.sin(Phi)
    du[1]=2*epsilon + 2*delta*(Z/s0)*math.cos(Phi) + Lambda*np.sum(envz)
    for i in range(N):
        k=2*(i+1); z,ph=u[k],u[k+1]; s=math.sqrt(max(1e-20,1-z*z))
        du[k]=-2*Di*s*math.sin(ph)
        du[k+1]=2*Ei + 2*Di*(z/s)*math.cos(ph) + Lambda*Z
    return du


def _canonical_jacobian(u):
    J=np.zeros((PHYS_DIM,PHYS_DIM),float)
    Z,Phi=u[0],u[1]; s0=math.sqrt(max(1e-20,1-Z*Z))
    J[0,0]=2*delta*(Z/s0)*math.sin(Phi)
    J[0,1]=-2*delta*s0*math.cos(Phi)
    J[1,0]=2*delta*math.cos(Phi)/(s0**3)
    J[1,1]=-2*delta*(Z/s0)*math.sin(Phi)
    for i in range(N):
        k=2*(i+1)
        J[1,k]=Lambda
        z,ph=u[k],u[k+1]; s=math.sqrt(max(1e-20,1-z*z))
        J[k,k]=2*Di*(z/s)*math.sin(ph)
        J[k,k+1]=-2*Di*s*math.cos(ph)
        J[k+1,k]=2*Di*math.cos(ph)/(s**3)
        J[k+1,k+1]=-2*Di*(z/s)*math.sin(ph)
        J[k+1,0]=Lambda
    return J


def _canonical_variational_rhs(t,Y):
    u=Y[:PHYS_DIM]; MM=Y[PHYS_DIM:].reshape(PHYS_DIM,PHYS_DIM)
    return np.concatenate([_canonical_rhs(t,u),(_canonical_jacobian(u)@MM).ravel()])


def reciprocal_pair_error(eigvals):
    a=np.abs(np.asarray(eigvals,complex)); a=a[np.isfinite(a)&(a>1e-300)]
    if len(a)<2:return np.nan
    logs=np.sort(np.log(a))
    return float(np.max(np.abs(logs + logs[::-1])))


def _floquet_bloch_fallback(R0,T):
    Y0=np.concatenate([R0,np.eye(BLOCH_DIM).ravel()])
    sol=solve_ivp(variational_rhs,(0,float(T)),Y0,method="DOP853",rtol=3e-11,atol=3e-13)
    if not sol.success:return None
    yf=sol.y[:,-1]; Rf=yf[:BLOCH_DIM]; MF=yf[BLOCH_DIM:].reshape(BLOCH_DIM,BLOCH_DIM)
    B=tangent_basis(R0); MP=B.T@MF@B
    eig=np.linalg.eigvals(MP); eig=eig[np.argsort(np.abs(eig))[::-1]]
    rho=float(np.max(np.abs(eig))); lam=float(np.log(max(rho,1e-300))/T)
    return {"return_D":float(np.linalg.norm(Rf-R0)),"rho":rho,"lambda":lam,
            "det":float(np.linalg.det(MP)),"symplectic_error":np.nan,
            "reciprocal_pair_error":reciprocal_pair_error(eig),"eigvals":eig,
            "Mphys":MP,"floquet_method":"bloch_tangent_fallback"}


def floquet_analysis(R0,T):
    """Primary Floquet calculation in true canonical (z,phi) coordinates.

    This avoids interpreting an arbitrary orthonormal Bloch tangent basis as a
    canonical one. If an orbit approaches a Bloch pole too closely, where the
    (z,phi) chart is singular, a constrained-Bloch tangent calculation is used
    as a documented fallback. Reciprocal-pair error is always reported.
    """
    try:
        # Ensure the canonical chart stays sufficiently far from singular poles.
        tt,tr=integrate_grid(R0,float(T),240,rtol=2e-10,atol=2e-12)
        pole_margin=float(np.min(1.0-np.abs(tr[:,2::3])))
        if pole_margin < 2e-7:
            raise FloatingPointError(f"canonical chart pole margin={pole_margin:.2e}")
        u0=_canonical_from_bloch(R0)
        Y0=np.concatenate([u0,np.eye(PHYS_DIM).ravel()])
        sol=solve_ivp(_canonical_variational_rhs,(0,float(T)),Y0,method="DOP853",
                      rtol=2e-11,atol=2e-13)
        if not sol.success:raise RuntimeError(sol.message)
        uf=sol.y[:PHYS_DIM,-1]; MC=sol.y[PHYS_DIM:,-1].reshape(PHYS_DIM,PHYS_DIM)
        eig=np.linalg.eigvals(MC); eig=eig[np.argsort(np.abs(eig))[::-1]]
        rho=float(np.max(np.abs(eig))); lam=float(np.log(max(rho,1e-300))/T)
        S=canonical_symplectic_matrix()
        Rf=_bloch_from_canonical(uf)
        return {"return_D":float(np.linalg.norm(Rf-R0)),"rho":rho,"lambda":lam,
                "det":float(np.linalg.det(MC)),
                "symplectic_error":float(np.max(np.abs(MC.T@S@MC-S))),
                "reciprocal_pair_error":reciprocal_pair_error(eig),"eigvals":eig,
                "Mphys":MC,"floquet_method":"canonical_action_angle",
                "canonical_pole_margin":pole_margin}
    except Exception as exc:
        out=_floquet_bloch_fallback(R0,T)
        if out is not None:
            out["canonical_failure"]=str(exc)
            out["canonical_pole_margin"]=np.nan
        return out

# ============================================================================
# CHAOS STAGE
# ============================================================================


def stage_chaos(cfg,target_energy,outdir,rng):
    if stage_done(outdir,"chaos"):
        p(f"N={N} chaos: checkpoint exists; skipping")
        return read_json(Path(outdir)/"chaos_summary.json",{})
    p(f"\n===== N={N}: CHAOS / FTLE =====")
    rows=[]; t0=time.perf_counter()
    for k in range(cfg["CHAOS_SAMPLES"]):
        try:
            A=random_same_energy_A(rng,target_energy); R=A_to_bloch(A)
            lam=ftle_one_vector(R,rng,cfg["FTLE_TIME"],cfg["FTLE_CHUNKS"])
            _,tr=integrate_grid(R,min(cfg["FTLE_TIME"],30.0),120,rtol=3e-9,atol=2e-11)
            drift,_,_=energy_drift(tr)
            rows.append({"sample":k,"ftle":lam,"energy_drift":drift,"A":A.tolist()})
            p(f"N={N} FTLE {k+1}/{cfg['CHAOS_SAMPLES']}: {lam:+.5e}, drift={drift:.2e}, elapsed={time.perf_counter()-t0:.1f}s")
        except Exception as exc:
            p(f"WARNING FTLE sample {k} skipped: {exc}")
    finite=np.array([r["ftle"] for r in rows if np.isfinite(r["ftle"])])
    summary={
        "N":N,"target_energy":target_energy,"energy_density":target_energy/M,
        "n_samples":len(rows),"mean_ftle":float(np.mean(finite)) if len(finite) else None,
        "median_ftle":float(np.median(finite)) if len(finite) else None,
        "max_ftle":float(np.max(finite)) if len(finite) else None,
        "fraction_positive":float(np.mean(finite>1e-4)) if len(finite) else None,
        "max_energy_drift":float(max([r["energy_drift"] for r in rows],default=np.nan)),
    }
    write_json(Path(outdir)/"chaos_summary.json",summary)
    fields=["sample","ftle","energy_drift","Z0","Phi0"]+[f"z{i+1}_0" for i in range(N)]+[f"phi{i+1}_0" for i in range(N)]
    table=[]
    for r in rows:
        A=r["A"]; row={"sample":r["sample"],"ftle":r["ftle"],"energy_drift":r["energy_drift"],"Z0":A[0],"Phi0":A[1]}
        for i in range(N): row[f"z{i+1}_0"]=A[2+i]; row[f"phi{i+1}_0"]=A[2+N+i]
        table.append(row)
    atomic_csv(Path(outdir)/"chaos_ftle.csv",fields,table)
    if len(finite):
        plt.figure(figsize=(7,5)); plt.hist(finite,bins=min(18,max(6,len(finite)//3))); plt.axvline(0,ls="--")
        plt.xlabel("Finite-time Lyapunov exponent"); plt.ylabel("Count"); plt.title(f"N={N} same-shell FTLE")
        plt.tight_layout(); plt.savefig(Path(outdir)/"ftle_histogram.png",dpi=300); plt.close()
    mark_stage(outdir,"chaos",summary)
    return summary

# ============================================================================
# POINCARE RECURRENCE SEARCH / REFINEMENT
# ============================================================================


def integrate_dense(R0,total_time,dt,rtol=2e-8,atol=1e-10):
    nt=int(np.floor(total_time/dt))+1
    tt=np.linspace(0,total_time,nt)
    sol=solve_ivp(bloch_rhs,(0,total_time),R0,method="DOP853",t_eval=tt,rtol=rtol,atol=atol)
    if not sol.success: raise RuntimeError(sol.message)
    return sol.t,sol.y.T


def section_state_exact_energy(Rinterp,target_energy):
    Rinterp=normalize_state(Rinterp)
    zs=[]; phis=[]
    for i in range(N):
        j=3+3*i; zs.append(float(Rinterp[j+2])); phis.append(float(np.arctan2(Rinterp[j+1],Rinterp[j])))
    roots=roots_for_Z(np.asarray(zs),np.asarray(phis),target_energy)
    if not roots: return None
    Z=min(roots,key=lambda z:abs(z-Rinterp[2]))
    A=np.array([Z,0.0,*zs,*phis],float)
    return A,A_to_bloch(A)


def extract_poincare_section(times,traj,target_energy):
    sec=[]; y=traj[:,1]
    for k in range(len(times)-1):
        if y[k] <= 0.0 < y[k+1]:
            dy=y[k+1]-y[k]; a=0 if abs(dy)<1e-15 else -y[k]/dy; a=float(np.clip(a,0,1))
            R=normalize_state((1-a)*traj[k]+a*traj[k+1]); t=(1-a)*times[k]+a*times[k+1]
            if R[0] <= 0: continue
            ex=section_state_exact_energy(R,target_energy)
            if ex is not None:
                A,RR=ex; sec.append({"t":float(t),"A":A,"R":RR})
    return sec


def recurrence_candidates_from_section(section,cfg):
    if len(section)<3: return []
    X=np.array([s["R"] for s in section]); ts=np.array([s["t"] for s in section]); tree=cKDTree(X)
    out=[]
    for i in range(len(section)):
        for j in tree.query_ball_point(X[i],r=cfg["COARSE_RADIUS"]):
            if j<=i: continue
            T=ts[j]-ts[i]
            if not(cfg["T_MIN"]<=T<=cfg["T_MAX"]): continue
            out.append({"A":section[i]["A"].copy(),"T":float(T),"D":float(np.linalg.norm(X[j]-X[i]))})
    out.sort(key=lambda c:c["D"])
    return out[:cfg["CANDIDATES_PER_TRAJECTORY"]]


def orbit_excursion(R0,T):
    try:
        _,tr=integrate_grid(R0,T,500,rtol=3e-10,atol=2e-11)
        return float(np.max(np.linalg.norm(tr-R0,axis=1)))
    except Exception: return np.nan


def reduce_period(R0,T,cfg):
    best=float(T)
    for q in range(2,13):
        t=T/q
        if t<cfg["T_MIN"]: continue
        Rf=integrate_final(R0,t,rtol=5e-10,atol=2e-11)
        if Rf is not None and np.linalg.norm(Rf-R0)<5*cfg["PERIODIC_TOL"]: best=min(best,t)
    return best


def params_to_A(x):
    return np.array([x[0],0.0,*x[1:1+N],*x[1+N:1+2*N]],float)


def candidate_to_x(c):
    A=c["A"]
    return np.array([A[0],*A[2:2+N],*A[2+N:2+2*N],c["T"]],float)


def recurrence_residual_factory(target_energy,cfg,print_every=100,rtol=4e-9,atol=2e-10):
    state={"calls":0,"best":np.inf,"last_improve":0}
    def residual(x):
        state["calls"]+=1
        if state["calls"]>cfg["MAX_RESIDUAL_CALLS"]:
            raise CandidateAbort("hard residual-call limit")
        A=params_to_A(x[:-1]); T=float(x[-1]); R0=A_to_bloch(A)
        Rf=integrate_final(R0,T,rtol=rtol,atol=atol)
        if Rf is None: return np.ones(BLOCH_DIM+1)*100
        rec=Rf-R0; dE=energy_bloch(R0)-target_energy
        score=float(np.linalg.norm(rec)+5*abs(dE))
        if score < state["best"]*0.995:
            state["best"]=score; state["last_improve"]=state["calls"]
        if state["calls"]>600 and state["calls"]-state["last_improve"]>cfg["STAGNATION_CALLS"] and state["best"]>5e-3:
            raise CandidateAbort(f"stagnation (best score {state['best']:.3e})")
        if state["calls"]%print_every==0:
            p(f"      eval {state['calls']:5d}: D={np.linalg.norm(rec):.3e}, dE={dE:+.2e}, T={T:.6f}")
        return np.concatenate([rec,[dE]])
    residual.state=state
    return residual


def orbit_to_row(idx,o):
    row={"orbit":idx,"T":o["T"],"return_D":o["return_D"],"energy":o["energy"],"energy_error":o["energy_error"],
         "excursion":o["excursion"],"max_mu":o["rho"],"floquet_lambda":o["lambda"],
         "lambda_over_omega":o["lambda"]/(2*np.pi/o["T"]),"det_M":o["det"],"symplectic_error":o.get("symplectic_error",np.nan),
         "reciprocal_pair_error":o.get("reciprocal_pair_error",np.nan),"floquet_method":o.get("floquet_method","unknown"),
         "canonical_pole_margin":o.get("canonical_pole_margin",np.nan),"source":o.get("source","search"),"Z0":o["A"][0]}
    for i in range(N): row[f"z{i+1}_0"]=o["A"][2+i]; row[f"phi{i+1}_0"]=o["A"][2+N+i]
    eig=np.asarray(o.get("eigvals",[]),complex)
    for k in range(PHYS_DIM):
        mu=eig[k] if k<len(eig) else np.nan+1j*np.nan
        row[f"mu{k+1}_real"]=float(np.real(mu)); row[f"mu{k+1}_imag"]=float(np.imag(mu))
    return row


def orbit_fields():
    return (["orbit","T","return_D","energy","energy_error","excursion","max_mu","floquet_lambda","lambda_over_omega","det_M","symplectic_error","reciprocal_pair_error","floquet_method","canonical_pole_margin","source","Z0"]+
            [f"z{i+1}_0" for i in range(N)]+[f"phi{i+1}_0" for i in range(N)]+
            [f"mu{k+1}_real" for k in range(PHYS_DIM)]+[f"mu{k+1}_imag" for k in range(PHYS_DIM)])


def save_orbits(path,orbits):
    atomic_csv(path,orbit_fields(),[orbit_to_row(i,o) for i,o in enumerate(orbits)])


def row_to_orbit(row):
    A=np.array([float(row["Z0"]),0.0]+[float(row[f"z{i+1}_0"]) for i in range(N)]+[float(row[f"phi{i+1}_0"]) for i in range(N)],float)
    eig=[]
    for k in range(PHYS_DIM):
        rk=f"mu{k+1}_real"; ik=f"mu{k+1}_imag"
        if rk in row and row[rk] not in (None,""):
            try:eig.append(complex(float(row[rk]),float(row[ik])))
            except Exception:pass
    return {"A":A,"R0":A_to_bloch(A),"T":float(row["T"]),"return_D":float(row.get("return_D",np.nan)),
            "energy":float(row.get("energy",np.nan)),"energy_error":float(row.get("energy_error",np.nan)),
            "excursion":float(row.get("excursion",np.nan)),"rho":float(row.get("max_mu",np.nan)),
            "lambda":float(row.get("floquet_lambda",np.nan)),"det":float(row.get("det_M",np.nan)),
            "symplectic_error":float(row.get("symplectic_error",np.nan) or np.nan),
            "reciprocal_pair_error":float(row.get("reciprocal_pair_error",np.nan) or np.nan),
            "floquet_method":row.get("floquet_method","legacy"),"canonical_pole_margin":float(row.get("canonical_pole_margin",np.nan) or np.nan),
            "eigvals":np.array(eig),"source":row.get("source","csv")}


def load_orbits(path):
    return [row_to_orbit(r) for r in read_csv(path)]


# ============================================================================
# EXACT-SYMMETRY UPO EQUIVALENCE / DEDUPLICATION
# ============================================================================

# Exact discrete symmetries for central epsilon=1 and identical environment TLSs:
#   I : identity
#   T : (x,y,z)(t)->(x,-y,z)(-t)
# Environment permutations and arbitrary phase origin remain exact.
# The epsilon=0 parity P and PT are intentionally NOT used: central bias breaks them.
SYMMETRY_NAMES=("I","T")


def _apply_value_symmetry(arr,name):
    a=np.asarray(arr,float).copy()
    shp=a.shape; b=a.reshape((-1,M,3))
    if name=="P":
        b[:,:,1]*=-1; b[:,:,2]*=-1
    elif name=="T":
        b[:,:,1]*=-1
    elif name=="PT":
        b[:,:,2]*=-1
    elif name!="I":
        raise ValueError(name)
    return b.reshape(shp)


def _symmetry_direction(name):
    return -1.0 if name in ("T","PT") else 1.0


def _permute_environment(arr,perm):
    a=np.asarray(arr,float); out=a.copy(); flat=out.reshape((-1,M,3)); src=a.reshape((-1,M,3))
    flat[:,0,:]=src[:,0,:]
    for i,j in enumerate(np.asarray(perm,int)):
        flat[:,i+1,:]=src[:,j+1,:]
    return out


def _permute_state(R,perm):
    return _permute_environment(np.asarray(R,float)[None,:],perm)[0]


def validate_exact_symmetries(outdir,rng,ntrials=10):
    """Validate the symmetry set used for epsilon=1 deduplication.

    I, T and environment permutations must be exact to roundoff. P and PT are
    audited separately and are required to be visibly broken so they can never
    be accidentally used to collapse distinct biased-system UPOs.
    """
    rows=[]; worst_active=0.0; broken=[]
    for q in range(ntrials):
        R=np.concatenate([rng.normal(size=3) for _ in range(M)]).astype(float)
        R=normalize_state(R); F=bloch_rhs(0,R); E=energy_bloch(R)
        for name in SYMMETRY_NAMES:
            S=_apply_value_symmetry(R,name); FS=bloch_rhs(0,S)
            rhs_expected=_apply_value_symmetry(F,name) if name=="I" else -_apply_value_symmetry(F,name)
            err=float(np.max(np.abs(FS-rhs_expected)))
            eerr=abs(energy_bloch(S)-E); worst_active=max(worst_active,err,eerr)
            rows.append({"trial":q,"symmetry":name,"is_active":True,"rhs_covariance_error":err,"energy_error":eerr})
        # Explicitly prove that the epsilon=0 parity operations are broken.
        for name in ("P","PT"):
            S=_apply_value_symmetry(R,name); FS=bloch_rhs(0,S)
            rhs_expected=_apply_value_symmetry(F,name) if name=="P" else -_apply_value_symmetry(F,name)
            err=float(np.max(np.abs(FS-rhs_expected))); eerr=abs(energy_bloch(S)-E)
            broken.append(max(err,eerr))
            rows.append({"trial":q,"symmetry":name,"is_active":False,"rhs_covariance_error":err,"energy_error":eerr})
        perm=rng.permutation(N); Rp=_permute_state(R,perm); Fp=bloch_rhs(0,Rp)
        expected=_permute_state(F,perm); err=float(np.max(np.abs(Fp-expected))); eerr=abs(energy_bloch(Rp)-E)
        worst_active=max(worst_active,err,eerr)
        rows.append({"trial":q,"symmetry":"ENV_PERM","is_active":True,"rhs_covariance_error":err,"energy_error":eerr})
    atomic_csv(Path(outdir)/"exact_symmetry_selftest.csv",["trial","symmetry","is_active","rhs_covariance_error","energy_error"],rows)
    payload={"worst_active_error":worst_active,"ntrials":ntrials,"active_symmetries":list(SYMMETRY_NAMES)+["ENV_PERM"],
             "broken_symmetries":["P","PT"],"min_broken_error":float(min(broken)) if broken else None}
    write_json(Path(outdir)/"exact_symmetry_selftest.json",payload)
    if worst_active>5e-10:
        raise RuntimeError(f"Active exact-symmetry self-test failed: worst error {worst_active:.3e}")
    if broken and max(broken)<1e-6:
        raise RuntimeError("P/PT unexpectedly appear exact for epsilon=1; refusing biased-system run")
    return worst_active


def phase_grid(orbit,points):
    key=f"phase_{points}"
    if key in orbit:return orbit[key]
    tt=np.linspace(0,orbit["T"],points,endpoint=False)
    sol=solve_ivp(bloch_rhs,(0,orbit["T"]),orbit["R0"],method="DOP853",t_eval=tt,rtol=2e-10,atol=2e-12)
    if not sol.success:raise RuntimeError(sol.message)
    orbit[key]=sol.y.T
    return orbit[key]


def _periodic_interp(traj,phases):
    traj=np.asarray(traj,float); K=len(traj); x=(np.asarray(phases,float)%1.0)*K
    i0=np.floor(x).astype(int)%K; f=x-np.floor(x); i1=(i0+1)%K
    out=(1-f)[:,None]*traj[i0]+f[:,None]*traj[i1]
    # Linear interpolation leaves each Bloch sphere slightly inside the unit
    # sphere; normalize only for distance evaluation.
    for k in range(M):
        j=3*k; nr=np.linalg.norm(out[:,j:j+3],axis=1); out[:,j:j+3]/=nr[:,None]
    return out


def _alignment_at_shift(ta,tb,shift,sym,verify_phases):
    A=_periodic_interp(ta,verify_phases)
    phases=(shift+_symmetry_direction(sym)*verify_phases)%1.0
    B=_apply_value_symmetry(_periodic_interp(tb,phases),sym)
    ea=A[:,3:].reshape(len(A),N,3); eb=B[:,3:].reshape(len(B),N,3)
    cost=np.mean(np.sum((ea[:,:,None,:]-eb[:,None,:,:])**2,axis=3),axis=0)
    rr,cc=linear_sum_assignment(cost); perm=np.empty(N,dtype=int); perm[rr]=cc
    sys2=np.sum((A[:,:3]-B[:,:3])**2,axis=1)
    env2=np.sum((ea-eb[:,perm,:])**2,axis=(1,2))
    per_time=np.sqrt((sys2+env2)/M)
    return float(np.sqrt(np.mean(per_time**2))),float(np.max(per_time)),perm


def best_family_alignment(a,b,cfg,require_same_period=True):
    rel=abs(a["T"]-b["T"])/min(a["T"],b["T"])
    if require_same_period and rel>cfg["DEDUP_PERIOD_REL_TOL"]:
        return {"equivalent":False,"period_rel_diff":rel,"trajectory_rms":np.nan,"trajectory_max":np.nan,
                "shift_phase":np.nan,"perm":"","symmetry":"PERIOD_MISMATCH","rho_rel_diff":np.nan}
    K=cfg["DEDUP_PHASE_POINTS"]; ta=phase_grid(a,K); tb=phase_grid(b,K)
    V=cfg["DEDUP_VERIFY_POINTS"]; verify=np.linspace(0,1,V,endpoint=False)
    coarse=cfg["DEDUP_COARSE_SHIFTS"]; step=1.0/coarse
    best=(np.inf,np.inf,None,None,None)
    for sym in SYMMETRY_NAMES:
        scores=[]
        for s in range(coarse):
            u=s/coarse; rms,mx,perm=_alignment_at_shift(ta,tb,u,sym,verify); scores.append((rms,mx,u,perm))
        # Refine the three best coarse phase origins continuously.
        for rms0,mx0,u0,perm0 in sorted(scores,key=lambda x:x[0])[:3]:
            def obj(dx):
                return _alignment_at_shift(ta,tb,(u0+dx)%1.0,sym,verify)[0]
            try:
                res=minimize_scalar(obj,bounds=(-step,step),method="bounded",options={"xatol":2e-7})
                u=(u0+float(res.x))%1.0; rms,mx,perm=_alignment_at_shift(ta,tb,u,sym,verify)
            except Exception:
                u=u0; rms,mx,perm=rms0,mx0,perm0
            if rms<best[0]:best=(rms,mx,u,perm,sym)
    rms,mx,u,perm,sym=best
    rho_rel=abs(a.get("rho",np.nan)-b.get("rho",np.nan))/max(1.0,abs(a.get("rho",1.0)),abs(b.get("rho",1.0)))
    eq=bool((not require_same_period or rel<=cfg["DEDUP_PERIOD_REL_TOL"]) and
            rms<cfg["DEDUP_RMS_TOL"] and mx<cfg["DEDUP_MAX_TOL"])
    return {"equivalent":eq,"period_rel_diff":rel,"trajectory_rms":rms,"trajectory_max":mx,
            "shift_phase":u,"perm":" ".join(map(str,perm.tolist())),"symmetry":sym,"rho_rel_diff":rho_rel}


def orbit_equivalence(a,b,cfg):
    return best_family_alignment(a,b,cfg,require_same_period=True)


def deduplicate_orbits(orbits,cfg,outdir,label="clear"):
    L=len(orbits); parent=list(range(L))
    def find(x):
        while parent[x]!=x:
            parent[x]=parent[parent[x]]; x=parent[x]
        return x
    def union(a,b):
        ra,rb=find(a),find(b)
        if ra!=rb:parent[rb]=ra
    pairrows=[]
    for i in range(L):
        for j in range(i+1,L):
            try:info=orbit_equivalence(orbits[i],orbits[j],cfg)
            except Exception as exc:
                info={"equivalent":False,"period_rel_diff":np.nan,"trajectory_rms":np.nan,"trajectory_max":np.nan,
                      "shift_phase":np.nan,"perm":"","symmetry":"ERROR","rho_rel_diff":np.nan,"error":str(exc)}
            pairrows.append({"i":i,"j":j,**info})
            if info["equivalent"]:union(i,j)
    groups=defaultdict(list)
    for i in range(L):groups[find(i)].append(i)
    comps=sorted(groups.values(),key=min); reps=[]; membership=[]
    for cid,ids in enumerate(comps):
        members=[orbits[i] for i in ids]
        rep=min(members,key=lambda o:(o.get("return_D",np.inf),o.get("reciprocal_pair_error",np.inf),-o.get("rho",1.0)))
        reps.append(rep)
        for i in ids:
            o=orbits[i]; membership.append({"class_id":cid,"member_index":i,"is_representative":bool(o is rep),
                "T":o["T"],"rho":o["rho"],"return_D":o["return_D"],"source":o.get("source","")})
    pf=["i","j","equivalent","period_rel_diff","trajectory_rms","trajectory_max","shift_phase","perm","symmetry","rho_rel_diff","error"]
    atomic_csv(Path(outdir)/f"{label}_orbit_equivalence_pairs.csv",pf,pairrows)
    atomic_csv(Path(outdir)/f"{label}_orbit_classes.csv",["class_id","member_index","is_representative","T","rho","return_D","source"],membership)
    return reps,[[orbits[i] for i in ids] for ids in comps]


def validate_orbit(o,target_energy,cfg):
    R0=normalize_state(o["R0"]); T=reduce_period(R0,o["T"],cfg)
    Rf=integrate_final(R0,T,rtol=5e-12,atol=5e-13)
    if Rf is None:return None
    D=float(np.linalg.norm(Rf-R0)); E=energy_bloch(R0); dE=E-target_energy; exc=orbit_excursion(R0,T)
    if D>max(8*cfg["PERIODIC_TOL"],2e-6) or abs(dE)>max(8*cfg["ENERGY_TOL_ORBIT"],2e-7) or not np.isfinite(exc) or exc<cfg["MIN_EXCURSION"]:
        return None
    F=floquet_analysis(R0,T)
    if F is None:return None
    if not np.isfinite(F["rho"]) or not np.isfinite(F["det"]):return None
    # Numerical Hamiltonian sanity checks. These thresholds are validation
    # guards, not definitions of hyperbolicity.
    deterr=abs(math.log(max(abs(F["det"]),1e-300)))
    rerr=F.get("reciprocal_pair_error",np.nan)
    if deterr>cfg["FLOQUET_DET_TOL"] or (np.isfinite(rerr) and rerr>cfg["FLOQUET_RECIP_TOL"]):
        return None
    oo=dict(o); oo["R0"]=R0; oo["A"]=bloch_to_A(R0); oo.update(F)
    oo.update({"T":T,"return_D":D,"energy":E,"energy_error":dE,"excursion":exc})
    return oo


def import_legacy_clear(legacy_path,target_energy,cfg,outdir):
    if not legacy_path or not Path(legacy_path).exists(): return []
    p(f"N={N}: importing legacy clear-UPO candidates from {legacy_path}")
    try: rows=read_csv(legacy_path)
    except Exception as exc:
        p("legacy import failed:",exc); return []
    candidates=[]
    for row in rows:
        try:
            if float(row.get("max_mu",0))<cfg["CLEAR_UPO_RHO"]: continue
            o=row_to_orbit(row); o["source"]=f"legacy:{legacy_path}"
            v=validate_orbit(o,target_energy,cfg)
            if v is not None:
                candidates.append(v); p(f"  validated T={v['T']:.6f}, rho={v['rho']:.6f}, D={v['return_D']:.2e}")
            else: p(f"  rejected legacy T={o['T']:.6f}: failed current validation")
        except Exception as exc: p("  legacy row skipped:",exc)
    save_orbits(Path(outdir)/"legacy_validated_clear_upos.csv",candidates)
    return candidates


def checkpoint_candidates(path,candidates):
    fields=["rank","D","T","Z0"]+[f"z{i+1}_0" for i in range(N)]+[f"phi{i+1}_0" for i in range(N)]
    rows=[]
    for k,c in enumerate(candidates):
        A=c["A"]; r={"rank":k,"D":c["D"],"T":c["T"],"Z0":A[0]}
        for i in range(N): r[f"z{i+1}_0"]=A[2+i]; r[f"phi{i+1}_0"]=A[2+N+i]
        rows.append(r)
    atomic_csv(path,fields,rows)


def _candidate_hash(c):
    A=np.asarray(c["A"],float)
    vals=np.concatenate([np.round(A,7),[round(float(c["T"]),6)]])
    return hashlib.sha1(vals.tobytes()).hexdigest()[:20]


def _load_candidate_file(path):
    out=[]
    for row in read_csv(path):
        A=np.array([float(row["Z0"]),0.0]+[float(row[f"z{i+1}_0"]) for i in range(N)]+[float(row[f"phi{i+1}_0"]) for i in range(N)],float)
        out.append({"A":A,"T":float(row["T"]),"D":float(row["D"])})
    return out


def _diversify_candidates(cands,cfg):
    # Prevent the smallest-return candidates from a single orbit/period family
    # monopolising an epoch. Keep several candidates per period bin, then fill
    # remaining slots globally by recurrence distance.
    cands=sorted(cands,key=lambda c:c["D"]); out=[]; perbin=defaultdict(int)
    width=max(3.0,0.025*cfg["T_MAX"]); cap=4
    used=set()
    for c in cands:
        b=int(c["T"]//width)
        if perbin[b]>=cap:continue
        h=_candidate_hash(c)
        if h in used:continue
        out.append(c); used.add(h); perbin[b]+=1
        if len(out)>=cfg["CANDIDATES_PER_EPOCH"]:return out
    for c in cands:
        h=_candidate_hash(c)
        if h not in used:
            out.append(c); used.add(h)
            if len(out)>=cfg["CANDIDATES_PER_EPOCH"]:break
    return out


def _epoch_local_cfg(cfg,epoch):
    c=dict(cfg); mode=epoch%4
    # Sweep short, medium, long and full-period recurrence windows repeatedly.
    if mode==0:c["T_MIN"],c["T_MAX"]=cfg["T_MIN"],min(cfg["T_MAX"],90+12*N)
    elif mode==1:c["T_MIN"],c["T_MAX"]=max(cfg["T_MIN"],40.0),min(cfg["T_MAX"],210+12*N)
    elif mode==2:c["T_MIN"],c["T_MAX"]=max(cfg["T_MIN"],100.0),cfg["T_MAX"]
    else:c["T_MIN"],c["T_MAX"]=cfg["T_MIN"],cfg["T_MAX"]
    c["COARSE_RADIUS"]=cfg["COARSE_RADIUS"]*[0.85,1.0,1.15,1.30][mode]
    return c


def _generate_epoch_candidates(cfg,target_energy,outdir,epoch,master_seed):
    path=Path(outdir)/f"search_epoch_{epoch:03d}_candidates.csv"
    if path.exists():return _load_candidate_file(path)
    ecfg=_epoch_local_cfg(cfg,epoch); erng=np.random.default_rng(master_seed+N*100000+epoch*1009)
    allc=[]
    p(f"N={N} generating search epoch {epoch}: T=[{ecfg['T_MIN']:.1f},{ecfg['T_MAX']:.1f}], radius={ecfg['COARSE_RADIUS']:.3f}")
    for q in range(cfg["COARSE_TRAJECTORIES_PER_EPOCH"]):
        try:
            A=random_same_energy_A(erng,target_energy); R=A_to_bloch(A)
            tt,tr=integrate_dense(R,cfg["COARSE_TIME"],cfg["COARSE_DT"])
            sec=extract_poincare_section(tt,tr,target_energy); cc=recurrence_candidates_from_section(sec,ecfg)
            allc.extend(cc)
            p(f"  epoch {epoch} coarse {q+1}/{cfg['COARSE_TRAJECTORIES_PER_EPOCH']}: section={len(sec)}, recurrences={len(cc)}")
        except Exception as exc:p(f"  WARNING coarse trajectory skipped: {exc}")
    selected=_diversify_candidates(allc,cfg)
    checkpoint_candidates(path,selected)
    return selected


def _refine_candidate_final(c,cfg,target_energy):
    state_bound=0.999999
    lower=np.array([-state_bound]+[-state_bound]*N+[-10*np.pi]*N+[cfg["T_MIN"]],float)
    upper=np.array([ state_bound]+[ state_bound]*N+[ 10*np.pi]*N+[cfg["T_MAX"]],float)
    x0=np.minimum(np.maximum(candidate_to_x(c),lower+1e-10),upper-1e-10)
    try:
        resfun=recurrence_residual_factory(target_energy,cfg,150,4e-9,2e-10)
        result=least_squares(resfun,x0,bounds=(lower,upper),method="trf",xtol=2e-10,ftol=2e-10,gtol=2e-10,
                             max_nfev=cfg["MAX_NFEV"],x_scale="jac")
        A1=params_to_A(result.x[:-1]); R1=A_to_bloch(A1); Rf=integrate_final(R1,float(result.x[-1]),rtol=3e-9,atol=2e-10)
        D1=np.linalg.norm(Rf-R1) if Rf is not None else np.inf
        if D1<2e-3 and abs(energy_bloch(R1)-target_energy)<2e-4:
            pcfg=dict(cfg); pcfg["MAX_RESIDUAL_CALLS"]=max(3000,cfg["MAX_RESIDUAL_CALLS"]); pcfg["STAGNATION_CALLS"]=max(1200,cfg["STAGNATION_CALLS"])
            polish=recurrence_residual_factory(target_energy,pcfg,250,1.5e-11,8e-13)
            result=least_squares(polish,result.x,bounds=(lower,upper),method="trf",xtol=3e-13,ftol=3e-13,gtol=3e-13,
                                 max_nfev=cfg["POLISH_NFEV"],x_scale="jac")
    except CandidateAbort as exc:return None,"aborted:"+str(exc)
    except Exception as exc:return None,f"error:{type(exc).__name__}:{exc}"
    try:
        A=params_to_A(result.x[:-1]); base={"A":A,"R0":A_to_bloch(A),"T":float(result.x[-1]),"source":"search"}
        val=validate_orbit(base,target_energy,cfg)
        if val is None:return None,"validation_failed"
        return val,"accepted"
    except Exception as exc:return None,f"post_error:{type(exc).__name__}:{exc}"


def search_periodic_orbits(cfg,target_energy,outdir,rng,seed_orbits=None,force_search=False):
    """Adaptive, resumable search that does not declare success below the
    requested number of exact-symmetry-inequivalent hyperbolic UPO families."""
    outdir=Path(outdir); raw_path=outdir/"periodic_orbits_all_valid.csv"; state_path=outdir/"search_state.json"
    done=stage_marker(outdir,"search_final_v1")
    found=[]
    if raw_path.exists():
        try:found=load_orbits(raw_path)
        except Exception:found=[]
    # Merge validated legacy seeds, preserving all symmetry copies for audit.
    for o in (seed_orbits or []):
        if not any(abs(o["T"]-x["T"])/min(o["T"],x["T"])<1e-10 and np.linalg.norm(o["R0"]-x["R0"])<1e-8 for x in found):
            found.append(o)
    save_orbits(raw_path,found)
    clear=[o for o in found if o["rho"]>=cfg["CLEAR_UPO_RHO"]]
    reps,classes=deduplicate_orbits(clear,cfg,outdir,"search_current_clear") if clear else ([],[])
    if len(reps)>=cfg["REQUIRED_INDEPENDENT_UPOS"] and not force_search:
        mark_stage(outdir,"search_final_v1",{"independent_clear_families":len(reps),"status":"complete_from_seeds_or_resume"})
        return found

    st=read_json(state_path,{}) or {}; epoch=int(st.get("epoch",0))
    processed_rows=read_csv(outdir/"search_processed_candidates.csv") if (outdir/"search_processed_candidates.csv").exists() else []
    processed={r["candidate_key"] for r in processed_rows}
    start=time.perf_counter(); budget=cfg["SEARCH_BUDGET_HOURS"]*3600
    while True:
        clear=[o for o in found if o["rho"]>=cfg["CLEAR_UPO_RHO"]]
        reps,classes=deduplicate_orbits(clear,cfg,outdir,"search_current_clear") if clear else ([],[])
        save_orbits(outdir/"independent_clear_upos_current.csv",reps)
        p(f"N={N}: exact-symmetry independent clear UPO families = {len(reps)}/{cfg['REQUIRED_INDEPENDENT_UPOS']}")
        if len(reps)>=cfg["REQUIRED_INDEPENDENT_UPOS"]:
            mark_stage(outdir,"search_final_v1",{"independent_clear_families":len(reps),"epochs_completed":epoch})
            if (outdir/"SEARCH_NEEDS_RESUME.json").exists():(outdir/"SEARCH_NEEDS_RESUME.json").unlink()
            return found
        if time.perf_counter()-start>budget:
            payload={"N":N,"time":utcnow(),"epoch":epoch,"independent_clear_families":len(reps),
                     "required":cfg["REQUIRED_INDEPENDENT_UPOS"],"message":"Re-submit the identical command; search resumes from checkpoints."}
            write_json(outdir/"SEARCH_NEEDS_RESUME.json",payload); write_json(state_path,{"epoch":epoch})
            raise SearchIncomplete(f"N={N}: search budget reached with {len(reps)}/{cfg['REQUIRED_INDEPENDENT_UPOS']} families; safe resume required")
        cands=_generate_epoch_candidates(cfg,target_energy,outdir,epoch,MASTER_SEED)
        for ci,c in enumerate(cands):
            key=f"{epoch}:{ci}:{_candidate_hash(c)}"
            if key in processed:continue
            if time.perf_counter()-start>budget:
                write_json(state_path,{"epoch":epoch}); save_orbits(raw_path,found)
                write_json(outdir/"SEARCH_NEEDS_RESUME.json",{"N":N,"epoch":epoch,"candidate_index":ci,"time":utcnow()})
                raise SearchIncomplete(f"N={N}: safe search checkpoint at epoch {epoch}, candidate {ci}")
            p(f"\nN={N} EPOCH {epoch} candidate {ci+1}/{len(cands)} D0={c['D']:.3e} T0={c['T']:.6f}")
            o,status=_refine_candidate_final(c,cfg,target_energy)
            row={"candidate_key":key,"epoch":epoch,"candidate_index":ci,"D0":c["D"],"T0":c["T"],"status":status,"time":utcnow()}
            if o is not None:
                row.update({"T":o["T"],"D":o["return_D"],"rho":o["rho"],"lambda_over_omega":o["lambda"]/(2*np.pi/o["T"]),"floquet_method":o.get("floquet_method","")})
                found.append(o); save_orbits(raw_path,found)
                p(f"  VALID orbit: T={o['T']:.9f}, D={o['return_D']:.2e}, rho={o['rho']:.7g}, lambda/omega={row['lambda_over_omega']:.5g}, method={o.get('floquet_method')}")
            processed_rows.append(row); processed.add(key)
            fields=[]
            for r in processed_rows:
                for k in r:
                    if k not in fields:fields.append(k)
            atomic_csv(outdir/"search_processed_candidates.csv",fields,processed_rows)
            clear=[x for x in found if x["rho"]>=cfg["CLEAR_UPO_RHO"]]
            reps,_=deduplicate_orbits(clear,cfg,outdir,"search_current_clear") if clear else ([],[])
            if len(reps)>=cfg["REQUIRED_INDEPENDENT_UPOS"]:break
        epoch+=1; write_json(state_path,{"epoch":epoch})


# ============================================================================
# DYNAMICAL SCAR / LOCALIZATION ANALYSIS -- exact family controls
# ============================================================================


def project_to_energy_shell(R,target_energy,tol=1e-10):
    R=normalize_state(R)
    for _ in range(60):
        dE=energy_bloch(R)-target_energy
        if abs(dE)<tol:return R,True
        g=energy_gradient(R); tg=np.zeros_like(R)
        for k in range(M):
            j=3*k; r=R[j:j+3]; gg=g[j:j+3]; tg[j:j+3]=gg-np.dot(gg,r)*r
        den=np.dot(tg,tg)
        if den<1e-15:return R,False
        R-=(dE/den)*tg; R=normalize_state(R)
    return R,abs(energy_bloch(R)-target_energy)<1e-7


def generate_near_state(R_upo,target_energy,rng,amplitude):
    B=tangent_basis(R_upo); flow=B.T@bloch_rhs(0,R_upo); grad=B.T@energy_gradient(R_upo)
    cons=[]
    for q in (flow,grad):
        if np.linalg.norm(q)>1e-12:cons.append(q/np.linalg.norm(q))
    Qb=np.linalg.qr(np.column_stack(cons))[0] if cons else None
    for _ in range(400):
        v=rng.normal(size=PHYS_DIM)
        if Qb is not None:v-=Qb@(Qb.T@v)
        nv=np.linalg.norm(v)
        if nv<1e-14:continue
        v*=amplitude/nv; dR=B@v; R=R_upo.copy()
        for k in range(M):
            j=3*k; r=R_upo[j:j+3]; dr=dR[j:j+3]; a=np.linalg.norm(dr)
            if a>0:R[j:j+3]=np.cos(a)*r+np.sin(a)*(dr/a)
        R,ok=project_to_energy_shell(R,target_energy)
        if ok:return R
    raise RuntimeError("failed to generate near-UPO same-shell state")


def overlap_matrix(trajectory,target_upo):
    Q=np.ones((len(trajectory),len(target_upo)),float)
    for k in range(M):
        j=3*k; dots=trajectory[:,j:j+3]@target_upo[:,j:j+3].T
        Q*=0.5*(1+np.clip(dots,-1,1))
    return np.clip(Q,0,1)


def phase_lock_metrics(Q,times,target_T,start_idx,end_idx):
    Nu=Q.shape[1]; idx=np.arange(start_idx,end_idx)
    expected=np.floor(((times%target_T)/target_T)*Nu).astype(int)%Nu
    shifts=np.arange(Nu); target_idx=(expected[idx,None]+shifts[None,:])%Nu
    scores=np.mean(Q[idx[:,None],target_idx],axis=0); C=float(np.max(scores))
    ridge=np.argmax(Q[idx],axis=1); phase_diff=2*np.pi*(ridge-expected[idx])/Nu
    R=float(abs(np.mean(np.exp(1j*phase_diff))))
    return C,R


def surrogate_null(Q,times,source_T,target_T,start_idx,end_idx,n_surrogates,rng):
    Nu=Q.shape[1]; idx=np.arange(start_idx,end_idx)
    expected=np.floor(((times%target_T)/target_T)*Nu).astype(int)%Nu
    source_period=np.floor(times/source_T).astype(int); periods=np.unique(source_period[idx]); shifts=np.arange(Nu); ridge=np.argmax(Q[idx],axis=1)
    Cn=np.empty(n_surrogates); Rn=np.empty(n_surrogates)
    for s in range(n_surrogates):
        ex=expected.copy()
        for pp in periods:
            mask=source_period==pp; ex[mask]=(ex[mask]+rng.integers(0,Nu))%Nu
        target_idx=(ex[idx,None]+shifts[None,:])%Nu
        Cn[s]=np.max(np.mean(Q[idx[:,None],target_idx],axis=0))
        phase_diff=2*np.pi*(ridge-ex[idx])/Nu; Rn[s]=abs(np.mean(np.exp(1j*phase_diff)))
    return Cn,Rn


def _aligned_target_phase_grid(source,target,cfg):
    info=best_family_alignment(source,target,cfg,require_same_period=False)
    K=cfg["PHASE_POINTS"]; base=phase_grid(target,max(K,cfg["DEDUP_PHASE_POINTS"]))
    phases=np.arange(K)/K
    B=_periodic_interp(base,(info["shift_phase"]+_symmetry_direction(info["symmetry"])*phases)%1.0)
    B=_apply_value_symmetry(B,info["symmetry"])
    perm=[int(x) for x in info["perm"].split()] if info["perm"] else list(range(N))
    B=_permute_environment(B,perm)
    return B,info


def _integrate_dense_solution(R0,total,rtol=1e-9,atol=1e-11):
    sol=solve_ivp(bloch_rhs,(0,float(total)),R0,method="DOP853",rtol=rtol,atol=atol,dense_output=True)
    if not sol.success:raise RuntimeError(sol.message)
    return sol


def _q_window_stats(Q,i0,i1):
    q=np.clip(Q[i0:i1],1e-300,1.0)
    return float(np.mean(q)),float(np.mean(np.log(q))/M)


def generic_same_energy_ensemble(cfg,target_energy,rng,orbits,outdir):
    path=Path(outdir)/"generic_baseline_final.csv"
    if path.exists():return read_csv(path)
    rows=[]; maxT=max(o["T"] for o in orbits)
    for s in range(cfg["N_GENERIC"]):
        try:
            A=random_same_energy_A(rng,target_energy); R=A_to_bloch(A); sol=_integrate_dense_solution(R,20*maxT)
            check_t=np.linspace(0,20*maxT,180); trc=sol.sol(check_t).T; drift,_,_=energy_drift(trc)
            for j,o in enumerate(orbits):
                tt=np.linspace(0,20*o["T"],20*cfg["POINTS_PER_PERIOD"]+1); tr=sol.sol(tt).T
                Q=overlap_matrix(tr,o["phase_traj"])
                a=10*cfg["POINTS_PER_PERIOD"]; b=16*cfg["POINTS_PER_PERIOD"]+1
                c=16*cfg["POINTS_PER_PERIOD"]; d=20*cfg["POINTS_PER_PERIOD"]+1
                q1,l1=_q_window_stats(Q,a,b); q2,l2=_q_window_stats(Q,c,d)
                rows.append({"sample":s,"target_orbit":j,"energy":energy_bloch(R),"energy_drift":drift,
                             "Qbar_10_16":q1,"mean_logQ_perTLS_10_16":l1,"Qbar_16_20":q2,"mean_logQ_perTLS_16_20":l2})
            p(f"N={N} generic {s+1}/{cfg['N_GENERIC']}")
        except Exception as exc:p("WARNING generic sample skipped:",exc)
    atomic_csv(path,["sample","target_orbit","energy","energy_drift","Qbar_10_16","mean_logQ_perTLS_10_16","Qbar_16_20","mean_logQ_perTLS_16_20"],rows)
    return rows


def aggregate_scar_window(records,source,w0,w1,scheme,n_orbits):
    selfrows=[r for r in records if r["source"]==source and r["target"]==source and r["scheme"]==scheme and r["window_start"]==w0 and r["window_end"]==w1]
    if not selfrows:return None
    samples=sorted(set(r["sample"] for r in selfrows)); Cs=[]; Cx=[]; Cn=[]; Rs=[]; Rx=[]; Rn=[]
    for s in samples:
        a=[r for r in selfrows if r["sample"]==s][0]
        cross=[r for r in records if r["source"]==source and r["target"]!=source and r["sample"]==s and r["scheme"]==scheme and r["window_start"]==w0 and r["window_end"]==w1]
        Cs.append(a["C"]); Cn.append(a["C_null_mean"]); Rs.append(a["R"]); Rn.append(a["R_null_mean"])
        Cx.append(max([r["C"] for r in cross],default=np.nan)); Rx.append(max([r["R"] for r in cross],default=np.nan))
    Cs=np.asarray(Cs); Cx=np.asarray(Cx); Cn=np.asarray(Cn); Rs=np.asarray(Rs); Rx=np.asarray(Rx); Rn=np.asarray(Rn)
    cross=np.isfinite(Cx); cross_available=bool(np.any(cross))
    pcross=safe_wilcoxon(Cs[cross]-Cx[cross]) if cross_available else np.nan
    pnull=safe_wilcoxon(Cs-Cn); prnull=safe_wilcoxon(Rs-Rn)
    return {"source":source,"scheme":scheme,"window_start":w0,"window_end":w1,"n_samples":len(Cs),
            "Cself":float(np.mean(Cs)),"Ccross":float(np.nanmean(Cx)) if cross_available else np.nan,"Cnull":float(np.mean(Cn)),
            "Rself":float(np.mean(Rs)),"Rcross":float(np.nanmean(Rx)) if cross_available else np.nan,"Rnull":float(np.mean(Rn)),
            "C_self_cross_ratio":float(np.mean(Cs)/np.nanmean(Cx)) if cross_available and np.nanmean(Cx)>0 else np.nan,
            "C_self_null_ratio":float(np.mean(Cs)/np.mean(Cn)) if np.mean(Cn)>0 else np.nan,
            "R_margin":float(np.mean(Rs)-np.mean(Rn)),"pCcross":pcross,"pCnull":pnull,"pRnull":prnull,"cross_available":cross_available}


def benjamini_hochberg(pvalues):
    pvals=np.asarray(pvalues,float); q=np.full(len(pvals),np.nan); mask=np.isfinite(pvals); pv=pvals[mask]
    if len(pv)==0:return q
    order=np.argsort(pv); ranked=pv[order]; m=len(ranked); adj=np.minimum.accumulate((ranked*m/np.arange(1,m+1))[::-1])[::-1]
    back=np.empty(m); back[order]=np.clip(adj,0,1); q[np.where(mask)[0]]=back; return q


def scar_stage(cfg,target_energy,outdir,rng):
    if stage_done(outdir,"scar_final_v1"):
        p(f"N={N} scar final: checkpoint exists; skipping")
        return read_csv(Path(outdir)/"scar_orbit_summary.csv")
    orbits=load_orbits(Path(outdir)/"selected_independent_upos.csv")
    if len(orbits)!=cfg["REQUIRED_INDEPENDENT_UPOS"]:
        raise RuntimeError(f"N={N}: refusing scar analysis with {len(orbits)} UPOs; exactly {cfg['REQUIRED_INDEPENDENT_UPOS']} independently validated families required")
    for i,o in enumerate(orbits):
        o["id"]=i; o["phase_traj"]=phase_grid(o,cfg["PHASE_POINTS"])
    np.savez_compressed(Path(outdir)/"upo_phase_trajectories.npz",**{f"upo_{i}":o["phase_traj"] for i,o in enumerate(orbits)})
    # Cross controls are aligned once to the source family using the strongest
    # allowed exact symmetry/permutation match. This makes cross-UPO controls
    # conservative and independent of arbitrary environment labels.
    aligned={}; alignrows=[]
    for i,s in enumerate(orbits):
        for j,t in enumerate(orbits):
            if i==j:
                aligned[(i,j)]=t["phase_traj"]
                alignrows.append({"source":i,"target":j,"symmetry":"I","shift_phase":0.0,"perm":"identity","trajectory_rms":0.0,"trajectory_max":0.0})
            else:
                g,info=_aligned_target_phase_grid(s,t,cfg); aligned[(i,j)]=g; alignrows.append({"source":i,"target":j,**info})
    af=[]
    for r in alignrows:
        for k in r:
            if k not in af:af.append(k)
    atomic_csv(Path(outdir)/"cross_family_alignment.csv",af,alignrows)

    windows=[]
    for w in STANDARD_WINDOWS+FINE_WINDOWS:
        if w not in windows:windows.append(w)
    records=[]; near_ic=[]; q10=defaultdict(list); q16=defaultdict(list); l10=defaultdict(list); l16=defaultdict(list); reps={}
    for i,source in enumerate(orbits):
        for s in range(cfg["N_NEAR"]):
            try:
                Rinit=generate_near_state(source["R0"],target_energy,rng,cfg["PERTURBATION_SCALE"])
                total=cfg["N_PERIODS"]*source["T"]; nt=cfg["N_PERIODS"]*cfg["POINTS_PER_PERIOD"]+1
                times,tr=integrate_grid(Rinit,total,nt,rtol=1e-9,atol=1e-11); drift,_,_=energy_drift(tr)
                near_ic.append({"source":i,"sample":s,"energy":energy_bloch(Rinit),"energy_drift":drift,"R_json":json.dumps(Rinit.tolist())})
                Qs={}
                for j,target in enumerate(orbits):
                    Q=overlap_matrix(tr,aligned[(i,j)]); Qs[j]=Q
                    if s==0:reps[(i,j)]=Q
                    for w0,w1 in windows:
                        i0=w0*cfg["POINTS_PER_PERIOD"]; i1=min(w1*cfg["POINTS_PER_PERIOD"]+1,len(times))
                        if i1-i0<4:continue
                        C,Rcoh=phase_lock_metrics(Q,times,target["T"],i0,i1)
                        Cn,Rn=surrogate_null(Q,times,source["T"],target["T"],i0,i1,cfg["N_SURROGATES"],rng)
                        records.append({"source":i,"target":j,"sample":s,"scheme":"standard" if (w0,w1) in STANDARD_WINDOWS else "fine",
                            "window_start":w0,"window_end":w1,"C":C,"R":Rcoh,"C_null_mean":float(np.mean(Cn)),"R_null_mean":float(np.mean(Rn)),
                            "C_null_p_empirical":float((1+np.sum(Cn>=C))/(len(Cn)+1)),"R_null_p_empirical":float((1+np.sum(Rn>=Rcoh))/(len(Rn)+1))})
                a=10*cfg["POINTS_PER_PERIOD"]; b=16*cfg["POINTS_PER_PERIOD"]+1; c=16*cfg["POINTS_PER_PERIOD"]; d=20*cfg["POINTS_PER_PERIOD"]+1
                q,l=_q_window_stats(Qs[i],a,b); q10[i].append(q); l10[i].append(l)
                q,l=_q_window_stats(Qs[i],c,d); q16[i].append(q); l16[i].append(l)
                p(f"N={N} near UPO {i}: {s+1}/{cfg['N_NEAR']}")
            except Exception as exc:p(f"WARNING N={N} near source={i} sample={s} skipped: {exc}")
    atomic_csv(Path(outdir)/"near_initial_conditions.csv",["source","sample","energy","energy_drift","R_json"],near_ic)
    if reps:np.savez_compressed(Path(outdir)/"representative_Q_matrices.npz",**{f"source_{i}_target_{j}":Q for (i,j),Q in reps.items()})
    generic_rows=generic_same_energy_ensemble(cfg,target_energy,rng,orbits,outdir)
    atomic_csv(Path(outdir)/"phase_locking_raw.csv",["source","target","sample","scheme","window_start","window_end","C","R","C_null_mean","R_null_mean","C_null_p_empirical","R_null_p_empirical"],records)

    aggs=[]
    for i in range(len(orbits)):
        for w0,w1 in STANDARD_WINDOWS:
            a=aggregate_scar_window(records,i,w0,w1,"standard",len(orbits)); aggs += [a] if a else []
        for w0,w1 in FINE_WINDOWS:
            a=aggregate_scar_window(records,i,w0,w1,"fine",len(orbits)); aggs += [a] if a else []
    for pkey,qkey in [("pCcross","qCcross"),("pCnull","qCnull"),("pRnull","qRnull")]:
        qq=benjamini_hochberg([a[pkey] for a in aggs])
        for a,v in zip(aggs,qq):a[qkey]=float(v) if np.isfinite(v) else np.nan
    for a in aggs:
        cross_ok=bool(a["cross_available"] and a["Cself"]>a["Ccross"] and a["qCcross"]<ALPHA)
        null_ok=bool(a["Cself"]>a["Cnull"] and a["qCnull"]<ALPHA and a["Rself"]>a["Rnull"] and a["qRnull"]<ALPHA)
        a["passed"]=bool(cross_ok and null_ok)
    aggfields=["source","scheme","window_start","window_end","n_samples","Cself","Ccross","Cnull","Rself","Rcross","Rnull","C_self_cross_ratio","C_self_null_ratio","R_margin","pCcross","pCnull","pRnull","qCcross","qCnull","qRnull","cross_available","passed"]
    atomic_csv(Path(outdir)/"window_summary.csv",aggfields,aggs)

    summary=[]
    for i,o in enumerate(orbits):
        std=[a for a in aggs if a["source"]==i and a["scheme"]=="standard"]
        fine=sorted([a for a in aggs if a["source"]==i and a["scheme"]=="fine"],key=lambda a:a["window_start"])
        pv=[bool(a["passed"]) for a in fine]; contiguous=2.0
        for a in fine:
            if a["window_start"]<=contiguous+1e-9 and a["passed"]:contiguous=float(a["window_end"])
            elif a["window_start"]<=contiguous+1e-9:break
        last=max([float(a["window_end"]) for a in fine if a["passed"]],default=0.0); transitions=sum(pv[k]!=pv[k-1] for k in range(1,len(pv)))
        gr=[r for r in generic_rows if int(r["target_orbit"])==i]
        g10=np.array([float(r["Qbar_10_16"]) for r in gr]); g16=np.array([float(r["Qbar_16_20"]) for r in gr])
        gl10=np.array([float(r["mean_logQ_perTLS_10_16"]) for r in gr]); gl16=np.array([float(r["mean_logQ_perTLS_16_20"]) for r in gr])
        n10=np.array(q10[i]); n16=np.array(q16[i]); nl10=np.array(l10[i]); nl16=np.array(l16[i])
        def loc(near,gen,nlog,glog):
            enh=float(np.mean(near)/np.mean(gen)); logenh=float(math.log(enh)/M); root=float(math.exp(logenh))
            return enh,root,logenh,float(np.mean(nlog)-np.mean(glog)),safe_mannwhitney(near,gen,"greater"),safe_mannwhitney(nlog,glog,"greater")
        e10,r10,le10,dl10,p10,pl10=loc(n10,g10,nl10,gl10); e16,r16,le16,dl16,p16,pl16=loc(n16,g16,nl16,gl16)
        summary.append({"orbit":i,"T":o["T"],"rho":o["rho"],"lambda":o["lambda"],"lambda_over_omega":o["lambda"]/(2*np.pi/o["T"]),
            "standard_pass_count":sum(bool(a["passed"]) for a in std),"fine_pass_fraction":float(np.mean(pv)),"contiguous_phase_memory_end_T":contiguous,
            "last_passing_window_end_T":last,"pass_fail_transitions":transitions,"intermittent":bool(transitions>=2 or last>contiguous+1e-9),
            "Qenh_10_16":e10,"Qenh_root_perTLS_10_16":r10,"log_Qenh_perTLS_10_16":le10,"delta_mean_logQ_perTLS_10_16":dl10,"Q_p_10_16":p10,"logQ_p_10_16":pl10,
            "Qenh_16_20":e16,"Qenh_root_perTLS_16_20":r16,"log_Qenh_perTLS_16_20":le16,"delta_mean_logQ_perTLS_16_20":dl16,"Q_p_16_20":p16,"logQ_p_16_20":pl16})
    atomic_csv(Path(outdir)/"scar_orbit_summary.csv",list(summary[0].keys()),summary)

    robustness=[]
    for i,o in enumerate(orbits):
        for amp in PERTURBATION_SCALES:
            vals=[]
            for s in range(cfg["ROBUSTNESS_SAMPLES"]):
                try:
                    Ri=generate_near_state(o["R0"],target_energy,rng,amp); times,tr=integrate_grid(Ri,10*o["T"],10*cfg["POINTS_PER_PERIOD"]+1,rtol=2e-9,atol=2e-11)
                    Q=overlap_matrix(tr,o["phase_traj"]); C,Rc=phase_lock_metrics(Q,times,o["T"],2*cfg["POINTS_PER_PERIOD"],6*cfg["POINTS_PER_PERIOD"]+1); vals.append((C,Rc))
                except Exception:pass
            robustness.append({"orbit":i,"amplitude":amp,"n":len(vals),"Cself_2_6":float(np.mean([x[0] for x in vals])) if vals else np.nan,"Rself_2_6":float(np.mean([x[1] for x in vals])) if vals else np.nan})
    atomic_csv(Path(outdir)/"perturbation_robustness.csv",["orbit","amplitude","n","Cself_2_6","Rself_2_6"],robustness)

    # Per-N article figures.
    for metric,filename,ylabel in [("C_self_cross_ratio","specificity_vs_time.png",r"$C_{self}/C_{cross}$"),("R_margin","phase_memory_margin_vs_time.png",r"$R_{self}-R_{null}$")]:
        plt.figure(figsize=(8,5))
        for i in range(len(orbits)):
            aa=[a for a in aggs if a["source"]==i and a["scheme"]=="fine"]
            plt.plot([0.5*(a["window_start"]+a["window_end"]) for a in aa],[a[metric] for a in aa],marker="o",label=f"UPO {i}")
        plt.xlabel("Time (source periods)"); plt.ylabel(ylabel); plt.title(f"N={N}: {ylabel}"); plt.legend(fontsize=8); plt.tight_layout(); plt.savefig(Path(outdir)/filename,dpi=300); plt.close()
    plt.figure(figsize=(7,5)); plt.scatter([s["lambda_over_omega"] for s in summary],[s["fine_pass_fraction"] for s in summary]); plt.xlabel(r"$\lambda_F/\omega$"); plt.ylabel("Fine-window pass fraction"); plt.title(f"N={N}: phase memory vs local instability"); plt.tight_layout(); plt.savefig(Path(outdir)/"instability_vs_phase_memory.png",dpi=300); plt.close()
    mark_stage(outdir,"scar_final_v1",{"n_independent_upos":len(orbits),"summary_rows":len(summary)})
    return summary

# ============================================================================
# NONLINEAR STATIONARY STATES -- COMPLETE SCALAR ROOT ENUMERATION
# ============================================================================


def _stationary_scalar_f(Z,s0,S):
    omi=2*Ei+Lambda*Z; zi_unit=omi/math.sqrt((2*Di)**2+omi**2)
    sumz=S*zi_unit; oms=2*epsilon+Lambda*sumz
    return Z - s0*oms/math.sqrt((2*delta)**2+oms**2)


def _stationary_roots_for_signature(s0,S):
    # For the article model epsilon=Ei=0 the fixed-point equations reduce
    # analytically to one zero root plus, above the pitchfork threshold, an
    # exact +/- pair.  Using the closed form avoids the spurious near-zero
    # roots that a grid finder can create exactly at |S|=4.
    if abs(epsilon)>1e-15 or abs(Ei)>1e-15:
        raise RuntimeError("Analytic stationary enumeration assumes epsilon=Ei=0")
    roots=[0.0]
    num=(Lambda**4)*(S**2) - 16*(delta**2)*(Di**2)
    den=4*(delta**2)*(Lambda**2) + (Lambda**4)*(S**2)
    if s0*S>0 and num>1e-13 and den>0:
        z=math.sqrt(num/den)
        if z<1.0-1e-12:
            roots=[-z,0.0,z]
    return roots


def _stationary_state_from_signs_Z(signs,Z):
    omi=2*Ei+Lambda*Z; normi=math.sqrt((2*Di)**2+omi**2)
    zs=np.array([s*omi/normi for s in signs[1:]],float); sumz=float(np.sum(zs)); oms=2*epsilon+Lambda*sumz; norms=math.sqrt((2*delta)**2+oms**2)
    R=[signs[0]*(-2*delta)/norms,0.0,Z]
    for s,z in zip(signs[1:],zs):R += [s*(-2*Di)/normi,0.0,z]
    return np.asarray(R,float),np.array([Z,*zs],float)


def _family_product_overlap_stationary(Rstate,Rorbit):
    # Permutation- and P/T-family-invariant stationary-to-UPO projection.
    vals=[]
    envs=Rstate[3:].reshape(N,3); sys=Rstate[:3]
    for Rt in Rorbit:
        best=0.0
        for sym in SYMMETRY_NAMES:
            B=_apply_value_symmetry(Rt,sym); sf=max(0.0,0.5*(1+np.dot(sys,B[:3])))
            eb=B[3:].reshape(N,3); F=np.clip(0.5*(1+envs@eb.T),1e-300,1.0)
            rr,cc=linear_sum_assignment(-np.log(F)); q=sf*float(np.exp(np.sum(np.log(F[rr,cc])))); best=max(best,q)
        vals.append(best)
    return np.asarray(vals,float)


def stationary_stage(cfg,target_energy,outdir,rng):
    if stage_done(outdir,"stationary_final_v1"):
        return read_json(Path(outdir)/"stationary_summary.json",{})
    p(f"\n===== N={N}: COMPLETE NONLINEAR STATIONARY ENUMERATION =====")
    upos=load_orbits(Path(outdir)/"selected_independent_upos.csv")
    for o in upos:o["phase_traj"]=phase_grid(o,max(500,cfg["PHASE_POINTS"]))
    # Solve only inequivalent sign-count signatures, then expand exact branch
    # multiplicities. This is complete for identical environment TLSs and avoids
    # stochastic least-squares under/over-counting.
    sigroots={}; classrows=[]; rawrows=[]; cid=0; rawid=0
    for s0 in (-1,1):
        for kplus in range(N+1):
            S=2*kplus-N; roots=_stationary_roots_for_signature(s0,S); sigroots[(s0,kplus)]=roots
            for rid,Z in enumerate(roots):
                signs=(float(s0),)+tuple([1.0]*kplus+[-1.0]*(N-kplus)); R,v=_stationary_state_from_signs_Z(signs,Z)
                E=energy_bloch(R); dyn=float(np.linalg.norm(bloch_rhs(0,R))); mult=math.comb(N,kplus)
                # Global P pairs +/-Z roots; class key by |Z|. We still keep every
                # exact root below, while reporting a parity-reduced class id.
                pkey=(s0,kplus,round(abs(Z),8))
                qdata={}
                for j,o in enumerate(upos):
                    q=_family_product_overlap_stationary(R,o["phase_traj"]); qdata[f"Qfamily_mean_UPO{j}"]=float(np.mean(q)); qdata[f"Qfamily_max_UPO{j}"]=float(np.max(q))
                classrows.append({"class_id_raw":cid,"s0":s0,"kplus":kplus,"S_env_sign":S,"root_index":rid,"Z":Z,"energy":E,"deltaE_target":E-target_energy,
                                  "environment_permutation_multiplicity":mult,"dynres":dyn,**qdata}); cid+=1
    # Assign parity-reduced class IDs deterministically.
    keys={}; nextid=0
    for r in classrows:
        key=(r["s0"],r["kplus"],round(abs(float(r["Z"])),7))
        if key not in keys:keys[key]=nextid; nextid+=1
        r["symmetry_class_id"]=keys[key]
    # Expand all labelled branches for an audit table (<= a few thousand rows at N=10).
    for s0 in (-1,1):
        for envbits in product([-1.0,1.0],repeat=N):
            kplus=sum(1 for s in envbits if s>0); roots=sigroots[(s0,kplus)]; signs=(float(s0),)+tuple(envbits)
            for rid,Z in enumerate(roots):
                R,v=_stationary_state_from_signs_Z(signs,Z); E=energy_bloch(R)
                row={"state":rawid,"s0":s0,"kplus":kplus,"root_index":rid,"Z":Z,"energy":E,"deltaE_target":E-target_energy,"dynres":float(np.linalg.norm(bloch_rhs(0,R))),"signs":" ".join(str(int(x)) for x in signs)}
                for j,x in enumerate(v):row[f"v{j}"]=x
                rawrows.append(row); rawid+=1
    rf=list(rawrows[0].keys()) if rawrows else ["state"]
    atomic_csv(Path(outdir)/"stationary_states_raw.csv",rf,rawrows)
    cf=[]
    for r in classrows:
        for k in r:
            if k not in cf:cf.append(k)
    atomic_csv(Path(outdir)/"stationary_symmetry_classes.csv",cf,classrows)
    gaps=[abs(r["deltaE_target"]) for r in classrows]
    summary={"N":N,"labelled_stationary_solutions":len(rawrows),"environment_permutation_classes":len(classrows),"parity_and_permutation_classes":nextid,
             "closest_abs_deltaE":float(min(gaps)) if gaps else None,"complete_scalar_enumeration":True}
    write_json(Path(outdir)/"stationary_summary.json",summary)
    if classrows:
        plt.figure(figsize=(8,5)); plt.scatter(np.arange(len(classrows)),[r["energy"] for r in classrows],s=12); plt.axhline(target_energy,ls="--"); plt.xlabel("Stationary symmetry-class root"); plt.ylabel("Energy"); plt.title(f"N={N}: complete nonlinear stationary spectrum"); plt.tight_layout(); plt.savefig(Path(outdir)/"stationary_energy_spectrum.png",dpi=300); plt.close()
    mark_stage(outdir,"stationary_final_v1",summary); p("Stationary summary:",summary); return summary

# ============================================================================
# PER-N REPORT
# ============================================================================


def per_n_report(n,outdir,target_energy):
    data={"N":n,"target_energy":target_energy,"energy_density":target_energy/(n+1)}
    for key,file in [("chaos","chaos_summary.json"),("stationary","stationary_summary.json")]:
        if (Path(outdir)/file).exists():data[key]=read_json(Path(outdir)/file,{})
    if (Path(outdir)/"independent_clear_upos.csv").exists():
        oo=load_orbits(Path(outdir)/"independent_clear_upos.csv")
        data["independent_upos"]=[{"T":o["T"],"rho":o["rho"],"lambda":o["lambda"],"lambda_over_omega":o["lambda"]/(2*np.pi/o["T"]),"return_D":o["return_D"]} for o in oo]
    if (Path(outdir)/"scar_orbit_summary.csv").exists():data["scar_orbits"]=read_csv(Path(outdir)/"scar_orbit_summary.csv")
    write_json(Path(outdir)/"N_REPORT.json",data)
    return data


# ============================================================================
# CROSS-N ARTICLE COMPARISON -- N=2,4,6,8,10
# ============================================================================


def ffloat(x):
    try:return float(x)
    except:return np.nan


def bbool(x):return str(x).lower() in ("true","1","yes")


def _finite_mean(v):
    a=np.asarray([ffloat(x) for x in v],float); a=a[np.isfinite(a)]; return float(np.mean(a)) if len(a) else np.nan


def _plot_line(xs,ys,xlabel,ylabel,title,path):
    plt.figure(figsize=(7.5,5)); plt.plot(xs,ys,marker="o"); plt.xlabel(xlabel); plt.ylabel(ylabel); plt.xticks(xs); plt.title(title); plt.tight_layout(); plt.savefig(path,dpi=300); plt.close()


def compare_all(root,Ns):
    comp=Path(root)/"COMPARISON"; ensure_dir(comp); main=[]; upos=[]; wins=[]; shellrows=[]
    for n in Ns:
        d=Path(root)/f"N{n}"; chaos=read_json(d/"chaos_summary.json",{}) or {}; stat=read_json(d/"stationary_summary.json",{}) or {}; shell=read_json(d/"energy_shell.json",{}) or {}
        scar=read_csv(d/"scar_orbit_summary.csv"); win=read_csv(d/"window_summary.csv")
        shellrows.append(shell)
        for r in scar:upos.append({"N":n,**r})
        for r in win:wins.append({"N":n,**r})
        sf={}
        for w0,w1 in STANDARD_WINDOWS:
            rr=[r for r in win if r["scheme"]=="standard" and int(float(r["window_start"]))==w0 and int(float(r["window_end"]))==w1]
            sf[f"pass_fraction_{w0}_{w1}"]=float(np.mean([bbool(r["passed"]) for r in rr]))
        main.append({"N":n,"energy_density":REFERENCE_ENERGY_DENSITY,"E_over_Emax":shell.get("E_over_Emax"),"mean_ftle":chaos.get("mean_ftle"),"median_ftle":chaos.get("median_ftle"),"max_ftle":chaos.get("max_ftle"),"fraction_positive_ftle":chaos.get("fraction_positive"),
            "n_independent_upos":len(scar),**sf,"mean_fine_pass_fraction":_finite_mean([r["fine_pass_fraction"] for r in scar]),"median_contiguous_phase_memory_T":float(np.median([ffloat(r["contiguous_phase_memory_end_T"]) for r in scar])),"median_last_pass_T":float(np.median([ffloat(r["last_passing_window_end_T"]) for r in scar])),"intermittent_fraction":float(np.mean([bbool(r["intermittent"]) for r in scar])),
            "mean_Qenh_16_20":_finite_mean([r["Qenh_16_20"] for r in scar]),"mean_Qenh_root_perTLS_16_20":_finite_mean([r["Qenh_root_perTLS_16_20"] for r in scar]),"mean_log_Qenh_perTLS_16_20":_finite_mean([r["log_Qenh_perTLS_16_20"] for r in scar]),"mean_delta_logQ_perTLS_16_20":_finite_mean([r["delta_mean_logQ_perTLS_16_20"] for r in scar]),
            "stationary_classes":stat.get("parity_and_permutation_classes"),"stationary_gap":stat.get("closest_abs_deltaE")})
    atomic_csv(comp/"ARTICLE_TABLE_FINITE_SIZE.csv",list(main[0].keys()),main)
    uf=[]
    for r in upos:
        for k in r:
            if k not in uf:uf.append(k)
    atomic_csv(comp/"ARTICLE_TABLE_UPO_LEVEL.csv",uf,upos)
    wf=[]
    for r in wins:
        for k in r:
            if k not in wf:wf.append(k)
    atomic_csv(comp/"ARTICLE_TABLE_ALL_WINDOWS.csv",wf,wins)
    sfld=[]
    for r in shellrows:
        for k in r:
            if k not in sfld:sfld.append(k)
    atomic_csv(comp/"ARTICLE_ENERGY_SHELLS.csv",sfld,shellrows)

    fine=[]
    for n in Ns:
        rr=[r for r in wins if int(r["N"])==n and r["scheme"]=="fine"]
        for w0,w1 in FINE_WINDOWS:
            q=[r for r in rr if int(float(r["window_start"]))==w0 and int(float(r["window_end"]))==w1]
            fine.append({"N":n,"window_start":w0,"window_end":w1,"midpoint":0.5*(w0+w1),"n_upos":len(q),"pass_fraction":float(np.mean([bbool(r["passed"]) for r in q])),"mean_Cself":_finite_mean([r["Cself"] for r in q]),"mean_Ccross":_finite_mean([r["Ccross"] for r in q]),"mean_Cnull":_finite_mean([r["Cnull"] for r in q]),"mean_R_margin":_finite_mean([r["R_margin"] for r in q])})
    atomic_csv(comp/"ARTICLE_FINE_WINDOW_SCALING.csv",list(fine[0].keys()),fine)

    xs=[r["N"] for r in main]
    for key,label,name in [("median_ftle","Median FTLE","FTLE_median_vs_N.png"),("mean_fine_pass_fraction","Mean phase-memory pass fraction","phase_memory_pass_vs_N.png"),("median_contiguous_phase_memory_T","Median contiguous phase memory (T)","contiguous_phase_memory_vs_N.png"),("median_last_pass_T","Median last passing window end (T)","last_pass_vs_N.png"),("mean_Qenh_16_20","Raw Q enhancement 16-20T","Qenh_raw_vs_N.png"),("mean_Qenh_root_perTLS_16_20","Per-TLS geometric Q enhancement 16-20T","Qenh_perTLS_vs_N.png"),("mean_log_Qenh_perTLS_16_20","log(Q enhancement)/(N+1)","log_Qenh_perTLS_vs_N.png"),("stationary_gap","Closest stationary |dE|","stationary_gap_vs_N.png"),("E_over_Emax","Target E / Emax","energy_shell_position_vs_N.png")]:
        _plot_line(xs,[ffloat(r[key]) for r in main],"Environment TLS count N",label,label+" vs N",comp/name)
    # Matched fine-window heat map.
    mat=np.full((len(Ns),len(FINE_WINDOWS)),np.nan)
    for i,n in enumerate(Ns):
        for j,(w0,w1) in enumerate(FINE_WINDOWS):
            q=[r for r in fine if r["N"]==n and r["window_start"]==w0 and r["window_end"]==w1]
            if q:mat[i,j]=q[0]["pass_fraction"]
    plt.figure(figsize=(10,5)); im=plt.imshow(mat,aspect="auto",vmin=0,vmax=1); plt.colorbar(im,label="Fraction of 4 UPO families passing"); plt.yticks(range(len(Ns)),[f"N={n}" for n in Ns]); plt.xticks(range(len(FINE_WINDOWS)),[f"{a}-{b}T" for a,b in FINE_WINDOWS],rotation=45,ha="right"); plt.title("Phase-specific UPO memory across environment size"); plt.tight_layout(); plt.savefig(comp/"phase_memory_heatmap.png",dpi=300); plt.close()
    # All-N fine curves.
    plt.figure(figsize=(8.5,5))
    for n in Ns:
        rr=[r for r in fine if r["N"]==n]; plt.plot([r["midpoint"] for r in rr],[r["pass_fraction"] for r in rr],marker="o",label=f"N={n}")
    plt.xlabel("Window midpoint (periods)"); plt.ylabel("Pass fraction"); plt.title("Matched phase-memory windows"); plt.legend(); plt.tight_layout(); plt.savefig(comp/"fine_pass_fraction_vs_time_allN.png",dpi=300); plt.close()
    # Orbit-level instability vs memory.
    plt.figure(figsize=(8,5))
    for n in Ns:
        rr=[r for r in upos if int(r["N"])==n]; plt.scatter([ffloat(r["lambda_over_omega"]) for r in rr],[ffloat(r["fine_pass_fraction"]) for r in rr],label=f"N={n}")
    plt.xlabel(r"$\lambda_F/\omega$"); plt.ylabel("Fine-window phase-memory pass fraction"); plt.title("Local UPO instability vs dynamical memory"); plt.legend(); plt.tight_layout(); plt.savefig(comp/"instability_vs_phase_memory_allN.png",dpi=300); plt.close()

    diag={"Ns":Ns,"energy_density":REFERENCE_ENERGY_DENSITY,"generated_utc":utcnow(),"required_independent_upos_per_N":REQUIRED_INDEPENDENT_UPOS_DEFAULT,"caveat":"Five finite sizes support a descriptive finite-environment trend, not a universal thermodynamic scaling exponent. UPOs within a given N are orbit-level samples, not independent system sizes."}
    x=np.asarray(xs,float)
    for key in ["median_ftle","mean_fine_pass_fraction","median_contiguous_phase_memory_T","median_last_pass_T","mean_log_Qenh_perTLS_16_20"]:
        y=np.asarray([ffloat(r[key]) for r in main]); mask=np.isfinite(y)
        if np.sum(mask)>=4:
            rr,pv=spearmanr(x[mask],y[mask]); diag[f"spearman_N_vs_{key}"]={"rho":float(rr),"p":float(pv),"n":int(np.sum(mask))}
    write_json(comp/"ARTICLE_SCALING_DIAGNOSTICS.json",diag)
    lines=["FINAL FINITE-ENVIRONMENT DYNAMICAL-SCARRING DATASET","",f"Fixed extensive energy density E/(N+1) = {REFERENCE_ENERGY_DENSITY:.15f}","N = 2,4,6,8,10; exactly four exact-symmetry-inequivalent hyperbolic UPO families are required at every N.","","Independence quotient used: time origin + environment permutations + global P + time reversal T + PT. Multiple covers are reduced before Floquet analysis.","Cross-UPO controls are aligned with the best allowed family symmetry/permutation before comparison.","Phase-specific orbital memory and phase-space localization Q are reported separately.","Raw Q enhancement is accompanied by intensive log and per-TLS geometric normalizations.","The target shell uses fixed energy density; ARTICLE_ENERGY_SHELLS.csv reports its relative location inside the exact classical energy bounds.","","N-level summary:"]
    for r in main:
        lines.append(f"N={r['N']}: median FTLE={r['median_ftle']}; pass 2-6/6-10/10-16={r['pass_fraction_2_6']}/{r['pass_fraction_6_10']}/{r['pass_fraction_10_16']}; median contiguous memory={r['median_contiguous_phase_memory_T']}T; median last pass={r['median_last_pass_T']}T; raw Qenh16-20={r['mean_Qenh_16_20']}; per-TLS Qenh16-20={r['mean_Qenh_root_perTLS_16_20']}; log-enh/TLS={r['mean_log_Qenh_perTLS_16_20']}; stationary gap={r['stationary_gap']}")
    lines += ["","Use ARTICLE_TABLE_UPO_LEVEL.csv and ARTICLE_TABLE_ALL_WINDOWS.csv for the manuscript statistics; do not infer a universal scaling exponent from five N values alone."]
    (comp/"ARTICLE_RESULTS_SUMMARY.txt").write_text("\n".join(lines)+"\n")
    write_json(comp/"ARTICLE_RESULTS_SUMMARY.json",{"finite_size_table":main,"diagnostics":diag,"schema":SCHEMA_VERSION})
    return main

# ============================================================================
# REPRODUCIBILITY MANIFEST
# ============================================================================


def write_manifest(root):
    root=Path(root); rows=[]
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.name=="MANIFEST_SHA256.csv":continue
        h=hashlib.sha256()
        try:
            with open(path,"rb") as f:
                for chunk in iter(lambda:f.read(1024*1024),b""):h.update(chunk)
            rows.append({"file":str(path.relative_to(root)),"bytes":path.stat().st_size,"sha256":h.hexdigest()})
        except Exception:pass
    atomic_csv(root/"MANIFEST_SHA256.csv",["file","bytes","sha256"],rows)


# ============================================================================
# MASTER DRIVER -- FINAL N=2,4,6,8,10 DATASET
# ============================================================================


def _legacy_catalog_paths(n,base):
    b=Path(base); c=[
        b/"ARTICLE_N248"/f"N{n}"/"periodic_orbits_raw.csv",
        b/"ARTICLE_N248"/f"N{n}"/"periodic_orbits_all_valid.csv",
        b/"ARTICLE_N248"/f"N{n}"/"independent_clear_upos.csv",
        b/f"N{n}_scar_results"/f"N{n}_same_energy_upos.csv",
        b/f"N{n}_scar_results"/"independent_clear_upos.csv",
        b/f"N{n}_same_energy_upos.csv",
    ]
    return [x for x in c if x.exists()]


def import_all_legacy_candidates(n,base,target,cfg,outdir):
    accepted=[]; audit=[]
    for path in _legacy_catalog_paths(n,base):
        p(f"N={n}: revalidating seed catalogue {path}")
        try:rows=read_csv(path)
        except Exception as exc:
            audit.append({"file":str(path),"row":"ALL","status":"read_error","note":str(exc)}); continue
        for ri,row in enumerate(rows):
            try:
                o=row_to_orbit(row); o["source"]=f"legacy:{path}"; v=validate_orbit(o,target,cfg)
                if v is None:audit.append({"file":str(path),"row":ri,"status":"rejected","note":"current validation failed"}); continue
                # Keep only clear candidates as search seeds; marginal orbits are not useful for the required catalogue.
                if v["rho"]>=cfg["CLEAR_UPO_RHO"]:
                    accepted.append(v); audit.append({"file":str(path),"row":ri,"status":"accepted_clear","T":v["T"],"rho":v["rho"]})
            except Exception as exc:audit.append({"file":str(path),"row":ri,"status":"error","note":str(exc)})
    # Remove literal duplicates but intentionally retain symmetry copies here;
    # the exact family quotient is documented by deduplicate_orbits.
    uniq=[]
    for o in accepted:
        if not any(abs(o["T"]-q["T"])/min(o["T"],q["T"])<1e-11 and np.linalg.norm(o["R0"]-q["R0"])<1e-9 for q in uniq):uniq.append(o)
    if audit:
        fields=[]
        for r in audit:
            for k in r:
                if k not in fields:fields.append(k)
        atomic_csv(Path(outdir)/"legacy_revalidation_audit.csv",fields,audit)
    save_orbits(Path(outdir)/"legacy_revalidated_clear_candidates.csv",uniq)
    return uniq


def _choose_exactly_required(reps,cfg):
    req=cfg["REQUIRED_INDEPENDENT_UPOS"]
    if len(reps)<req:raise RuntimeError(f"Only {len(reps)} independent families; {req} required")
    if len(reps)==req:return list(reps)
    # Deterministic diversity selection in period and local instability only;
    # no scar/localization outcome enters the selection.
    feats=np.array([[math.log(max(o["T"],1e-9)),math.log1p(max(o["lambda"]/(2*np.pi/o["T"]),0))] for o in reps])
    mu=feats.mean(0); sd=np.where(feats.std(0)>1e-12,feats.std(0),1); z=(feats-mu)/sd
    chosen=[int(np.argmin(feats[:,1])),int(np.argmax(feats[:,1]))]
    chosen=list(dict.fromkeys(chosen))
    while len(chosen)<req:
        remaining=[i for i in range(len(reps)) if i not in chosen]
        d=[min(np.linalg.norm(z[i]-z[j]) for j in chosen) for i in remaining]; chosen.append(remaining[int(np.argmax(d))])
    return [reps[i] for i in chosen[:req]]


def prepare_n_environment(outdir,n,cfg,target,args):
    ensure_dir(outdir); shell=energy_shell_diagnostics(n,target); write_json(Path(outdir)/"energy_shell.json",shell)
    write_json(Path(outdir)/"run_config.json",{"schema":SCHEMA_VERSION,"N":n,"M":n+1,"epsilon":epsilon,"delta":delta,"Ei":Ei,"Di":Di,"Lambda":Lambda,"target_energy":target,"energy_density":target/(n+1),"master_seed":args.seed,"quick":args.quick,"settings":cfg,"standard_windows":STANDARD_WINDOWS,"fine_windows":FINE_WINDOWS,"perturbation_scales":PERTURBATION_SCALES})
    write_json(Path(outdir)/"environment.json",{"generated_utc":utcnow(),"hostname":platform.node(),"python":platform.python_version(),"numpy":np.__version__,"scipy":scipy.__version__,"matplotlib":matplotlib.__version__,"slurm_job_id":os.environ.get("SLURM_JOB_ID"),"slurm_job_name":os.environ.get("SLURM_JOB_NAME")})


def run_one_n(n,root,args):
    set_model(n); outdir=Path(root)/f"N{n}"; cfg=config_for_n(n,args.quick,args.required_upos); target=target_energy_for_n(n); ensure_dir(outdir)
    prepare_n_environment(outdir,n,cfg,target,args); rng=np.random.default_rng(args.seed+1000*n)
    p("\n"+"="*96); p(f"FINAL ARTICLE PIPELINE N={n}: E={target:.12f}, E/(N+1)={target/(n+1):.12f}, required independent UPOs={cfg['REQUIRED_INDEPENDENT_UPOS']}"); p("="*96)
    validate_exact_symmetries(outdir,np.random.default_rng(args.seed+777*n))
    stage_chaos(cfg,target,outdir,rng)
    seeds=[] if args.no_legacy else import_all_legacy_candidates(n,args.legacy_base,target,cfg,outdir)
    found=search_periodic_orbits(cfg,target,outdir,rng,seeds,force_search=args.force_search)
    clear=[o for o in found if o["rho"]>=cfg["CLEAR_UPO_RHO"]]
    reps,classes=deduplicate_orbits(clear,cfg,outdir,"FINAL_exact_symmetry_clear")
    if len(reps)<cfg["REQUIRED_INDEPENDENT_UPOS"]:
        raise SearchIncomplete(f"N={n}: final exact-symmetry audit has {len(reps)}/{cfg['REQUIRED_INDEPENDENT_UPOS']} families")
    selected=_choose_exactly_required(reps,cfg); save_orbits(outdir/"all_independent_clear_upos.csv",reps); save_orbits(outdir/"selected_independent_upos.csv",selected); save_orbits(outdir/"independent_clear_upos.csv",selected)
    write_json(outdir/"upo_family_summary.json",{"raw_valid_periodic_orbits":len(found),"clear_candidates":len(clear),"independent_exact_symmetry_families":len(reps),"selected_for_matched_analysis":len(selected),"family_sizes":[len(c) for c in classes],"required":cfg["REQUIRED_INDEPENDENT_UPOS"]})
    # Final validation archive.
    fb={}; vr=[]
    for i,o in enumerate(selected):
        v=validate_orbit(o,target,cfg)
        if v is None:raise RuntimeError(f"Selected UPO {i} failed final revalidation")
        selected[i]=v; tt,tr=integrate_grid(v["R0"],v["T"],1400,rtol=1.5e-10,atol=1e-12); drift,_,_=energy_drift(tr)
        fb[f"orbit_time_{i}"]=tt; fb[f"orbit_traj_{i}"]=tr; fb[f"monodromy_{i}"]=v["Mphys"]; fb[f"eigvals_{i}"]=v["eigvals"]
        vr.append({"orbit":i,"T":v["T"],"return_D":v["return_D"],"energy":v["energy"],"energy_drift_over_period":drift,"rho":v["rho"],"lambda":v["lambda"],"lambda_over_omega":v["lambda"]/(2*np.pi/v["T"]),"det_M":v["det"],"symplectic_error":v.get("symplectic_error"),"reciprocal_pair_error":v.get("reciprocal_pair_error"),"floquet_method":v.get("floquet_method"),"canonical_pole_margin":v.get("canonical_pole_margin")})
    save_orbits(outdir/"selected_independent_upos.csv",selected); save_orbits(outdir/"independent_clear_upos.csv",selected)
    np.savez_compressed(outdir/"selected_upo_full_data.npz",**fb)
    atomic_csv(outdir/"selected_upo_validation.csv",list(vr[0].keys()),vr)
    scar_stage(cfg,target,outdir,rng); write_json(outdir/"stationary_summary.json",{"status":"not_run","reason":"analytic epsilon=0 stationary enumerator is not valid for epsilon=1"}); per_n_report(n,outdir,target)


def main():
    parser=argparse.ArgumentParser(description="epsilon=1 CPU pipeline: time-reversal/permutation-independent dynamical scars for N=2,4,6,8,10")
    parser.add_argument("--root",default="ARTICLE_N246810_FINAL")
    parser.add_argument("--Ns",default="2,4,6,8,10")
    parser.add_argument("--required-upos",type=int,default=4,help="exact number of independent hyperbolic UPO families used per N; final study default 4")
    parser.add_argument("--legacy-base",default=str(Path.home()/"scars"),help="prior results are used only as candidates and are fully revalidated")
    parser.add_argument("--no-legacy",action="store_true",help="ignore every prior orbit catalogue and search completely from scratch")
    parser.add_argument("--force-search",action="store_true",help="continue searching even if seeds already satisfy the required family count")
    parser.add_argument("--quick",action="store_true",help="smoke test only; not article quality")
    parser.add_argument("--seed",type=int,default=MASTER_SEED)
    args=parser.parse_args(); Ns=sorted(set(int(x) for x in args.Ns.split(",") if x.strip()))
    if Ns!=sorted(Ns) or any(n not in (2,4,6,8,10) for n in Ns):raise ValueError("Final supported N values are 2,4,6,8,10")
    if not args.quick and args.required_upos!=4:raise ValueError("Final article run intentionally requires exactly 4 UPO families per N")
    root=Path(args.root).resolve(); ensure_dir(root)
    global _INTERRUPTION_FILE; _INTERRUPTION_FILE=root/"INTERRUPTED.json"
    write_json(root/"MASTER_CONFIG.json",{"schema":SCHEMA_VERSION,"Ns":Ns,"required_upos":args.required_upos,"seed":args.seed,"quick":args.quick,"legacy_base":args.legacy_base,"created_utc":utcnow(),"reference_energy_density":REFERENCE_ENERGY_DENSITY})
    write_json(root/"ARTICLE_METHODS_PARAMETERS.json",{"schema":SCHEMA_VERSION,"model":{"epsilon":epsilon,"delta":delta,"Ei":Ei,"Di":Di,"Lambda":Lambda},"energy_matching":{"primary":"fixed E/(N+1)","value":REFERENCE_ENERGY_DENSITY,"rationale":"Hamiltonian is extensive in environment size; exact E bounds and relative shell positions are also stored"},"Ns":Ns,"required_independent_upos_per_N":args.required_upos,"upo_equivalence":"phase origin + fixed environment permutation + exact time reversal T; parity P/PT are broken by central epsilon=1; trajectory-level continuous phase optimization","floquet":"canonical action-angle monodromy with reciprocal-pair/determinant checks; documented Bloch fallback near coordinate poles","statistics":"paired Wilcoxon self-vs-cross/null with Benjamini-Hochberg FDR within each N; Mann-Whitney near-vs-generic localization; raw and intensive log-Q metrics","standard_windows":STANDARD_WINDOWS,"fine_windows":FINE_WINDOWS})
    try:
        shutil.copy2(Path(__file__).resolve(),root/"CODE_USED_scar_article_final_N246810.py")
    except Exception:pass
    try:
        for n in Ns:run_one_n(n,root,args)
        compare_all(root,Ns); write_manifest(root); write_json(root/"PIPELINE_COMPLETE.json",{"schema":SCHEMA_VERSION,"completed_utc":utcnow(),"Ns":Ns,"required_upos":args.required_upos})
        p("\nFINAL PIPELINE COMPLETE"); p("Summary:",root/"COMPARISON"/"ARTICLE_RESULTS_SUMMARY.txt"); p("Manifest:",root/"MANIFEST_SHA256.csv")
    except SearchIncomplete as exc:
        write_json(root/"PIPELINE_NEEDS_RESUME.json",{"time":utcnow(),"message":str(exc),"instruction":"Re-submit exactly the same command. Completed stages and search candidates are checkpointed."}); p("\nSEARCH INCOMPLETE BUT SAFELY CHECKPOINTED:",exc); raise SystemExit(75)
    except SystemExit:raise
    except Exception as exc:
        write_json(root/"PIPELINE_FATAL_ERROR.json",{"time":utcnow(),"type":type(exc).__name__,"message":str(exc),"traceback":traceback.format_exc()}); raise



if __name__=="__main__":
    main()
