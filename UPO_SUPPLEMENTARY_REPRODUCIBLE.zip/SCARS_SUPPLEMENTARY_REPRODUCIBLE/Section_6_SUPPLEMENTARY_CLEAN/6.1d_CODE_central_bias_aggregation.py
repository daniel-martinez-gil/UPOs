#!/usr/bin/env python3
"""Final Section 6.1 aggregation: combine the five validated epsilon=1 datasets and compare them with the final epsilon=0 reference."""
import argparse,csv,hashlib,importlib.util,json,math,os,itertools
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import mannwhitneyu,spearmanr

NS=[2,4,6,8,10]
MAIN_METRICS={
 'S_per_spin':'Collective length |S|/N',
 'restricted_lambda_over_omega':'Fixed-sector lambda/omega',
 'effect_tube_P_2_20':'Tube localization 2-20T',
 'effect_tube_P_16_20':'Tube localization 16-20T',
 'effect_return_peak_1_5':'Return enhancement 1-5T',
 'effect_return_peak_6_10':'Return enhancement 6-10T',
 'effect_F_harmonic_power':'Return Fourier harmonic enhancement',
 'effect_tube_harmonic_power':'Tube Fourier harmonic enhancement',
 'localization_ratio_L2':'Renyi L2 localization ratio',
 'localization_ratio_L4':'Renyi L4 localization ratio',
}

def loadmod(name,path):
 spec=importlib.util.spec_from_file_location(name,str(Path(path).resolve())); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def ensure(p):Path(p).mkdir(parents=True,exist_ok=True)
def rcsv(p):return list(csv.DictReader(open(p,newline='',encoding='utf-8')))
def wcsv(p,rows,fields=None):
 p=Path(p); ensure(p.parent)
 if fields is None:
  fields=[]
  for r in rows:
   for k in r:
    if k not in fields:fields.append(k)
 with open(p,'w',newline='',encoding='utf-8') as f:csv.DictWriter(f,fieldnames=fields,extrasaction='ignore').writeheader(); f.seek(0,2)
 # reopen because writer object lost; simple safe write
 with open(p,'w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
def san(x):
 if isinstance(x,dict):return {str(k):san(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [san(v) for v in x]
 if isinstance(x,np.generic):return san(x.item())
 if isinstance(x,float) and not np.isfinite(x):return None
 return x
def jdump(p,o):
 p=Path(p);ensure(p.parent);json.dump(san(o),open(p,'w'),indent=2,allow_nan=False)
def af(x):
 try:
  y=float(x);return y if np.isfinite(y) else np.nan
 except:return np.nan

def mean(rows,key):
 a=np.array([af(r.get(key)) for r in rows]);a=a[np.isfinite(a)];return float(np.mean(a)) if len(a) else np.nan

def exact_spearman_5(x,y):
 x=np.asarray(x,float);y=np.asarray(y,float);obs=float(spearmanr(x,y).statistic);vals=[]
 for perm in itertools.permutations(y):vals.append(float(spearmanr(x,np.array(perm)).statistic))
 p=float(np.mean(np.abs(vals)>=abs(obs)-1e-15));return {'rho':obs,'p_exact':p,'n':len(y)}

def exact_signflip(d):
 d=np.asarray(d,float);obs=abs(float(np.mean(d)));vals=[]
 for signs in itertools.product([-1.,1.],repeat=len(d)):vals.append(abs(float(np.mean(d*np.array(signs)))))
 return {'mean_difference':float(np.mean(d)),'median_difference':float(np.median(d)),'p_exact_two_sided':float(np.mean(np.array(vals)>=obs-1e-15)),'n_N':len(d)}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--core',required=True);ap.add_argument('--metrics',required=True);ap.add_argument('--baseline-dir',default='',help='Optional legacy epsilon=0 comparison directory; not required for the final reproducible workflow, which compares models in 6.3')
 a=ap.parse_args();root=Path(a.root).resolve();comp=root/'COMPARISON';ensure(comp);metrics=loadmod('eps1_metrics_agg',a.metrics);core=loadmod('eps1_core_agg',a.core)
 # hard gate: all five N tasks complete and validated
 allrows=[]
 for N in NS:
  nd=root/f'N{N}'
  if not (nd/'DONE.json').exists():raise RuntimeError(f'N={N} missing DONE.json')
  val=json.load(open(nd/'FINAL_N_VALIDATION.json'))
  if not val.get('PASS'):raise RuntimeError(f'N={N} failed final validation: {val}')
  rows=rcsv(nd/'EPS1_UPO_SUMMARIES.csv')
  if len(rows)!=4:raise RuntimeError(f'N={N}: expected 4 summary rows, got {len(rows)}')
  allrows.extend(rows)
 if len(allrows)!=20:raise RuntimeError('not exactly 20 epsilon=1 families')
 # Copy per-N standard metric folders into common tree expected by metrics.aggregate.
 stdroot=root/'FINAL_STANDARD_METRICS';ensure(stdroot)
 import shutil
 for N in NS:
  src=root/f'N{N}'/'STANDARD_METRICS';dst=stdroot/f'N{N}'
  if dst.exists():shutil.rmtree(dst)
  shutil.copytree(src,dst)
 # Build broad chaos rows and standard aggregate using existing tested implementation.
 sector_rows=[];class_maps={}
 for N in NS:
  core.set_model(N); sector_rows.extend(metrics.ftle_sector_audit(core,N,root/f'N{N}'));class_maps[N]={i:i for i in range(4)}
 metrics.aggregate(root,stdroot,NS,allrows,sector_rows,class_maps)
 tests=metrics.apply_fdr(stdroot,NS)
 prim=[r for r in tests if r.get('family')=='primary']
 if len(prim)!=200:raise RuntimeError(f'global primary test count {len(prim)} != 200')
 # final epsilon=1 20-family file
 eps1=sorted(allrows,key=lambda r:(int(r['N']),int(float(r['orbit']))))
 wcsv(comp/'EPS1_FINAL_20_COLLECTIVE_FAMILY_METRICS.csv',eps1)
 # N-level epsilon=1 summary including fixed-sector FTLE.
 nrows=[]
 for N in NS:
  rr=[r for r in eps1 if int(r['N'])==N]
  chaos=[r for r in sector_rows if int(r['N'])==N]
  row={'N':N,'n_collective_families':len(rr),'mean_S_per_spin':mean(rr,'S_per_spin'),'mean_restricted_lambda_over_omega':mean(rr,'restricted_lambda_over_omega'),
       'mean_restricted_heller_sum_over_2pi':mean(rr,'restricted_heller_sum_over_2pi'),'mean_full_lambda_over_omega':mean(rr,'lambda_max_over_omega'),
       'mean_sector_ftle_median_180':mean(rr,'sector_ftle_median_180'),'mean_sector_ftle_relchange_120_to_180':mean(rr,'sector_ftle_median_relchange_120_to_180'),
       'broad_fullspace_ftle_mean':mean(chaos,'ftle'),'broad_fullspace_ftle_median':float(np.median([af(r['ftle']) for r in chaos])) if chaos else np.nan,
       'mean_tube_P_16_20':mean(rr,'effect_tube_P_16_20'),'mean_tube_P_2_20':mean(rr,'effect_tube_P_2_20'),'mean_return_peak_1_5':mean(rr,'effect_return_peak_1_5'),
       'mean_F_harmonic_power':mean(rr,'effect_F_harmonic_power'),'mean_Renyi_L2_localization':mean(rr,'localization_ratio_L2'),'mean_Renyi_L4_localization':mean(rr,'localization_ratio_L4'),
       'fraction_fixed_sector_hyperbolic_rho_gt_1p05':float(np.mean([af(r['restricted_rho'])>1.05 for r in rr]))}
  nrows.append(row)
 wcsv(comp/'EPS1_BALANCED_N_LEVEL_4x5.csv',nrows)
 trends={}
 for k in ['mean_restricted_lambda_over_omega','mean_sector_ftle_median_180','broad_fullspace_ftle_median','mean_tube_P_16_20','mean_tube_P_2_20','mean_return_peak_1_5','mean_Renyi_L2_localization']:
  trends[k]=exact_spearman_5([r['N'] for r in nrows],[r[k] for r in nrows])
 jdump(comp/'EPS1_N_LEVEL_EXACT_TRENDS.json',trends)
 # The final reproducible manuscript workflow performs the homogeneous-vs-modified
 # comparison in Section 6.3 using the corrected Section-3/4 V2 baseline.  The
 # historical epsilon=0 comparison tables are therefore optional here.
 if not str(a.baseline_dir).strip():
  lines=['EPSILON=1 FINAL BALANCED DATASET\n\n',
         'Design: N=2,4,6,8,10; four collectively inequivalent fixed-sector-hyperbolic UPO families per N; same reference energy density; central epsilon=1, homogeneous environment Ei=0.\n\n',
         'The final homogeneous comparison is performed by 6.3_CODE_robustness_comparison.py using the corrected Section-3/4 collective baseline.\n\n',
         'EPSILON=1 N-LEVEL SUMMARY\n']
  for r in nrows: lines.append(json.dumps(san(r),sort_keys=True)+'\n')
  lines.append('\nEPSILON=1 EXACT N-LEVEL TRENDS\n'+json.dumps(san(trends),indent=2)+'\n')
  lines.append('\nGLOBAL PRIMARY FDR CHECK: epsilon=1 primary tests = %d (required 200).\n'%len(prim))
  open(comp/'EPS1_FINAL_REPORT.txt','w').writelines(lines)
  pre=[]
  for N in NS: pre.append(json.load(open(root/f'N{N}'/'PREFLIGHT.json')))
  validation={'PASS':True,'epsilon':1.0,'Ns':NS,'n_collective_families':20,'families_per_N':4,'global_primary_tests':len(prim),'preflight_all_pass':all(x.get('PASS') for x in pre),'homogeneous_comparison':'deferred_to_section_6.3','report':str(comp/'EPS1_FINAL_REPORT.txt')}
  import shutil
  codedir=root/'CODE_USED';ensure(codedir)
  for src in [a.core,a.metrics,str(Path(__file__).resolve())]:
   try: shutil.copy2(src,codedir/Path(src).name)
   except Exception: pass
  jdump(comp/'FINAL_AGGREGATION_VALIDATION.json',validation); jdump(root/'DONE_ALL.json',validation)
  metrics.manifest(root)
  print('EPSILON=1 AGGREGATION COMPLETE (final reproducible workflow)')
  print('Report:',comp/'EPS1_FINAL_REPORT.txt')
  return
 # Optional historical epsilon=0 comparison, retained for backward compatibility.
 bdir=Path(a.baseline_dir);b20=rcsv(bdir/'epsilon0_FINAL_20_COLLECTIVE_FAMILY_METRICS.csv');bn=rcsv(bdir/'epsilon0_FINAL_BALANCED_N_LEVEL_4x5.csv');bprim=rcsv(bdir/'epsilon0_PRIMARY_HYPOTHESIS_TESTS_20_FDR.csv');bchaos=rcsv(bdir/'epsilon0_CHAOS_FTLE_SECTOR_ALL.csv')
 if len(b20)!=20:raise RuntimeError('epsilon=0 baseline is not final 20-family dataset')
 # Direct descriptive comparison, same N and same energy density but independent UPO catalogues.
 cmp=[];sigflip={}
 for key,label in MAIN_METRICS.items():
  diffs=[]
  for N in NS:
   r0=[r for r in b20 if int(r['N'])==N];r1=[r for r in eps1 if int(r['N'])==N];m0=mean(r0,key);m1=mean(r1,key)
   try:p=float(mannwhitneyu([af(r[key]) for r in r1],[af(r[key]) for r in r0],alternative='two-sided',method='exact').pvalue)
   except Exception:p=np.nan
   cmp.append({'metric':key,'label':label,'N':N,'epsilon0_mean':m0,'epsilon1_mean':m1,'difference_eps1_minus_eps0':m1-m0,'ratio_eps1_over_eps0':m1/m0 if abs(m0)>1e-300 else np.nan,'MWU_exact_p_descriptive':p})
   diffs.append(m1-m0)
  sigflip[key]=exact_signflip(diffs)
 # broad FTLE direct comparison
 for N in NS:
  v0=np.array([af(r['ftle']) for r in bchaos if int(r['N'])==N]);r1=[r for r in nrows if r['N']==N][0];m0=float(np.median(v0));m1=r1['broad_fullspace_ftle_median']
  cmp.append({'metric':'broad_fullspace_ftle_median','label':'Broad same-shell full-space FTLE median','N':N,'epsilon0_mean':m0,'epsilon1_mean':m1,'difference_eps1_minus_eps0':m1-m0,'ratio_eps1_over_eps0':m1/m0 if abs(m0)>1e-300 else np.nan,'MWU_exact_p_descriptive':np.nan})
 wcsv(comp/'EPSILON0_VS_EPSILON1_BY_N.csv',cmp);jdump(comp/'EPSILON0_VS_EPSILON1_EXACT_SIGNFLIP_5N.json',sigflip)
 # Primary FDR significance count comparison.
 sigrows=[]
 for metric in metrics.PRIMARY_METRICS:
  for eps,arr in [(0,bprim),(1,prim)]:
   rr=[r for r in arr if r['metric']==metric];sig=sum(str(r.get('significant_q05_global_family','')).lower()=='true' for r in rr)
   sigrows.append({'epsilon':eps,'metric':metric,'n_tests':len(rr),'n_significant_global_FDR':sig,'fraction_significant':sig/len(rr) if rr else np.nan})
 wcsv(comp/'EPSILON0_VS_EPSILON1_PRIMARY_FDR_COUNTS.csv',sigrows)
 # Plots.
 def plot_compare(key,ylabel,fn):
  y0=[];y1=[]
  for N in NS:
   y0.append(mean([r for r in b20 if int(r['N'])==N],key));y1.append(mean([r for r in eps1 if int(r['N'])==N],key))
  plt.figure(figsize=(6.6,4.6));plt.plot(NS,y0,marker='o',label=r'$\epsilon=0$');plt.plot(NS,y1,marker='s',label=r'$\epsilon=1$');plt.xlabel('Environment size N');plt.ylabel(ylabel);plt.legend();plt.tight_layout();plt.savefig(comp/fn,dpi=300);plt.close()
 for k,l,fn in [('restricted_lambda_over_omega',r'Fixed-sector $\lambda/\omega$','compare_fixed_sector_chi.png'),('effect_tube_P_2_20','Tube localization 2-20T','compare_tube_2_20.png'),('effect_tube_P_16_20','Tube localization 16-20T','compare_tube_16_20.png'),('effect_return_peak_1_5','Return enhancement 1-5T','compare_return_1_5.png'),('localization_ratio_L2',r'$L_2$ localization ratio','compare_renyi_L2.png')]:plot_compare(k,l,fn)
 # broad FTLE plot
 d0={N:float(np.median([af(r['ftle']) for r in bchaos if int(r['N'])==N])) for N in NS};d1={r['N']:r['broad_fullspace_ftle_median'] for r in nrows}
 plt.figure(figsize=(6.6,4.6));plt.plot(NS,[d0[n] for n in NS],marker='o',label=r'$\epsilon=0$');plt.plot(NS,[d1[n] for n in NS],marker='s',label=r'$\epsilon=1$');plt.xlabel('Environment size N');plt.ylabel('Median broad full-space FTLE');plt.legend();plt.tight_layout();plt.savefig(comp/'compare_broad_FTLE.png',dpi=300);plt.close()
 # Human-readable validation/report.
 lines=['EPSILON=1 FINAL BALANCED DATASET AND EPSILON=0 COMPARISON\n\n','Design: N=2,4,6,8,10; four collectively inequivalent fixed-sector-hyperbolic UPO families per N; same energy density as the final epsilon=0 reference; central epsilon=1, homogeneous environment Ei=0.\n\n','Orbit selection used periodicity, collective inequivalence and fixed-sector hyperbolicity only; no localization outcome entered selection. P/PT are broken and never used as equivalences; I, time reversal and environment permutations are the only exact discrete redundancies used.\n\n']
 lines.append('EPSILON=1 N-LEVEL SUMMARY\n')
 for r in nrows:lines.append(json.dumps(san(r),sort_keys=True)+'\n')
 lines.append('\nEPSILON=1 EXACT N-LEVEL TRENDS\n'+json.dumps(san(trends),indent=2)+'\n')
 lines.append('\nDIRECT EPSILON COMPARISON CAVEAT\nThe four UPOs at epsilon=0 and epsilon=1 are independent catalogues, not continued one-to-one branches. Therefore the epsilon comparison is a balanced cross-sectional comparison at fixed N and energy density. The 4-vs-4 Mann-Whitney p values are descriptive and low-powered; the five-N exact sign-flip tests are supplied as an additional system-size-level summary.\n')
 lines.append('\nGLOBAL PRIMARY FDR CHECK: epsilon=1 primary tests = %d (required 200).\n'%len(prim))
 open(comp/'EPS1_FINAL_REPORT.txt','w').writelines(lines)
 # final validation marker
 pre=[]
 for N in NS:pre.append(json.load(open(root/f'N{N}'/'PREFLIGHT.json')))
 validation={'PASS':True,'epsilon':1.0,'Ns':NS,'n_collective_families':20,'families_per_N':4,'global_primary_tests':len(prim),'preflight_all_pass':all(x.get('PASS') for x in pre),'baseline_rows':len(b20),'report':str(comp/'EPS1_FINAL_REPORT.txt')}
 # Archive exact code and reference tables used for the comparison.
 import shutil
 codedir=root/'CODE_USED';ensure(codedir)
 for src in [a.core,a.metrics,str(Path(__file__).resolve())]:
  try:shutil.copy2(src,codedir/Path(src).name)
  except Exception:pass
 refout=root/'EPSILON0_REFERENCE_USED';ensure(refout)
 for src in bdir.glob('*'):
  if src.is_file():shutil.copy2(src,refout/src.name)
 jdump(comp/'FINAL_AGGREGATION_VALIDATION.json',validation);jdump(root/'DONE_ALL.json',validation)
 metrics.manifest(root)
 print('EPSILON=1 AGGREGATION COMPLETE');print('Report:',comp/'EPS1_FINAL_REPORT.txt');print('Comparison:',comp/'EPSILON0_VS_EPSILON1_BY_N.csv')

if __name__=='__main__':main()
