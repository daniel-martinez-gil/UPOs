#!/usr/bin/env python3
"""
scar_env_single.py
==================
Final single environmental-asymmetry pipeline for UPO-associated dynamical
localization in the nonlinear central-TLS + finite-environment model.

PHYSICAL CASE
-------------
Central TLS: epsilon=1, delta=1.
Environment: D_i=Lambda_i=1 and non-identical longitudinal biases

    epsilon_i = 0.10 * xi_i,
    mean_i xi_i = 0,
    RMS_i xi_i = 1.

Thus RMS(epsilon_i)=0.10 for every N.  The deterministic centered linear xi_i
pattern is recorded in every output.  There is NO scan of environmental
asymmetry and NO scan of energy.

The extensive energy density is exactly the same as in the previous datasets:

    E/(N+1) = 2.511352169911679/3 = 0.8371173899705596...

for N=2,4,6,8,10.

SCIENTIFIC DESIGN
-----------------
For each N, exactly four independent hyperbolic UPOs are required.  The
homogeneous epsilon=1 UPO catalogue is used only to supply numerical seeds.
Because environmental permutation symmetry is broken, environment
permutations are NOT used to identify UPOs.  Only arbitrary phase origin and
exact time reversal are quotiented.  If seed refinement does not provide four
families, a resumable full-energy Poincare recurrence search continues until
four are obtained.

Each accepted UPO then receives the same article protocol used for the
homogeneous case: 24 near-UPO trajectories, 48 same-energy controls, 20T,
60 points/T, 360 phase points, tube localization, return/revival enhancement,
nT timing, Fourier locking, Renyi L2/L4, IPR, phase-locking windows, Floquet
stability and BH-FDR.  Full-space same-energy FTLE is computed to t=1600.

Breaking environmental homogeneity destroys the Gram invariants, so the exact
fixed collective sector no longer exists.  Consequently fixed-sector
Floquet/FTLE quantities are not defined; the full-space quantities already
present in the earlier pipelines are the common stability diagnostics.

Main commands:
  python3 scar_env_single.py search    --N 4
  python3 scar_env_single.py metrics   --N 4 --orbit 0
  python3 scar_env_single.py chaos     --N 4
  python3 scar_env_single.py aggregate
  python3 scar_env_single.py smoke

Dependencies: numpy, scipy, matplotlib. CPU only. No pandas.
"""

import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

import argparse
import csv
import hashlib
import itertools
import json
import math
import shutil
import signal
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
from scipy.optimize import least_squares, brentq
from scipy.spatial import cKDTree
from scipy.stats import mannwhitneyu, spearmanr, wilcoxon


# =============================================================================
# GLOBAL STUDY CONSTANTS
# =============================================================================

EPS = 1e-300
CENTRAL_EPSILON = 1.0
CENTRAL_DELTA = 1.0
REFERENCE_N2_ENERGY = 2.511352169911679
REFERENCE_ENERGY_DENSITY = REFERENCE_N2_ENERGY / 3.0
DEFAULT_NS = (2, 4, 6, 8, 10)
FIXED_ENV_EPS_RMS = 0.10
DEFAULT_WS = (FIXED_ENV_EPS_RMS,)
MASTER_SEED = 20261001
ALPHA = 0.05

PRIMARY_METRICS = (
    "tube_P_2_20",
    "tube_P_10_16",
    "tube_P_16_20",
    "return_peak_1_5",
    "return_peak_6_10",
    "return_timing_1_5",
    "F_harmonic_power",
    "tube_harmonic_power",
    "Renyi_L2",
    "Renyi_L4",
)
STANDARD_WINDOWS = ((2, 6), (6, 10), (10, 16))
FINE_WINDOWS = tuple((a, a + 2) for a in range(2, 20, 2))


class SearchIncomplete(RuntimeError):
    """Search is safely checkpointed but has not yet found four UPOs."""


def search_config(N, quick=False, required=4):
    N=int(N)
    if quick:
        return dict(
            COARSE_TRAJECTORIES_PER_EPOCH=2, COARSE_TIME=120.0, COARSE_DT=.30,
            T_MIN=4.0, T_MAX=90.0, COARSE_RADIUS=1.25,
            CANDIDATES_PER_TRAJECTORY=10, CANDIDATES_PER_EPOCH=18,
            MAX_NFEV=50, POLISH_NFEV=30, SEARCH_BUDGET_HOURS=.15,
            PERIODIC_TOL=2e-5, ENERGY_TOL=3e-6, MIN_EXCURSION=.04,
            CLEAR_RHO=1.05, REQUIRED=min(int(required),2),
            DEDUP_PERIOD_REL_TOL=5e-4, DEDUP_RMS_TOL=6e-2, DEDUP_MAX_TOL=1.8e-1)
    table={
        2:(18,1700.,.16,260.,180,18.),
        4:(22,2300.,.18,320.,220,24.),
        6:(28,3100.,.20,390.,260,36.),
        8:(34,4100.,.22,470.,320,52.),
        10:(42,5200.,.24,560.,380,84.),
    }
    ntraj,ctime,cdt,tmax,ncand,budget=table[N]
    return dict(
        COARSE_TRAJECTORIES_PER_EPOCH=ntraj, COARSE_TIME=ctime, COARSE_DT=cdt,
        T_MIN=5.0, T_MAX=tmax, COARSE_RADIUS=1.10,
        CANDIDATES_PER_TRAJECTORY=55, CANDIDATES_PER_EPOCH=ncand,
        MAX_NFEV=340, POLISH_NFEV=210, SEARCH_BUDGET_HOURS=budget,
        PERIODIC_TOL=2e-7, ENERGY_TOL=2e-8, MIN_EXCURSION=.08,
        CLEAR_RHO=1.05, REQUIRED=int(required),
        DEDUP_PERIOD_REL_TOL=1e-4, DEDUP_RMS_TOL=2e-2, DEDUP_MAX_TOL=6e-2)

_INTERRUPTION_FILE = None


def utcnow():
    return datetime.now(timezone.utc).isoformat()


def log(*args):
    print(*args, flush=True)


def ensure(path):
    Path(path).mkdir(parents=True, exist_ok=True)


def sanitize(obj):
    if isinstance(obj, dict):
        return {str(k): sanitize(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [sanitize(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return sanitize(obj.tolist())
    if isinstance(obj, np.generic):
        obj = obj.item()
    if isinstance(obj, float) and not np.isfinite(obj):
        return None
    return obj


def write_json(path, obj):
    path = Path(path)
    ensure(path.parent)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(sanitize(obj), f, indent=2, allow_nan=False)
    os.replace(tmp, path)


def read_json(path, default=None):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def write_csv(path, rows, fields=None):
    path = Path(path)
    ensure(path.parent)
    rows = list(rows)
    if fields is None:
        fields = []
        for row in rows:
            for k in row:
                if k not in fields:
                    fields.append(k)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for row in rows:
            w.writerow(row)
    os.replace(tmp, path)


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def ffloat(x, default=np.nan):
    try:
        if x in (None, ""):
            return default
        return float(x)
    except Exception:
        return default


def wtag(W):
    s = f"{float(W):.6f}".rstrip("0").rstrip(".")
    if s == "":
        s = "0"
    return "W_" + s.replace("-", "m").replace(".", "p")


def parse_ws(text):
    if text is None:
        return list(DEFAULT_WS)
    return sorted(set(float(x.strip()) for x in text.split(",") if x.strip()))


def target_energy(N):
    return REFERENCE_ENERGY_DENSITY * (int(N) + 1)


def interruption_handler(signum, frame):
    global _INTERRUPTION_FILE
    try:
        if _INTERRUPTION_FILE:
            write_json(_INTERRUPTION_FILE, {
                "signal": int(signum), "interrupted_utc": utcnow(),
                "message": "Safe interruption marker. Re-submit the same command."
            })
    finally:
        raise SystemExit(128 + int(signum))


signal.signal(signal.SIGTERM, interruption_handler)
signal.signal(signal.SIGINT, interruption_handler)


# =============================================================================
# MODEL
# =============================================================================


def deterministic_bias_pattern(N):
    """Zero-mean unit-RMS deterministic inhomogeneity direction."""
    q = np.arange(int(N), dtype=float) - 0.5 * (int(N) - 1)
    q -= np.mean(q)
    rms = math.sqrt(float(np.mean(q*q)))
    if rms <= 0:
        raise ValueError("N must be >=2")
    return q / rms


def random_bias_pattern(N, seed):
    rng = np.random.default_rng(int(seed) + 7919 * int(N))
    q = rng.normal(size=int(N))
    q -= np.mean(q)
    rms = math.sqrt(float(np.mean(q*q)))
    if rms < 1e-12:
        return deterministic_bias_pattern(N)
    return q / rms


@dataclass
class HeteroModel:
    N: int
    W: float
    pattern_kind: str = "linear"
    pattern_seed: int = 314159

    def __post_init__(self):
        self.N = int(self.N)
        self.M = self.N + 1
        self.BLOCH_DIM = 3 * self.M
        self.PHYS_DIM = 2 * self.M
        self.epsilon = CENTRAL_EPSILON
        self.delta = CENTRAL_DELTA
        if self.pattern_kind == "linear":
            self.xi = deterministic_bias_pattern(self.N)
        elif self.pattern_kind == "random":
            self.xi = random_bias_pattern(self.N, self.pattern_seed)
        else:
            raise ValueError(f"Unknown pattern_kind={self.pattern_kind}")
        self.Evec = float(self.W) * self.xi
        self.Dvec = np.ones(self.N, float)
        self.Lvec = np.ones(self.N, float)

    def info(self):
        return {
            "N": self.N, "M": self.M, "epsilon": self.epsilon,
            "delta": self.delta, "W": float(self.W),
            "pattern_kind": self.pattern_kind, "pattern_seed": self.pattern_seed,
            "xi": self.xi.tolist(), "E_i": self.Evec.tolist(),
            "D_i": self.Dvec.tolist(), "Lambda_i": self.Lvec.tolist(),
            "mean_Ei": float(np.mean(self.Evec)),
            "rms_Ei": float(np.sqrt(np.mean(self.Evec**2))),
            "max_abs_Ei": float(np.max(np.abs(self.Evec))),
        }

    # canonical ordering: [z0,phi0,z1,phi1,...,zN,phiN]
    def u_to_R(self, u):
        u = np.asarray(u, float)
        R = np.empty(self.BLOCH_DIM, float)
        for k in range(self.M):
            z = float(np.clip(u[2*k], -1.0, 1.0))
            ph = float(u[2*k+1])
            s = math.sqrt(max(0.0, 1.0-z*z))
            R[3*k:3*k+3] = (s*math.cos(ph), s*math.sin(ph), z)
        return R

    def R_to_u(self, R):
        R = np.asarray(R, float)
        u = np.empty(self.PHYS_DIM, float)
        for k in range(self.M):
            j = 3*k
            u[2*k] = float(np.clip(R[j+2], -0.999999999999, 0.999999999999))
            u[2*k+1] = float(np.arctan2(R[j+1], R[j]))
        return u

    def normalize_R(self, R):
        R = np.asarray(R, float).copy()
        for k in range(self.M):
            j = 3*k
            n = np.linalg.norm(R[j:j+3])
            if n < 1e-300:
                raise ValueError("zero Bloch vector")
            R[j:j+3] /= n
        return R

    def rhs(self, t, R):
        R = np.asarray(R, float)
        dR = np.zeros_like(R)
        x0, y0, Z = R[:3]
        env_z = np.array([R[3+3*i+2] for i in range(self.N)], float)
        Om0 = 2*self.epsilon + float(np.dot(self.Lvec, env_z))
        dR[0] = -Om0*y0
        dR[1] =  Om0*x0 + 2*self.delta*Z
        dR[2] = -2*self.delta*y0
        for i in range(self.N):
            j = 3 + 3*i
            x, y, z = R[j:j+3]
            Omi = 2*self.Evec[i] + self.Lvec[i]*Z
            dR[j]   = -Omi*y
            dR[j+1] =  Omi*x + 2*self.Dvec[i]*z
            dR[j+2] = -2*self.Dvec[i]*y
        return dR

    def jacobian(self, R):
        R = np.asarray(R, float)
        J = np.zeros((self.BLOCH_DIM, self.BLOCH_DIM), float)
        x0, y0, Z = R[:3]
        env_z = np.array([R[3+3*i+2] for i in range(self.N)], float)
        Om0 = 2*self.epsilon + float(np.dot(self.Lvec, env_z))
        J[0,1] = -Om0
        J[1,0] =  Om0
        J[1,2] = 2*self.delta
        J[2,1] = -2*self.delta
        for i in range(self.N):
            zi = 3 + 3*i + 2
            J[0,zi] = -self.Lvec[i]*y0
            J[1,zi] =  self.Lvec[i]*x0
        for i in range(self.N):
            j = 3 + 3*i
            x, y, z = R[j:j+3]
            Omi = 2*self.Evec[i] + self.Lvec[i]*Z
            J[j,j+1] = -Omi
            J[j,2] = -self.Lvec[i]*y
            J[j+1,j] = Omi
            J[j+1,j+2] = 2*self.Dvec[i]
            J[j+1,2] = self.Lvec[i]*x
            J[j+2,j+1] = -2*self.Dvec[i]
        return J

    def energy(self, R):
        R = np.asarray(R, float)
        x0, _, Z = R[:3]
        H = -2*self.delta*x0 + 2*self.epsilon*Z
        for i in range(self.N):
            j = 3+3*i
            x, _, z = R[j:j+3]
            H += -2*self.Dvec[i]*x + 2*self.Evec[i]*z + self.Lvec[i]*Z*z
        return float(H)

    def energy_gradient(self, R):
        R = np.asarray(R, float)
        g = np.zeros_like(R)
        Z = R[2]
        env_z = np.array([R[3+3*i+2] for i in range(self.N)], float)
        g[0] = -2*self.delta
        g[2] = 2*self.epsilon + float(np.dot(self.Lvec, env_z))
        for i in range(self.N):
            j = 3+3*i
            g[j] = -2*self.Dvec[i]
            g[j+2] = 2*self.Evec[i] + self.Lvec[i]*Z
        return g

    def canonical_rhs(self, t, u):
        u = np.asarray(u, float)
        du = np.zeros_like(u)
        Z, Phi = u[0], u[1]
        s0 = math.sqrt(max(1e-20, 1-Z*Z))
        envz = np.array([u[2*(i+1)] for i in range(self.N)])
        du[0] = -2*self.delta*s0*math.sin(Phi)
        du[1] = (2*self.epsilon + 2*self.delta*(Z/s0)*math.cos(Phi)
                 + float(np.dot(self.Lvec, envz)))
        for i in range(self.N):
            k = 2*(i+1)
            z, ph = u[k], u[k+1]
            s = math.sqrt(max(1e-20, 1-z*z))
            du[k] = -2*self.Dvec[i]*s*math.sin(ph)
            du[k+1] = (2*self.Evec[i] + 2*self.Dvec[i]*(z/s)*math.cos(ph)
                       + self.Lvec[i]*Z)
        return du

    def canonical_jacobian(self, u):
        u = np.asarray(u, float)
        J = np.zeros((self.PHYS_DIM, self.PHYS_DIM), float)
        Z, Phi = u[0], u[1]
        s0 = math.sqrt(max(1e-20, 1-Z*Z))
        J[0,0] = 2*self.delta*(Z/s0)*math.sin(Phi)
        J[0,1] = -2*self.delta*s0*math.cos(Phi)
        J[1,0] = 2*self.delta*math.cos(Phi)/(s0**3)
        J[1,1] = -2*self.delta*(Z/s0)*math.sin(Phi)
        for i in range(self.N):
            k = 2*(i+1)
            J[1,k] = self.Lvec[i]
            z, ph = u[k], u[k+1]
            s = math.sqrt(max(1e-20, 1-z*z))
            J[k,k] = 2*self.Dvec[i]*(z/s)*math.sin(ph)
            J[k,k+1] = -2*self.Dvec[i]*s*math.cos(ph)
            J[k+1,k] = 2*self.Dvec[i]*math.cos(ph)/(s**3)
            J[k+1,k+1] = -2*self.Dvec[i]*(z/s)*math.sin(ph)
            J[k+1,0] = self.Lvec[i]
        return J

    def tangent_basis(self, R):
        R = np.asarray(R, float)
        B = np.zeros((self.BLOCH_DIM, self.PHYS_DIM), float)
        for k in range(self.M):
            j = 3*k
            r = R[j:j+3]/np.linalg.norm(R[j:j+3])
            ref = np.array([0.,0.,1.]) if abs(r[2]) < .9 else np.array([1.,0.,0.])
            e1 = np.cross(ref, r)
            e1 /= np.linalg.norm(e1)
            e2 = np.cross(r, e1)
            e2 /= np.linalg.norm(e2)
            B[j:j+3,2*k] = e1
            B[j:j+3,2*k+1] = e2
        return B

    def symplectic_matrix(self):
        S = np.zeros((self.PHYS_DIM, self.PHYS_DIM), float)
        J2 = np.array([[0.,1.],[-1.,0.]])
        for k in range(self.M):
            S[2*k:2*k+2,2*k:2*k+2] = J2
        return S

    def integrate_final(self, R0, T, rtol=2e-10, atol=1e-11):
        sol = solve_ivp(self.rhs, (0,float(T)), np.asarray(R0,float), method="DOP853",
                        rtol=rtol, atol=atol)
        return sol.y[:,-1] if sol.success else None

    def integrate_grid(self, R0, total_time, nt, rtol=2e-9, atol=1e-11):
        tt = np.linspace(0,float(total_time),int(nt))
        sol = solve_ivp(self.rhs, (0,float(total_time)), np.asarray(R0,float),
                        method="DOP853", t_eval=tt, rtol=rtol, atol=atol)
        if not sol.success:
            raise RuntimeError(sol.message)
        return sol.t, sol.y.T


# =============================================================================
# BASELINE UPO INPUT / CANONICAL LABELING
# =============================================================================


def legacy_row_to_R(row, N):
    m = HeteroModel(N, 0.0)
    u = np.zeros(2*(N+1), float)
    u[0] = float(row["Z0"])
    u[1] = 0.0
    for i in range(N):
        u[2*(i+1)] = float(row[f"z{i+1}_0"])
        u[2*(i+1)+1] = float(row[f"phi{i+1}_0"])
    return m.u_to_R(u)


def canonicalize_environment_labels(R, N):
    """Choose a deterministic W=0 representative before assigning xi_i.

    Environment permutations are exact at W=0.  Sorting by (z,x,y) makes the
    W>0 bias assignment reproducible and removes dependence on the arbitrary
    CSV environment ordering.
    """
    rr = np.asarray(R,float).reshape(N+1,3).copy()
    env = rr[1:]
    # np.lexsort uses last key as primary: z, then x, then y.
    perm = np.lexsort((env[:,1], env[:,0], env[:,2]))
    rr[1:] = env[perm]
    return rr.reshape(-1), perm


def load_base_orbit(base_root, N, oid, pattern_kind="linear", pattern_seed=314159):
    path = Path(base_root) / f"N{N}" / "selected_independent_upos.csv"
    if not path.exists():
        path = Path(base_root) / f"N{N}" / "independent_clear_upos.csv"
    rows = read_csv(path)
    if oid < 0 or oid >= len(rows):
        raise IndexError(f"orbit {oid} not available in {path}; rows={len(rows)}")
    row = rows[oid]
    R0 = legacy_row_to_R(row, N)
    R0, perm = canonicalize_environment_labels(R0, N)
    model = HeteroModel(N, 0.0, pattern_kind, pattern_seed)
    u0 = model.R_to_u(R0)
    return {
        "N": int(N), "orbit": int(oid), "W": 0.0,
        "u": u0, "R0": R0, "T": float(row["T"]),
        "source": str(path), "legacy_row": row,
        "canonical_env_permutation": [int(x) for x in perm],
    }


# =============================================================================
# ENERGY SHELL / MICROCANONICAL SAMPLING / NEAR STATES
# =============================================================================


def random_unit_vector(rng):
    v = rng.normal(size=3)
    n = np.linalg.norm(v)
    return random_unit_vector(rng) if n < 1e-14 else v/n


def central_energy_circle(model, env, Etarget):
    env = np.asarray(env,float).reshape(model.N,3)
    a = np.array([
        -2*model.delta,
        0.0,
        2*model.epsilon + float(np.dot(model.Lvec, env[:,2]))
    ], float)
    an = float(np.linalg.norm(a))
    Henv = 0.0
    for i in range(model.N):
        x, _, z = env[i]
        Henv += -2*model.Dvec[i]*x + 2*model.Evec[i]*z
    c = float(Etarget - Henv)
    if an < 1e-14 or abs(c) > an + 2e-12:
        return None
    d = float(np.clip(c/an, -1.0, 1.0))
    n = a/an
    rad = math.sqrt(max(0.0, 1-d*d))
    return n, d, rad, an


def central_on_energy(model, env, Etarget, rng, target=None, delta_angle=None):
    ec = central_energy_circle(model, env, Etarget)
    if ec is None:
        return None
    n, d, rad, _ = ec
    if target is None:
        tmp = np.array([1.,0.,0.]) if abs(n[0]) < .8 else np.array([0.,1.,0.])
        u = tmp - np.dot(tmp,n)*n
        u /= np.linalg.norm(u)
        v = np.cross(n,u); v /= np.linalg.norm(v)
        ang = float(rng.uniform(0,2*np.pi))
    else:
        q = np.asarray(target,float) - np.dot(target,n)*n
        if np.linalg.norm(q) < 1e-12:
            tmp = np.array([1.,0.,0.]) if abs(n[0]) < .8 else np.array([0.,1.,0.])
            q = tmp - np.dot(tmp,n)*n
        u = q/np.linalg.norm(q)
        v = np.cross(n,u); v /= np.linalg.norm(v)
        ang = float(delta_angle or 0.0)
    r = d*n + rad*(math.cos(ang)*u + math.sin(ang)*v)
    return r/np.linalg.norm(r)


def sample_microcanonical_full_energy(model, Etarget, rng, max_attempts=30000):
    """Full-energy-shell sample, with the central-circle delta(E-H) weight.

    Environment spins are isotropic and independent.  For a fixed environment,
    the central-spin energy constraint is a circle.  Its microcanonical surface
    weight is proportional to 1/|a|; since |a| >= 2*delta, rejection with
    probability 2*delta/|a| gives the corresponding conditional weight.
    """
    lower = max(1e-12, 2.0*abs(model.delta))
    for _ in range(max_attempts):
        env = np.array([random_unit_vector(rng) for _ in range(model.N)], float)
        ec = central_energy_circle(model, env, Etarget)
        if ec is None:
            continue
        _, _, _, an = ec
        if rng.random() > min(1.0, lower/an):
            continue
        c = central_on_energy(model, env, Etarget, rng)
        if c is None:
            continue
        R = np.vstack([c,env]).reshape(-1)
        if abs(model.energy(R)-Etarget) < 2e-10:
            return R
    raise RuntimeError("failed to sample full fixed-energy shell")


def project_to_energy_shell(model, R, Etarget, tol=1e-10):
    R = model.normalize_R(R)
    for _ in range(80):
        dE = model.energy(R)-Etarget
        if abs(dE) < tol:
            return R, True
        g = model.energy_gradient(R)
        tg = np.zeros_like(R)
        for k in range(model.M):
            j = 3*k
            r = R[j:j+3]
            gg = g[j:j+3]
            tg[j:j+3] = gg - np.dot(gg,r)*r
        den = float(np.dot(tg,tg))
        if den < 1e-15:
            return R, False
        R -= (dE/den)*tg
        R = model.normalize_R(R)
    return R, abs(model.energy(R)-Etarget) < 1e-7


def generate_near_state(model, Rupo, Etarget, rng, amplitude=1e-4):
    B = model.tangent_basis(Rupo)
    flow = B.T @ model.rhs(0,Rupo)
    grad = B.T @ model.energy_gradient(Rupo)
    cons = []
    for q in (flow, grad):
        if np.linalg.norm(q) > 1e-12:
            cons.append(q/np.linalg.norm(q))
    Qb = np.linalg.qr(np.column_stack(cons))[0] if cons else None
    for _ in range(600):
        v = rng.normal(size=model.PHYS_DIM)
        if Qb is not None:
            v -= Qb @ (Qb.T @ v)
        nv = np.linalg.norm(v)
        if nv < 1e-14:
            continue
        v *= amplitude/nv
        dR = B@v
        R = np.asarray(Rupo,float).copy()
        for k in range(model.M):
            j = 3*k
            r = Rupo[j:j+3]
            dr = dR[j:j+3]
            a = np.linalg.norm(dr)
            if a > 0:
                R[j:j+3] = math.cos(a)*r + math.sin(a)*(dr/a)
        R, ok = project_to_energy_shell(model,R,Etarget)
        if ok:
            return R
    raise RuntimeError("failed to generate full-space near-UPO state")


# =============================================================================
# CONTINUATION AND PERIODIC-ORBIT VALIDATION
# =============================================================================


def section_x_from_u(u, T, N):
    """Legacy/article section coordinates: Phi0 is fixed to zero."""
    u=np.asarray(u,float)
    return np.array([u[0], *[u[2*(i+1)] for i in range(N)],
                     *[u[2*(i+1)+1] for i in range(N)], float(T)], float)


def section_x_to_u(x, N):
    u=np.zeros(2*(N+1),float)
    u[0]=x[0]; u[1]=0.0
    for i in range(N):
        u[2*(i+1)]=x[1+i]
        u[2*(i+1)+1]=x[1+N+i]
    return u


def section_shooting_residual(x, model, Etarget, rtol=3e-9, atol=2e-11):
    u=section_x_to_u(x[:-1],model.N); T=float(x[-1]); R0=model.u_to_R(u)
    Rf=model.integrate_final(R0,T,rtol=rtol,atol=atol)
    if Rf is None:return np.ones(model.BLOCH_DIM+1)*100.0
    return np.concatenate([Rf-R0,[2.0*(model.energy(R0)-Etarget)]])


def general_shooting_residual(x, model, Etarget, Rref, Fref, rtol=3e-9, atol=2e-11):
    """Fallback when the Phi0=0 section becomes unsuitable."""
    u=np.asarray(x[:-1],float); T=float(x[-1]); R0=model.u_to_R(u)
    Rf=model.integrate_final(R0,T,rtol=rtol,atol=atol)
    if Rf is None:return np.ones(model.BLOCH_DIM+2)*100.0
    rec=Rf-R0; dE=model.energy(R0)-Etarget
    phase=float(np.dot(R0-Rref,Fref)/(np.linalg.norm(Fref)+1e-15))
    return np.concatenate([rec,[2.0*dE,phase]])


def _solve_section(prev, new_model, Etarget, quick=False, max_nfev=320):
    N=new_model.N; uguess=np.asarray(prev["u"],float); Tguess=float(prev["T"])
    # shift the previous phase origin to Phi0=0 if numerical storage has a tiny offset
    Rguess=new_model.u_to_R(uguess)
    # continuation starts from states that were stored on the section; use their
    # z and environment phases directly.
    x0=section_x_from_u(uguess,Tguess,N)
    lo=np.full(2*N+2,-np.inf); hi=np.full(2*N+2,np.inf)
    lo[0]=-0.9999995; hi[0]=0.9999995
    for i in range(N):lo[1+i]=-0.9999995; hi[1+i]=0.9999995
    lo[-1]=max(2.0,.70*Tguess); hi[-1]=max(lo[-1]+1e-4,1.35*Tguess)
    x0=np.minimum(np.maximum(x0,lo+1e-10),hi-1e-10)
    def coarse(x):return section_shooting_residual(x,new_model,Etarget,
                                                    rtol=2e-8 if quick else 4e-9,
                                                    atol=1e-10 if quick else 2e-10)
    res=least_squares(coarse,x0,bounds=(lo,hi),method="trf",
                      xtol=2e-7 if quick else 2e-10,
                      ftol=2e-7 if quick else 2e-10,
                      gtol=2e-7 if quick else 2e-10,
                      max_nfev=35 if quick else max_nfev,x_scale="jac")
    u1=section_x_to_u(res.x[:-1],N); T1=float(res.x[-1]); R1=new_model.u_to_R(u1)
    Rf=new_model.integrate_final(R1,T1,rtol=2e-9 if quick else 2e-10,atol=2e-11 if quick else 2e-12)
    D=np.linalg.norm(Rf-R1) if Rf is not None else np.inf; dE=new_model.energy(R1)-Etarget
    if not quick and D<2e-3 and abs(dE)<2e-4:
        def polish(x):return section_shooting_residual(x,new_model,Etarget,rtol=1.5e-11,atol=8e-13)
        res=least_squares(polish,res.x,bounds=(lo,hi),method="trf",xtol=4e-13,ftol=4e-13,gtol=4e-13,max_nfev=190,x_scale="jac")
        u1=section_x_to_u(res.x[:-1],N);T1=float(res.x[-1]);R1=new_model.u_to_R(u1)
        Rf=new_model.integrate_final(R1,T1,rtol=4e-11,atol=2e-13)
        D=np.linalg.norm(Rf-R1) if Rf is not None else np.inf;dE=new_model.energy(R1)-Etarget
    tolD=2e-5 if quick else 5e-7; tolE=3e-6 if quick else 3e-8
    return {"success":bool(np.isfinite(D) and D<tolD and abs(dE)<tolE),"u":u1,"R0":R1,"T":T1,
            "return_D":float(D),"energy":float(new_model.energy(R1)),"energy_error":float(dE),
            "cost":float(res.cost),"optimality":float(res.optimality),"nfev":int(res.nfev),
            "status":int(res.status),"message":"section_Phi0=0: "+str(res.message),"solver":"section_Phi0=0"}


def _solve_general(prev, new_model, old_model, Etarget, quick=False, max_nfev=320):
    Rref=np.asarray(prev["R0"],float);Fref=old_model.rhs(0,Rref);uguess=np.asarray(prev["u"],float);Tguess=float(prev["T"])
    x0=np.concatenate([uguess,[Tguess]]);lo=np.full(new_model.PHYS_DIM+1,-np.inf);hi=np.full(new_model.PHYS_DIM+1,np.inf)
    for k in range(new_model.M):lo[2*k]=-0.9999995;hi[2*k]=0.9999995
    lo[-1]=max(2.,.70*Tguess);hi[-1]=max(lo[-1]+1e-4,1.35*Tguess);x0=np.minimum(np.maximum(x0,lo+1e-10),hi-1e-10)
    def fun(x):return general_shooting_residual(x,new_model,Etarget,Rref,Fref,rtol=3e-8 if quick else 4e-9,atol=1e-10 if quick else 2e-10)
    res=least_squares(fun,x0,bounds=(lo,hi),method="trf",xtol=5e-7 if quick else 3e-10,ftol=5e-7 if quick else 3e-10,gtol=5e-7 if quick else 3e-10,max_nfev=20 if quick else max_nfev,x_scale="jac")
    u1=res.x[:-1];T1=float(res.x[-1]);R1=new_model.u_to_R(u1);Rf=new_model.integrate_final(R1,T1,rtol=2e-9 if quick else 2e-10,atol=2e-11 if quick else 2e-12)
    D=np.linalg.norm(Rf-R1) if Rf is not None else np.inf;dE=new_model.energy(R1)-Etarget
    tolD=2e-5 if quick else 5e-7;tolE=3e-6 if quick else 3e-8
    return {"success":bool(np.isfinite(D) and D<tolD and abs(dE)<tolE),"u":u1,"R0":R1,"T":T1,"return_D":float(D),"energy":float(new_model.energy(R1)),"energy_error":float(dE),"cost":float(res.cost),"optimality":float(res.optimality),"nfev":int(res.nfev),"status":int(res.status),"message":"general_phase: "+str(res.message),"solver":"general_phase"}


def solve_continuation_step(prev, Wnew, Etarget, pattern_kind, pattern_seed,
                            max_nfev=320, quick=False):
    N=int(prev["N"]);old_model=HeteroModel(N,float(prev["W"]),pattern_kind,pattern_seed);new_model=HeteroModel(N,float(Wnew),pattern_kind,pattern_seed)
    # Fast path: the same Phi0=0 Poincare section used by the validated epsilon=1 searches.
    sec=_solve_section(prev,new_model,Etarget,quick,max_nfev)
    if sec["success"]:
        sec.update({"N":N,"W":float(Wnew)});return sec
    # Rare fallback if the continued branch no longer has a numerically convenient Phi0=0 representative.
    gen=_solve_general(prev,new_model,old_model,Etarget,quick,max_nfev)
    gen["message"]="section failed: "+sec["message"]+" | "+gen["message"]
    gen.update({"N":N,"W":float(Wnew)})
    return gen

def adaptive_continue(prev, Wtarget, Etarget, pattern_kind, pattern_seed,
                      trace_path=None, quick=False,
                      initial_step=0.01, max_step=0.025, min_step=1e-4):
    current = dict(prev)
    Wcur = float(current["W"])
    Wtarget = float(Wtarget)
    if Wtarget < Wcur - 1e-14:
        raise ValueError("Continuation expects nondecreasing W")
    if abs(Wtarget-Wcur) < 1e-14:
        return current, []
    h = min(initial_step, Wtarget-Wcur)
    accepted = []
    while Wcur < Wtarget-1e-13:
        Wtry = min(Wtarget, Wcur+h)
        log(f"  continuation W={Wcur:.6g} -> {Wtry:.6g} (h={Wtry-Wcur:.3g})")
        try:
            cand = solve_continuation_step(current,Wtry,Etarget,pattern_kind,pattern_seed,quick=quick)
        except Exception as exc:
            cand = {"success":False,"W":Wtry,"message":f"{type(exc).__name__}: {exc}","return_D":np.inf,"energy_error":np.inf}
        row = {
            "from_W":Wcur,"to_W":Wtry,"step":Wtry-Wcur,
            "success":bool(cand.get("success",False)),
            "return_D":cand.get("return_D",np.nan),
            "energy_error":cand.get("energy_error",np.nan),
            "T":cand.get("T",np.nan),"nfev":cand.get("nfev",np.nan),
            "message":cand.get("message","")
        }
        accepted.append(row)
        if trace_path is not None:
            old = read_csv(trace_path) if Path(trace_path).exists() else []
            write_csv(trace_path, old+[row])
        if cand.get("success",False):
            current = cand
            Wcur = Wtry
            h = min(max_step, max(min_step, h*1.45))
        else:
            h *= 0.5
            if h < min_step:
                raise RuntimeError(
                    f"Continuation failed before W={Wtarget}; last accepted W={Wcur}, "
                    f"minimum step {min_step} exceeded. Last: {row}"
                )
    return current, accepted


def periodic_phase_grid(model, orbit, points=360):
    tt = np.linspace(0,float(orbit["T"]),int(points),endpoint=False)
    sol = solve_ivp(model.rhs,(0,float(orbit["T"])),orbit["R0"],method="DOP853",
                    t_eval=tt,rtol=2e-10,atol=2e-12)
    if not sol.success:
        raise RuntimeError(sol.message)
    return sol.y.T


def orbit_excursion(model, orbit):
    _, tr = model.integrate_grid(orbit["R0"],orbit["T"],500,rtol=3e-10,atol=2e-11)
    return float(np.max(np.linalg.norm(tr-orbit["R0"],axis=1)))


def best_phase_rms(model_a, orb_a, model_b, orb_b, points=240, allow_time_reversal=True):
    A = periodic_phase_grid(model_a,orb_a,points)
    B = periodic_phase_grid(model_b,orb_b,points)
    best = (np.inf,np.inf,0,False)
    candidates = [(B,False)]
    if allow_time_reversal:
        Bt = B[::-1].copy().reshape(points,model_b.M,3)
        Bt[:,:,1] *= -1
        candidates.append((Bt.reshape(points,-1),True))
    for BB,rev in candidates:
        for s in range(points):
            C = np.roll(BB,s,axis=0)
            per = np.sqrt(np.mean((A-C)**2,axis=1))
            rms = float(np.sqrt(np.mean(per**2)))
            mx = float(np.max(per))
            if rms < best[0]:
                best = (rms,mx,s,rev)
    return {"trajectory_rms":best[0],"trajectory_max":best[1],
            "phase_shift_index":int(best[2]),"time_reversed":bool(best[3])}


# =============================================================================
# FLOQUET / STABILITY
# =============================================================================


def reciprocal_pair_error(eigvals):
    a = np.abs(np.asarray(eigvals,complex))
    a = a[np.isfinite(a)&(a>1e-300)]
    if len(a)<2:
        return np.nan
    logs = np.sort(np.log(a))
    return float(np.max(np.abs(logs+logs[::-1])))


def floquet_analysis(model, R0, T):
    try:
        _, tr = model.integrate_grid(R0,T,240,rtol=2e-10,atol=2e-12)
        pole_margin = float(np.min(1.0-np.abs(tr[:,2::3])))
        if pole_margin < 2e-7:
            raise FloatingPointError(f"canonical chart pole margin={pole_margin:.2e}")
        u0 = model.R_to_u(R0)
        d = model.PHYS_DIM
        def vrhs(t,Y):
            u = Y[:d]
            MM = Y[d:].reshape(d,d)
            return np.concatenate([model.canonical_rhs(t,u),(model.canonical_jacobian(u)@MM).ravel()])
        Y0 = np.concatenate([u0,np.eye(d).ravel()])
        sol = solve_ivp(vrhs,(0,float(T)),Y0,method="DOP853",rtol=2e-11,atol=2e-13)
        if not sol.success:
            raise RuntimeError(sol.message)
        uf = sol.y[:d,-1]
        MC = sol.y[d:,-1].reshape(d,d)
        eig = np.linalg.eigvals(MC)
        eig = eig[np.argsort(np.abs(eig))[::-1]]
        rho = float(np.max(np.abs(eig)))
        lam = float(np.log(max(rho,1e-300))/T)
        S = model.symplectic_matrix()
        Rf = model.u_to_R(uf)
        return {
            "return_D":float(np.linalg.norm(Rf-R0)),"rho":rho,"lambda":lam,
            "lambda_over_omega":float(lam/(2*np.pi/T)),
            "det":float(np.linalg.det(MC)),
            "symplectic_error":float(np.max(np.abs(MC.T@S@MC-S))),
            "reciprocal_pair_error":reciprocal_pair_error(eig),
            "eigvals":eig,"Mphys":MC,"floquet_method":"canonical_action_angle",
            "canonical_pole_margin":pole_margin,
        }
    except Exception as exc:
        # Bloch tangent fallback.
        D = model.BLOCH_DIM
        def brhs(t,Y):
            R = Y[:D]
            MM = Y[D:].reshape(D,D)
            return np.concatenate([model.rhs(t,R),(model.jacobian(R)@MM).ravel()])
        Y0 = np.concatenate([R0,np.eye(D).ravel()])
        sol = solve_ivp(brhs,(0,float(T)),Y0,method="DOP853",rtol=3e-11,atol=3e-13)
        if not sol.success:
            return None
        yf = sol.y[:,-1]
        MF = yf[D:].reshape(D,D)
        B = model.tangent_basis(R0)
        MP = B.T@MF@B
        eig = np.linalg.eigvals(MP)
        eig = eig[np.argsort(np.abs(eig))[::-1]]
        rho = float(np.max(np.abs(eig)))
        lam = float(np.log(max(rho,1e-300))/T)
        return {
            "return_D":float(np.linalg.norm(yf[:D]-R0)),"rho":rho,"lambda":lam,
            "lambda_over_omega":float(lam/(2*np.pi/T)),
            "det":float(np.linalg.det(MP)),"symplectic_error":np.nan,
            "reciprocal_pair_error":reciprocal_pair_error(eig),"eigvals":eig,
            "Mphys":MP,"floquet_method":"bloch_tangent_fallback",
            "canonical_failure":str(exc),"canonical_pole_margin":np.nan,
        }


def stability_metrics(floquet, T):
    eig = np.asarray(floquet.get("eigvals",[]),complex)
    abs_mu = np.abs(eig)
    abs_mu = abs_mu[np.isfinite(abs_mu)&(abs_mu>EPS)]
    logs = np.log(abs_mu)
    positive = logs[logs>1e-5]/T
    lam_sum = float(np.sum(positive))
    lam_max = float(np.max(positive)) if len(positive) else 0.0
    omega = 2*np.pi/T
    return {
        "n_positive_floquet":int(len(positive)),
        "lambda_plus_sum":lam_sum,
        "heller_sum_over_2pi":float(lam_sum/omega),
        "classical_return_damping_per_period":float(np.exp(-lam_sum*T)),
        "lambda_max_from_spectrum":lam_max,
        "lambda_max_over_omega":float(lam_max/omega),
        "lyapunov_time_over_period":float(1/(lam_max*T)) if lam_max>0 else np.inf,
        "lambda_over_omega_lt_1":bool((lam_max/omega)<1) if lam_max>0 else True,
        "floquet_abs_json":json.dumps([float(x) for x in sorted(abs_mu,reverse=True)]),
    }


# =============================================================================
# SINGLE-ASYMMETRY PERIODIC-ORBIT SEARCH
# =============================================================================


def _section_roots_for_Z(model, env, Etarget):
    """All Phi0=0, x0>0 central-Z roots for fixed environment spins."""
    env=np.asarray(env,float).reshape(model.N,3)
    Henv=0.0
    for i in range(model.N):
        x,_,z=env[i]
        Henv += -2*model.Dvec[i]*x + 2*model.Evec[i]*z
    A=2*model.epsilon + float(np.dot(model.Lvec,env[:,2]))
    def f(z):
        return -2*model.delta*math.sqrt(max(0.0,1-z*z)) + A*z + Henv-Etarget
    grid=np.linspace(-0.999999999,0.999999999,801)
    vals=np.array([f(z) for z in grid])
    roots=[]
    for k in range(len(grid)-1):
        a,b=grid[k],grid[k+1]; fa,fb=vals[k],vals[k+1]
        if abs(fa)<1e-11: roots.append(float(a))
        if fa*fb<0:
            try: roots.append(float(brentq(f,a,b,xtol=2e-13,rtol=2e-13,maxiter=100)))
            except Exception: pass
    if abs(vals[-1])<1e-11: roots.append(float(grid[-1]))
    out=[]
    for z in sorted(roots):
        if not out or abs(z-out[-1])>1e-8: out.append(z)
    return out


def _section_exact_energy(model, Rinterp, Etarget):
    rr=model.normalize_R(Rinterp).reshape(model.M,3)
    env=rr[1:].copy()
    roots=_section_roots_for_Z(model,env,Etarget)
    if not roots: return None
    Z=min(roots,key=lambda z:abs(z-rr[0,2]))
    x=math.sqrt(max(0.0,1-Z*Z))
    R=np.vstack([[x,0.0,Z],env]).reshape(-1)
    if abs(model.energy(R)-Etarget)>2e-8: return None
    return model.R_to_u(R),R


def _integrate_dense(model,R0,total_time,dt):
    nt=int(np.floor(total_time/dt))+1
    tt=np.linspace(0,total_time,nt)
    sol=solve_ivp(model.rhs,(0,total_time),R0,method='DOP853',t_eval=tt,rtol=2e-8,atol=1e-10)
    if not sol.success: raise RuntimeError(sol.message)
    return sol.t,sol.y.T


def _extract_section(model,times,traj,Etarget):
    sec=[]; y=traj[:,1]
    for k in range(len(times)-1):
        if y[k] <= 0.0 < y[k+1]:
            dy=y[k+1]-y[k]; a=0.0 if abs(dy)<1e-15 else -y[k]/dy; a=float(np.clip(a,0,1))
            R=(1-a)*traj[k]+a*traj[k+1]
            if R[0] <= 0: continue
            ex=_section_exact_energy(model,R,Etarget)
            if ex is None: continue
            u,RR=ex; t=(1-a)*times[k]+a*times[k+1]
            sec.append({'t':float(t),'u':u,'R':RR})
    return sec


def _recurrence_candidates(section,cfg):
    if len(section)<3:return []
    X=np.array([q['R'] for q in section]); ts=np.array([q['t'] for q in section]); tree=cKDTree(X)
    out=[]
    for i in range(len(section)):
        for j in tree.query_ball_point(X[i],r=cfg['COARSE_RADIUS']):
            if j<=i:continue
            T=ts[j]-ts[i]
            if not(cfg['T_MIN']<=T<=cfg['T_MAX']):continue
            out.append({'u':section[i]['u'].copy(),'T':float(T),'D':float(np.linalg.norm(X[j]-X[i]))})
    out.sort(key=lambda c:c['D'])
    return out[:cfg['CANDIDATES_PER_TRAJECTORY']]


def _candidate_key(c):
    vals=np.concatenate([np.round(np.asarray(c['u']),7),[round(float(c['T']),6)]])
    return hashlib.sha1(vals.tobytes()).hexdigest()[:20]


def _diversify_candidates(cands,cfg):
    cands=sorted(cands,key=lambda c:c['D']);out=[];used=set();bins={}
    width=max(3.0,.025*cfg['T_MAX']);cap=4
    for c in cands:
        b=int(c['T']//width);h=_candidate_key(c)
        if bins.get(b,0)>=cap or h in used:continue
        out.append(c);used.add(h);bins[b]=bins.get(b,0)+1
        if len(out)>=cfg['CANDIDATES_PER_EPOCH']:return out
    for c in cands:
        h=_candidate_key(c)
        if h not in used:
            out.append(c);used.add(h)
            if len(out)>=cfg['CANDIDATES_PER_EPOCH']:break
    return out


def _search_epoch_cfg(cfg,epoch,N):
    c=dict(cfg);mode=epoch%4
    if mode==0:c['T_MIN'],c['T_MAX']=cfg['T_MIN'],min(cfg['T_MAX'],90+12*N)
    elif mode==1:c['T_MIN'],c['T_MAX']=max(cfg['T_MIN'],40.),min(cfg['T_MAX'],210+12*N)
    elif mode==2:c['T_MIN'],c['T_MAX']=max(cfg['T_MIN'],100.),cfg['T_MAX']
    c['COARSE_RADIUS']=cfg['COARSE_RADIUS']*[.85,1.,1.15,1.30][mode]
    return c


def _reduce_period_model(model,R0,T,cfg):
    best=float(T)
    for q in range(2,13):
        tt=T/q
        if tt<cfg['T_MIN']:continue
        Rf=model.integrate_final(R0,tt,rtol=5e-10,atol=2e-11)
        if Rf is not None and np.linalg.norm(Rf-R0)<5*cfg['PERIODIC_TOL']:best=min(best,tt)
    return best


def _orbit_excursion_model(model,R0,T):
    try:
        _,tr=model.integrate_grid(R0,T,500,rtol=3e-10,atol=2e-11)
        return float(np.max(np.linalg.norm(tr-R0,axis=1)))
    except Exception:return np.nan


def _validate_search_orbit(model,u,T,Etarget,cfg,source='search'):
    R0=model.u_to_R(u)
    Tred=_reduce_period_model(model,R0,T,cfg)
    if Tred < T*(1-1e-6):T=float(Tred)
    Rf=model.integrate_final(R0,T,rtol=3e-11,atol=3e-13)
    if Rf is None:return None
    D=float(np.linalg.norm(Rf-R0));dE=float(model.energy(R0)-Etarget);exc=_orbit_excursion_model(model,R0,T)
    if D>cfg['PERIODIC_TOL'] or abs(dE)>cfg['ENERGY_TOL'] or not np.isfinite(exc) or exc<cfg['MIN_EXCURSION']:return None
    fl=floquet_analysis(model,R0,T)
    if fl is None or not np.isfinite(fl['rho']):return None
    if float(fl['rho'])<cfg['CLEAR_RHO']:return None
    return {'u':model.R_to_u(R0),'R0':R0,'T':float(T),'return_D':D,'energy':float(model.energy(R0)),
            'energy_error':dE,'excursion':exc,'rho':float(fl['rho']),'lambda':float(fl['lambda']),
            'lambda_over_omega':float(fl['lambda_over_omega']),'det':float(fl['det']),
            'symplectic_error':fl.get('symplectic_error',np.nan),'reciprocal_pair_error':fl.get('reciprocal_pair_error',np.nan),
            'floquet_method':fl.get('floquet_method',''),'canonical_pole_margin':fl.get('canonical_pole_margin',np.nan),
            'eigvals':np.asarray(fl.get('eigvals',[]),complex),'Mphys':np.asarray(fl.get('Mphys',[])),'source':source}


def _refine_candidate(model,c,Etarget,cfg):
    N=model.N; x0=section_x_from_u(c['u'],c['T'],N)
    lo=np.full(2*N+2,-np.inf);hi=np.full(2*N+2,np.inf)
    lo[0]=-0.999999;hi[0]=0.999999
    for i in range(N):lo[1+i]=-0.999999;hi[1+i]=0.999999
    for i in range(N):lo[1+N+i]=-10*np.pi;hi[1+N+i]=10*np.pi
    lo[-1]=cfg['T_MIN'];hi[-1]=cfg['T_MAX'];x0=np.minimum(np.maximum(x0,lo+1e-10),hi-1e-10)
    try:
        def fun(x):return section_shooting_residual(x,model,Etarget,rtol=4e-9,atol=2e-10)
        res=least_squares(fun,x0,bounds=(lo,hi),method='trf',xtol=2e-10,ftol=2e-10,gtol=2e-10,max_nfev=cfg['MAX_NFEV'],x_scale='jac')
        u=section_x_to_u(res.x[:-1],N);T=float(res.x[-1]);R=model.u_to_R(u);Rf=model.integrate_final(R,T,rtol=3e-9,atol=2e-10)
        D=np.linalg.norm(Rf-R) if Rf is not None else np.inf
        if D<2e-3 and abs(model.energy(R)-Etarget)<2e-4:
            def polish(x):return section_shooting_residual(x,model,Etarget,rtol=1.5e-11,atol=8e-13)
            res=least_squares(polish,res.x,bounds=(lo,hi),method='trf',xtol=3e-13,ftol=3e-13,gtol=3e-13,max_nfev=cfg['POLISH_NFEV'],x_scale='jac')
            u=section_x_to_u(res.x[:-1],N);T=float(res.x[-1])
        return _validate_search_orbit(model,u,T,Etarget,cfg,'recurrence_search')
    except Exception:return None


def _equivalent_orbits(model,a,b,cfg):
    rel=abs(float(a['T'])-float(b['T']))/max(1e-15,min(float(a['T']),float(b['T'])))
    if rel>cfg['DEDUP_PERIOD_REL_TOL']:return False,None
    d=best_phase_rms(model,a,model,b,points=360 if cfg['REQUIRED']>2 else 180,allow_time_reversal=True)
    ok=d['trajectory_rms']<cfg['DEDUP_RMS_TOL'] and d['trajectory_max']<cfg['DEDUP_MAX_TOL']
    return bool(ok),d


def _dedup_orbits(model,orbits,cfg):
    reps=[];classes=[]
    for o in sorted(orbits,key=lambda z:(float(z['T']),-float(z['rho']))):
        hit=None;detail=None
        for k,r in enumerate(reps):
            eq,d=_equivalent_orbits(model,o,r,cfg)
            if eq:hit=k;detail=d;break
        if hit is None:
            reps.append(o);classes.append([o])
        else:classes[hit].append(o)
    return reps,classes


def _orbit_row(o,idx=None):
    return {'orbit':idx,'T':o['T'],'return_D':o['return_D'],'energy':o['energy'],'energy_error':o['energy_error'],
            'excursion':o['excursion'],'rho':o['rho'],'lambda':o['lambda'],'lambda_over_omega':o['lambda_over_omega'],
            'det_M':o['det'],'symplectic_error':o.get('symplectic_error'),'reciprocal_pair_error':o.get('reciprocal_pair_error'),
            'floquet_method':o.get('floquet_method'),'source':o.get('source',''),'u_json':json.dumps(np.asarray(o['u']).tolist()),
            'R0_json':json.dumps(np.asarray(o['R0']).tolist())}


def _row_orbit(r):
    return {'u':np.asarray(json.loads(r['u_json']),float),'R0':np.asarray(json.loads(r['R0_json']),float),'T':ffloat(r['T']),
            'return_D':ffloat(r['return_D']),'energy':ffloat(r['energy']),'energy_error':ffloat(r['energy_error']),
            'excursion':ffloat(r['excursion']),'rho':ffloat(r['rho']),'lambda':ffloat(r['lambda']),
            'lambda_over_omega':ffloat(r['lambda_over_omega']),'det':ffloat(r['det_M']),
            'symplectic_error':ffloat(r.get('symplectic_error')),'reciprocal_pair_error':ffloat(r.get('reciprocal_pair_error')),
            'floquet_method':r.get('floquet_method',''),'source':r.get('source','csv')}


def _save_orbit_catalog(path,orbits):
    write_csv(path,[_orbit_row(o,i) for i,o in enumerate(orbits)])


def _load_orbit_catalog(path):
    return [_row_orbit(r) for r in read_csv(path)] if Path(path).exists() else []


def _rotate_vec_axis(v,axis,theta):
    axis=np.asarray(axis,float);v=np.asarray(v,float);na=np.linalg.norm(axis)
    if na<1e-12:return v.copy()
    k=axis/na
    return v*math.cos(theta)+np.cross(k,v)*math.sin(theta)+k*np.dot(k,v)*(1-math.cos(theta))


def _random_same_sum_embedding(R,N,rng,nmoves=None):
    """Explore the W=0 microscopic degeneracy while preserving sum_i r_i exactly.

    Pair rotations keep a+b fixed and preserve |a|=|b|=1. Repeating them samples
    different labelled environmental realizations of the same collective parent UPO.
    """
    rr=np.asarray(R,float).reshape(N+1,3).copy();env=rr[1:].copy();nmoves=int(nmoves or max(6,3*N))
    for _ in range(nmoves):
        i,j=rng.choice(N,2,replace=False);a=env[i].copy();b=env[j].copy();p=a+b;d=a-b
        if np.linalg.norm(p)<1e-10:
            # antipodal pair: any common rotation preserves zero pair sum
            axis=rng.normal(size=3);theta=rng.uniform(-np.pi,np.pi);aa=_rotate_vec_axis(a,axis,theta);env[i]=aa/np.linalg.norm(aa);env[j]=-env[i]
            continue
        if np.linalg.norm(d)<1e-10:continue
        theta=rng.uniform(-np.pi,np.pi);dp=_rotate_vec_axis(d,p,theta);env[i]=(p+dp)/2;env[j]=(p-dp)/2
        env[i]/=np.linalg.norm(env[i]);env[j]/=np.linalg.norm(env[j])
    env=env[rng.permutation(N)]
    rr[1:]=env
    return rr.reshape(-1)


def _try_homogeneous_seeds(model,Etarget,cfg,base_root,seed=MASTER_SEED):
    """Resolve the W=0 neutral family into candidate fixed-W microscopic UPOs.

    Homogeneous UPOs are numerical seeds only. Accepted objects must independently
    satisfy the asymmetric equations, target energy, periodicity and hyperbolicity.
    """
    seeds=[];rng=np.random.default_rng(int(seed)+31337*model.N)
    # Keep this stage finite; recurrence search remains the authoritative fallback.
    trials_per_parent={2:8,4:10,6:12,8:14,10:16}[model.N]
    seedcfg=dict(cfg);seedcfg['MAX_NFEV']=min(cfg['MAX_NFEV'],90);seedcfg['POLISH_NFEV']=min(cfg['POLISH_NFEV'],90)
    for oid in range(4):
        try:base=load_base_orbit(base_root,model.N,oid,model.pattern_kind,model.pattern_seed)
        except Exception as exc:
            log(f'  parent UPO{oid} unavailable: {exc}');continue
        bank=[base['R0']]
        for _ in range(trials_per_parent-1):bank.append(_random_same_sum_embedding(base['R0'],model.N,rng))
        for k,Rseed in enumerate(bank):
            useed=model.R_to_u(Rseed);useed[1]=0.0;c={'u':useed,'T':base['T'],'D':np.nan}
            o=_refine_candidate(model,c,Etarget,seedcfg)
            if o is None:continue
            o['source']=f'homogeneous_parent_UPO{oid}_degenerate_seed';seeds.append(o)
            reps,_=_dedup_orbits(model,seeds,cfg)
            log(f'  parent UPO{oid} seed {k+1}/{len(bank)} -> valid; independent seed families={len(reps)}')
            if len(reps)>=cfg['REQUIRED']:return reps
    return seeds



def _parent_guided_initial(model,Etarget,base_root,rng):
    """One full-energy state obtained from a random W=0 parent embedding."""
    oid=int(rng.integers(0,4));base=load_base_orbit(base_root,model.N,oid,model.pattern_kind,model.pattern_seed)
    R=_random_same_sum_embedding(base['R0'],model.N,rng)
    # Add a moderate tangent kick so coarse trajectories do not all shadow parents.
    B=model.tangent_basis(R);v=rng.normal(size=model.PHYS_DIM);v/=max(np.linalg.norm(v),1e-15);dR=B@(0.08*v)
    Rp=R.copy()
    for k in range(model.M):
        j=3*k;r=R[j:j+3];dr=dR[j:j+3];a=np.linalg.norm(dr)
        if a>0:Rp[j:j+3]=math.cos(a)*r+math.sin(a)*(dr/a)
    Rp,ok=project_to_energy_shell(model,Rp,Etarget,tol=2e-10)
    return Rp if ok else sample_microcanonical_full_energy(model,Etarget,rng)


def run_search(args):
    N=int(args.N);root=Path(args.root);base_root=Path(args.base_root);W=float(args.env_epsilon_rms)
    if W<=0:raise ValueError('Environmental RMS epsilon must be >0 for this study')
    model=HeteroModel(N,W,args.pattern,args.pattern_seed);E=target_energy(N);cfg=search_config(N,args.quick,args.required_upos)
    if getattr(args,'search_budget_hours',None) is not None: cfg['SEARCH_BUDGET_HOURS']=float(args.search_budget_hours)
    out=root/'SEARCH'/f'N{N}';ensure(out);global _INTERRUPTION_FILE;_INTERRUPTION_FILE=out/'INTERRUPTED.json'
    done=out/'SEARCH_DONE.json';selected_path=out/'selected_independent_upos.csv';all_path=out/'all_valid_upos.csv'
    if done.exists() and selected_path.exists() and not args.force:
        selected=_load_orbit_catalog(selected_path)
        if len(selected)>=args.required_upos:
            log(f'N={N} search checkpoint complete: {len(selected)} UPOs');return
    write_json(out/'MODEL.json',{'model':model.info(),'target_energy':E,'energy_density':REFERENCE_ENERGY_DENSITY,
              'required_upos':args.required_upos,'equivalence':'phase origin + exact time reversal only; no environment permutations'})
    found=_load_orbit_catalog(all_path)
    if not found:
        found.extend(_try_homogeneous_seeds(model,E,cfg,base_root,args.seed));_save_orbit_catalog(all_path,found)
    reps,_=_dedup_orbits(model,[o for o in found if o['rho']>=cfg['CLEAR_RHO']],cfg)
    processed_path=out/'search_processed_candidates.csv';processed_rows=read_csv(processed_path) if processed_path.exists() else [];processed={r['candidate_key'] for r in processed_rows}
    state=read_json(out/'search_state.json',{}) or {};epoch=int(state.get('epoch',0));start=time.perf_counter();budget=cfg['SEARCH_BUDGET_HOURS']*3600
    while len(reps)<cfg['REQUIRED']:
        if time.perf_counter()-start>budget:
            write_json(out/'SEARCH_NEEDS_RESUME.json',{'N':N,'epoch':epoch,'independent':len(reps),'required':cfg['REQUIRED'],'time':utcnow()})
            _save_orbit_catalog(all_path,found);_save_orbit_catalog(selected_path,reps);raise SearchIncomplete(f'N={N}: {len(reps)}/{cfg["REQUIRED"]}; re-submit same job')
        ecfg=_search_epoch_cfg(cfg,epoch,N);candfile=out/f'search_epoch_{epoch:03d}_candidates.csv'
        if candfile.exists():
            cands=[]
            for r in read_csv(candfile):cands.append({'u':np.asarray(json.loads(r['u_json']),float),'T':ffloat(r['T']),'D':ffloat(r['D'])})
        else:
            allc=[];rng=np.random.default_rng(args.seed+N*100000+epoch*1009)
            log(f'N={N} search epoch {epoch}: T=[{ecfg["T_MIN"]:.1f},{ecfg["T_MAX"]:.1f}] radius={ecfg["COARSE_RADIUS"]:.3f}')
            for q in range(cfg['COARSE_TRAJECTORIES_PER_EPOCH']):
                try:
                    R=(_parent_guided_initial(model,E,base_root,rng) if q%2 else sample_microcanonical_full_energy(model,E,rng));tt,tr=_integrate_dense(model,R,cfg['COARSE_TIME'],cfg['COARSE_DT']);sec=_extract_section(model,tt,tr,E);cc=_recurrence_candidates(sec,ecfg);allc.extend(cc)
                    log(f'  coarse {q+1}/{cfg["COARSE_TRAJECTORIES_PER_EPOCH"]}: section={len(sec)} recurrences={len(cc)}')
                except Exception as exc:log('  WARNING coarse skipped:',exc)
            cands=_diversify_candidates(allc,cfg)
            write_csv(candfile,[{'rank':i,'D':c['D'],'T':c['T'],'u_json':json.dumps(np.asarray(c['u']).tolist())} for i,c in enumerate(cands)])
        for ci,c in enumerate(cands):
            key=f'{epoch}:{ci}:{_candidate_key(c)}'
            if key in processed:continue
            if time.perf_counter()-start>budget:break
            log(f'N={N} epoch={epoch} candidate={ci+1}/{len(cands)} D0={c["D"]:.3e} T0={c["T"]:.6f}')
            o=_refine_candidate(model,c,E,cfg);row={'candidate_key':key,'epoch':epoch,'candidate_index':ci,'D0':c['D'],'T0':c['T'],'accepted':bool(o is not None),'time':utcnow()}
            if o is not None:
                found.append(o);_save_orbit_catalog(all_path,found);row.update({'T':o['T'],'D':o['return_D'],'rho':o['rho'],'lambda_over_omega':o['lambda_over_omega']});log(f'  VALID T={o["T"]:.9f} D={o["return_D"]:.2e} rho={o["rho"]:.6g}')
            processed_rows.append(row);processed.add(key);write_csv(processed_path,processed_rows)
            reps,_=_dedup_orbits(model,[x for x in found if x['rho']>=cfg['CLEAR_RHO']],cfg);_save_orbit_catalog(selected_path,reps[:cfg['REQUIRED']]);log(f'  independent hyperbolic UPOs: {len(reps)}/{cfg["REQUIRED"]}')
            if len(reps)>=cfg['REQUIRED']:break
        epoch+=1;write_json(out/'search_state.json',{'epoch':epoch,'independent':len(reps)})
    selected=sorted(reps[:cfg['REQUIRED']],key=lambda o:o['T']);_save_orbit_catalog(selected_path,selected)
    # Store the selected four in the same orbit-bundle layout consumed by the validated metrics code.
    for oid,o in enumerate(selected):
        fl=floquet_analysis(model,o['R0'],o['T']);save_orbit_bundle(orbit_dir(root,N,oid,W),model,o,fl,extra={'selection':'independent asymmetric search','source':o.get('source','')})
    write_json(done,{'status':'COMPLETE','N':N,'environmental_epsilon_rms':W,'n_independent_upos':len(selected),'completed_utc':utcnow()})
    if (out/'SEARCH_NEEDS_RESUME.json').exists():(out/'SEARCH_NEEDS_RESUME.json').unlink()
    log(f'N={N} SEARCH COMPLETE: four independent asymmetric UPOs')

# =============================================================================
# GRAM-BREAKING DIAGNOSTICS
# =============================================================================


def env_gram(model, R):
    E = np.asarray(R,float).reshape(model.M,3)[1:]
    return E@E.T


def gram_drift_on_trajectory(model, traj):
    G0 = env_gram(model,traj[0])
    diffs = []
    pair_rms = []
    iu = np.triu_indices(model.N,1)
    for R in traj:
        d = env_gram(model,R)-G0
        diffs.append(float(np.max(np.abs(d))))
        if len(iu[0]):
            pair_rms.append(float(np.sqrt(np.mean(d[iu]**2))))
        else:
            pair_rms.append(0.0)
    return {
        "gram_max_drift":float(np.max(diffs)),
        "gram_time_rms_drift":float(np.sqrt(np.mean(np.asarray(pair_rms)**2))),
        "gram_mean_pair_rms_drift":float(np.mean(pair_rms)),
        "gram_final_max_error":float(np.max(np.abs(env_gram(model,traj[-1])-G0))),
    }


def inhomogeneity_identity_check(model, R):
    """Check analytic d/dt(r_i.r_j) against numerical RHS at one state."""
    rr = np.asarray(R,float).reshape(model.M,3)
    dr = model.rhs(0,R).reshape(model.M,3)
    errs=[]; mags=[]
    for i in range(model.N):
        for j in range(i+1,model.N):
            a = rr[i+1]; b = rr[j+1]
            num = float(np.dot(dr[i+1],b)+np.dot(a,dr[j+1]))
            # The common Z and D parts cancel only when D_i=D_j and Lambda_i=Lambda_j.
            # With our design the remaining difference is generated by E_i-E_j.
            # Compute the exact model-predicted derivative directly from the two
            # local precession fields for an independent audit.
            Z = rr[0,2]
            Bi = np.array([-2*model.Dvec[i],0.0,2*model.Evec[i]+model.Lvec[i]*Z])
            Bj = np.array([-2*model.Dvec[j],0.0,2*model.Evec[j]+model.Lvec[j]*Z])
            pred = float(np.dot(np.cross(Bi,a),b)+np.dot(a,np.cross(Bj,b)))
            errs.append(abs(num-pred)); mags.append(abs(pred))
    return {
        "gram_derivative_identity_max_error":float(max(errs,default=0.0)),
        "gram_derivative_predicted_abs_mean":float(np.mean(mags)) if mags else 0.0,
        "gram_derivative_predicted_abs_max":float(max(mags,default=0.0)),
    }


# =============================================================================
# PRODUCT-STATE OVERLAPS / SCAR METRICS
# =============================================================================


def pair_overlap_matrix(model, A, B, chunk=256):
    A = np.asarray(A,float); B=np.asarray(B,float)
    out = np.empty((len(A),len(B)),float)
    bb = B.reshape(len(B),model.M,3)
    for s in range(0,len(A),chunk):
        aa = A[s:s+chunk].reshape(-1,model.M,3)
        Q = np.ones((len(aa),len(B)),float)
        for k in range(model.M):
            Q *= .5*(1+np.clip(aa[:,k,:]@bb[:,k,:].T,-1,1))
        out[s:s+len(aa)] = np.clip(Q,0,1)
    return out


def max_tube_overlap(model, R, phase):
    return float(np.max(pair_overlap_matrix(model,np.asarray(R)[None,:],phase)[0]))


def survival_fidelity(model, traj, R0):
    rr0=np.asarray(R0,float).reshape(model.M,3)
    tr=np.asarray(traj,float).reshape(len(traj),model.M,3)
    F=np.ones(len(tr),float)
    for k in range(model.M):
        F *= .5*(1+np.clip(tr[:,k,:]@rr0[k],-1,1))
    return np.clip(F,0,1)


def tube_time_series(model,traj,phase):
    Q=pair_overlap_matrix(model,traj,phase)
    return np.mean(Q,axis=1),np.max(Q,axis=1),Q


def revival_metrics(F,T,times,M,window_frac=.12,max_n=20):
    F=np.asarray(F,float); times=np.asarray(times,float)
    peaks=[]; exact=[]; peak_t=[]; offsets=[]; abs_offsets=[]
    for n in range(1,max_n+1):
        lo,hi=(n-window_frac)*T,(n+window_frac)*T
        mask=(times>=lo)&(times<=hi)
        if np.any(mask):
            inds=np.flatnonzero(mask); j=inds[int(np.argmax(F[mask]))]
            pv=float(F[j]); pt=float(times[j])
        else:
            pv,pt=np.nan,np.nan
        peaks.append(pv); peak_t.append(pt)
        off=(pt-n*T)/T if np.isfinite(pt) else np.nan
        offsets.append(off); abs_offsets.append(abs(off) if np.isfinite(off) else np.nan)
        exact.append(float(F[np.argmin(np.abs(times-n*T))]))
    phase=np.mod(times/T,1.0)
    offperiod=(times>=2*T)&(np.minimum(phase,1-phase)>window_frac)
    bg=F[offperiod] if np.any(offperiod) else F[times>=2*T]
    bg_med=float(np.median(bg)) if len(bg) else float(np.median(F))
    bg_mad=float(np.median(np.abs(bg-np.median(bg)))) if len(bg) else np.nan
    bg_sigma=1.4826*bg_mad if np.isfinite(bg_mad) else np.nan
    mean15=float(np.nanmean(peaks[:5]))
    contrast=(mean15-bg_med)/(bg_sigma+1e-15) if np.isfinite(bg_sigma) else np.nan
    root=np.power(np.clip(F,EPS,1),1.0/M)
    return {
        "revival_peak_1":peaks[0],"mean_peak_1_5":mean15,
        "mean_peak_6_10":float(np.nanmean(peaks[5:10])),
        "mean_peak_11_20":float(np.nanmean(peaks[10:20])),
        "mean_exact_1_5":float(np.nanmean(exact[:5])),
        "mean_abs_timing_offset_1_5":float(np.nanmean(abs_offsets[:5])),
        "mean_abs_timing_offset_6_10":float(np.nanmean(abs_offsets[5:10])),
        "background_median":bg_med,"background_robust_sigma":bg_sigma,
        "revival_contrast_1_5":float(contrast),
        "revival_enhancement_1_5":float(mean15/(bg_med+EPS)),
        "late_mean_F":float(np.mean(F[times>=10*T])),
        "late_mean_F_root_perTLS":float(np.mean(root[times>=10*T])),
        "peaks_json":json.dumps(peaks),
        "peak_times_over_T_json":json.dumps([pt/T if np.isfinite(pt) else None for pt in peak_t]),
        "timing_offsets_json":json.dumps(offsets),"exact_json":json.dumps(exact),
    }


def spectral_metrics(sig,times,T):
    sig=np.asarray(sig,float); times=np.asarray(times,float)
    mask=times>=T; x=sig[mask]; tt=times[mask]
    if len(x)<32:
        return {"fundamental_power_fraction":np.nan,"harmonic_power_fraction":np.nan,
                "dominant_frequency_times_T":np.nan,"fundamental_frequency_mismatch":np.nan}
    x=(x-np.mean(x))*np.hanning(len(x))
    dt=float(np.mean(np.diff(tt)))
    P=np.abs(np.fft.rfft(x))**2; f=np.fft.rfftfreq(len(x),dt)
    if len(P): P[0]=0
    den=np.sum(P)+EPS; parts=[]
    for h in range(1,5):
        target=h/T; k=int(np.argmin(np.abs(f-target)))
        a,b=max(0,k-1),min(len(P),k+2)
        parts.append(float(np.sum(P[a:b])/den))
    kd=int(np.argmax(P)) if len(P) else 0
    dom=float(f[kd]*T) if len(f) else np.nan
    target=1/T; k1=int(np.argmin(np.abs(f-target)))
    mismatch=float(abs(f[k1]-target)*T)
    return {"fundamental_power_fraction":parts[0],"harmonic_power_fraction":float(sum(parts)),
            "harmonic_parts_json":json.dumps(parts),"dominant_frequency_times_T":dom,
            "fundamental_frequency_mismatch":mismatch}


def window_slice(ppp,a,b):
    return slice(int(a*ppp),int(b*ppp)+1)


def phase_lock_metrics(Q,times,T,start_idx,end_idx):
    Nu=Q.shape[1]; idx=np.arange(start_idx,min(end_idx,len(times)))
    if len(idx)==0:return np.nan,np.nan
    expected=np.floor(((times%T)/T)*Nu).astype(int)%Nu
    shifts=np.arange(Nu); target_idx=(expected[idx,None]+shifts[None,:])%Nu
    scores=np.mean(Q[idx[:,None],target_idx],axis=0); C=float(np.max(scores))
    ridge=np.argmax(Q[idx],axis=1); phase_diff=2*np.pi*(ridge-expected[idx])/Nu
    R=float(abs(np.mean(np.exp(1j*phase_diff))))
    return C,R


def trajectory_scalar_metrics(model,traj,times,phase,T,ppp):
    F=survival_fidelity(model,traj,traj[0])
    tube_mean,tube_max,Q=tube_time_series(model,traj,phase)
    rm=revival_metrics(F,T,times,model.M)
    sf=spectral_metrics(F,times,T); st=spectral_metrics(tube_mean,times,T); sz=spectral_metrics(traj[:,2],times,T)
    out={**rm}
    out.update({f"F_{k}":v for k,v in sf.items()})
    out.update({f"tube_{k}":v for k,v in st.items()})
    out.update({f"Z_{k}":v for k,v in sz.items()})
    for a,b in ((2,20),(10,16),(16,20)):
        sl=window_slice(ppp,a,b)
        q=np.clip(tube_mean[sl],EPS,1); qm=np.clip(tube_max[sl],EPS,1)
        out[f"tube_mean_{a}_{b}"]=float(np.mean(q))
        out[f"tube_max_{a}_{b}"]=float(np.mean(qm))
        out[f"tube_log_perTLS_{a}_{b}"]=float(np.mean(np.log(q))/model.M)
    return out,F,tube_mean,tube_max,Q


def integrate_for_periods(model,R0,T,periods,ppp):
    total=float(periods*T); nt=int(periods*ppp)+1
    return model.integrate_grid(R0,total,nt,rtol=2e-9,atol=1e-11)


def renyi_occupations(profile):
    q=np.clip(np.asarray(profile,float),EPS,1.0); m1=float(np.mean(q)); out={}
    for a in (2.0,4.0):
        ma=float(np.mean(q**a))
        out[f"L{int(a)}"]=float((ma/(m1**a))**(1/(1-a))) if m1>0 and ma>0 else np.nan
    mql=float(np.mean(q*np.log(q)))
    out["L1"]=float(m1*np.exp(-mql/m1)) if m1>0 else np.nan
    out["IPR2_norm"]=float(1/out["L2"]) if out["L2"]>0 else np.nan
    return out


def trajectory_husimi_profile(model,snapshots,reference):
    return np.mean(pair_overlap_matrix(model,snapshots,reference),axis=0)


def renyi_convergence(profile,sizes,reps,rng):
    q=np.asarray(profile,float); rows=[]
    for size in sizes:
        m=min(int(size),len(q))
        if m<20:continue
        for rep in range(reps):
            idx=rng.choice(len(q),size=m,replace=False) if m<len(q) else np.arange(len(q))
            rows.append({"reference_size":m,"replicate":rep,**renyi_occupations(q[idx])})
    return rows


# =============================================================================
# STATISTICS
# =============================================================================


def cliff_delta(x,y):
    x=np.asarray(x,float); y=np.asarray(y,float)
    x=x[np.isfinite(x)]; y=y[np.isfinite(y)]
    if not len(x) or not len(y):return np.nan
    # small ensembles: exact pairwise count is cheap.
    d=(x[:,None]>y[None,:]).sum()-(x[:,None]<y[None,:]).sum()
    return float(d/(len(x)*len(y)))


def mwu_bundle(x,y,alternative="greater"):
    x=np.asarray(x,float); y=np.asarray(y,float)
    x=x[np.isfinite(x)]; y=y[np.isfinite(y)]
    if not len(x) or not len(y):return {"p":1.0,"cliff_delta":np.nan,"auc":np.nan}
    try:p=float(mannwhitneyu(x,y,alternative=alternative,method="auto").pvalue)
    except Exception:p=1.0
    cd=cliff_delta(x,y)
    return {"p":p,"cliff_delta":cd,"auc":float((cd+1)/2) if np.isfinite(cd) else np.nan}


def bootstrap_two_sample(x,y,rng,statistic="ratio",nboot=2000,level=.95):
    x=np.asarray(x,float); y=np.asarray(y,float); x=x[np.isfinite(x)]; y=y[np.isfinite(y)]
    if not len(x) or not len(y):return np.nan,np.nan,np.nan
    def stat(a,b):
        if statistic=="ratio":return float(np.mean(a)/(np.mean(b)+EPS))
        return float(np.mean(a)-np.mean(b))
    point=stat(x,y); vals=[]
    for _ in range(int(nboot)):
        vals.append(stat(x[rng.integers(0,len(x),len(x))],y[rng.integers(0,len(y),len(y))]))
    a=(1-level)/2
    return point,float(np.quantile(vals,a)),float(np.quantile(vals,1-a))


def summarize_comparison(near,ctrl,rng,direction="greater",ci="ratio",nboot=2000):
    near=np.asarray(near,float); ctrl=np.asarray(ctrl,float)
    near=near[np.isfinite(near)]; ctrl=ctrl[np.isfinite(ctrl)]
    mb=mwu_bundle(near,ctrl,alternative=direction)
    point,lo,hi=bootstrap_two_sample(near,ctrl,rng,"ratio" if ci=="ratio" else "difference",nboot)
    return {"near_mean":float(np.mean(near)) if len(near) else np.nan,
            "control_mean":float(np.mean(ctrl)) if len(ctrl) else np.nan,
            "effect":point,"effect_ci_low":lo,"effect_ci_high":hi,
            "p":mb["p"],"cliff_delta":mb["cliff_delta"],"auc":mb["auc"]}


def bh_adjust(pvals):
    p=np.asarray(pvals,float); out=np.full(len(p),np.nan)
    finite=np.isfinite(p); idx=np.where(finite)[0]
    if not len(idx):return out
    order=idx[np.argsort(p[idx])]; m=len(order); q=np.empty(m,float); running=1.0
    for rank_from_end in range(m-1,-1,-1):
        rank=rank_from_end+1; val=p[order[rank_from_end]]*m/rank
        running=min(running,val); q[rank_from_end]=min(1.0,running)
    for j,oi in enumerate(order):out[oi]=q[j]
    return out


def exact_signflip_p(diffs):
    d=np.asarray(diffs,float); d=d[np.isfinite(d)]
    if not len(d):return np.nan
    obs=abs(np.mean(d)); count=0; total=2**len(d)
    for signs in itertools.product([-1.,1.],repeat=len(d)):
        if abs(np.mean(d*np.asarray(signs)))>=obs-1e-15:count+=1
    return float(count/total)


def exact_permutation_spearman(x,y):
    x=np.asarray(x,float); y=np.asarray(y,float); n=len(x)
    if n<3:return {"rho":np.nan,"p_exact":np.nan,"n":n}
    obs=float(spearmanr(x,y).statistic); cnt=0; total=0
    if n<=8:
        for perm in itertools.permutations(y.tolist()):
            r=float(spearmanr(x,np.asarray(perm)).statistic); total+=1
            if abs(r)>=abs(obs)-1e-15:cnt+=1
        p=cnt/total
    else:
        p=float(spearmanr(x,y).pvalue)
    return {"rho":obs,"p_exact":float(p),"n":n}


# =============================================================================
# METRICS TASK
# =============================================================================


def make_away_control(model,Etarget,rng,phase,max_overlap=.20,max_trials=15000):
    best=None; bestq=np.inf
    for _ in range(max_trials):
        R=sample_microcanonical_full_energy(model,Etarget,rng,max_attempts=500)
        q=max_tube_overlap(model,R,phase)
        if q<bestq:bestq,best=q,R.copy()
        if q<=max_overlap:return R
    if best is not None:return best
    raise RuntimeError("failed full-energy away-control generation")


def metric_dir(root,N,oid,W):
    return Path(root)/"METRICS"/f"N{N}"/f"UPO{oid}"/wtag(W)


def orbit_dir(root,N,oid,W):
    return Path(root)/"UPOS"/f"N{N}"/f"UPO{oid}"


def save_orbit_bundle(path, model, orbit, floquet=None, extra=None):
    path=Path(path); ensure(path)
    data={"N":model.N,"W":model.W,"T":float(orbit["T"]),
          "return_D":float(orbit.get("return_D",np.nan)),
          "energy":float(orbit.get("energy",model.energy(orbit["R0"]))),
          "energy_error":float(orbit.get("energy_error",np.nan)),
          "u":np.asarray(orbit["u"],float).tolist(),"R0":np.asarray(orbit["R0"],float).tolist(),
          "model":model.info(),"saved_utc":utcnow()}
    if extra:data.update(sanitize(extra))
    if floquet is not None:
        data["floquet"]={k:(json.dumps([[float(z.real),float(z.imag)] for z in v]) if k=="eigvals" else v)
                         for k,v in floquet.items() if k not in ("Mphys",)}
    write_json(path/"orbit.json",data)
    np.savez_compressed(path/"orbit_full.npz",u=np.asarray(orbit["u"]),R0=np.asarray(orbit["R0"]),T=float(orbit["T"]),
                        eigvals=np.asarray(floquet.get("eigvals",[]) if floquet else [],complex),
                        Mphys=np.asarray(floquet.get("Mphys",[]) if floquet else []))


def load_saved_orbit(root,N,oid,W,pattern_kind="linear",pattern_seed=314159):
    d=orbit_dir(root,N,oid,W); j=read_json(d/"orbit.json")
    if not j:raise FileNotFoundError(d/"orbit.json")
    model=HeteroModel(N,W,pattern_kind,pattern_seed)
    return {"N":N,"orbit":oid,"W":W,"u":np.asarray(j["u"],float),
            "R0":np.asarray(j["R0"],float),"T":float(j["T"]),
            "return_D":ffloat(j.get("return_D")),"energy":ffloat(j.get("energy")),
            "energy_error":ffloat(j.get("energy_error"))}


def run_metrics(args):
    N=int(args.N); oid=int(args.orbit); W=float(args.W); root=Path(args.root)
    od=metric_dir(root,N,oid,W); ensure(od)
    done=od/"DONE.json"
    if done.exists() and (od/"summary.csv").exists() and not args.force:
        log("metrics checkpoint exists:",od); return
    global _INTERRUPTION_FILE; _INTERRUPTION_FILE=od/"INTERRUPTED.json"
    model=HeteroModel(N,W,args.pattern,args.pattern_seed); E=target_energy(N)
    orbit=load_saved_orbit(root,N,oid,W,args.pattern,args.pattern_seed)
    T=float(orbit["T"]); phase=periodic_phase_grid(model,orbit,args.phase_points)
    rng=np.random.default_rng(args.seed+N*100000+oid*1000+int(round(W*1e6)))

    # UPO audit over one period: energy, Gram breaking, stability.
    tt,upo_tr=model.integrate_grid(orbit["R0"],T,max(500,args.phase_points),rtol=2e-10,atol=2e-12)
    energies=np.array([model.energy(r) for r in upo_tr])
    gram=gram_drift_on_trajectory(model,upo_tr)
    gid=inhomogeneity_identity_check(model,orbit["R0"])
    floq=floquet_analysis(model,orbit["R0"],T)
    if floq is None:raise RuntimeError("Floquet failed")
    stab=stability_metrics(floq,T)
    audit={"N":N,"orbit":oid,"W":W,"T":T,"target_energy":E,
           "energy_drift":float(np.max(np.abs(energies-energies[0]))),
           "return_D":float(np.linalg.norm(upo_tr[-1]-upo_tr[0])),
           "rho":float(floq["rho"]),"lambda":float(floq["lambda"]),
           "lambda_over_omega":float(floq["lambda_over_omega"]),
           "det_M":float(floq["det"]),"symplectic_error":floq.get("symplectic_error"),
           "reciprocal_pair_error":floq.get("reciprocal_pair_error"),
           "floquet_method":floq.get("floquet_method"),**stab,**gram,**gid,
           "rms_Ei":float(np.sqrt(np.mean(model.Evec**2))),
           "max_abs_Ei":float(np.max(np.abs(model.Evec)))}
    write_json(od/"orbit_stability_and_gram_audit.json",audit)

    controls=[]; near_states=[]; dyn=[]; phase_rows=[]; icrows=[]
    ctrl_sparse=[]; near_sparse=[]; time_series={"control":[],"near":[]}

    for s in range(args.controls):
        R=make_away_control(model,E,rng,phase,args.control_max_tube,
                            max_trials=2000 if args.quick else 15000)
        times,tr=integrate_for_periods(model,R,T,args.periods,args.ppp)
        vals,F,tmean,tmax,Q=trajectory_scalar_metrics(model,tr,times,phase,T,args.ppp)
        gd=gram_drift_on_trajectory(model,tr[::max(1,args.ppp//2)])
        dyn.append({"kind":"control","sample":s,"energy":model.energy(R),**gd,**vals})
        icrows.append({"kind":"control","sample":s,"max_initial_tube":max_tube_overlap(model,R,phase),
                       "energy_error":model.energy(R)-E,"R_json":json.dumps(R.tolist())})
        ctrl_sparse.append(tr[2*args.ppp::args.renyi_stride].copy()); controls.append(R)
        time_series["control"].append(np.column_stack([F,tmean,tmax,tr[:,2]]))
        for a,b in STANDARD_WINDOWS+FINE_WINDOWS:
            C,Rc=phase_lock_metrics(Q,times,T,a*args.ppp,b*args.ppp+1)
            phase_rows.append({"kind":"control","sample":s,"window_start":a,"window_end":b,"C":C,"R":Rc})
        log(f"N={N} UPO={oid} W={W:g} control {s+1}/{args.controls}")

    # Independent full-energy reference for Renyi occupations.
    ref=np.array([sample_microcanonical_full_energy(model,E,rng) for _ in range(args.reference_points)],float)
    np.savez_compressed(od/"full_energy_microcanonical_reference.npz",reference=ref)

    for s in range(args.near):
        base=phase[int(rng.integers(0,len(phase)))]
        R=generate_near_state(model,base,E,rng,args.near_amplitude)
        times,tr=integrate_for_periods(model,R,T,args.periods,args.ppp)
        vals,F,tmean,tmax,Q=trajectory_scalar_metrics(model,tr,times,phase,T,args.ppp)
        gd=gram_drift_on_trajectory(model,tr[::max(1,args.ppp//2)])
        dyn.append({"kind":"near","sample":s,"energy":model.energy(R),**gd,**vals})
        icrows.append({"kind":"near","sample":s,"max_initial_tube":max_tube_overlap(model,R,phase),
                       "energy_error":model.energy(R)-E,"R_json":json.dumps(R.tolist())})
        near_sparse.append(tr[2*args.ppp::args.renyi_stride].copy()); near_states.append(R)
        time_series["near"].append(np.column_stack([F,tmean,tmax,tr[:,2]]))
        for a,b in STANDARD_WINDOWS+FINE_WINDOWS:
            C,Rc=phase_lock_metrics(Q,times,T,a*args.ppp,b*args.ppp+1)
            phase_rows.append({"kind":"near","sample":s,"window_start":a,"window_end":b,"C":C,"R":Rc})
        log(f"N={N} UPO={oid} W={W:g} near {s+1}/{args.near}")

    np.savez_compressed(od/"standard_time_series.npz",times=times,
                        control=np.asarray(time_series["control"],float),
                        near=np.asarray(time_series["near"],float),
                        columns=np.array(["return_fidelity","tube_mean","tube_max","Z"]))
    write_csv(od/"dynamics_raw.csv",dyn); write_csv(od/"initial_conditions.csv",icrows); write_csv(od/"phase_windows_raw.csv",phase_rows)

    # Renyi occupations and convergence.
    ren=[]; conv=[]
    sizes=[x for x in args.renyi_reference_sizes if x<=len(ref)]
    if len(ref) not in sizes:sizes.append(len(ref))
    sizes=sorted(set(sizes))
    for kind,collections in (("control",ctrl_sparse),("near",near_sparse)):
        for s,snaps in enumerate(collections):
            prof=trajectory_husimi_profile(model,snaps,ref); rr=renyi_occupations(prof)
            ren.append({"kind":kind,"sample":s,**rr,"mean_husimi":float(np.mean(prof))})
            for r in renyi_convergence(prof,sizes,args.renyi_convergence_reps,rng):
                conv.append({"kind":kind,"sample":s,**r})
    write_csv(od/"renyi_occupation_raw.csv",ren); write_csv(od/"renyi_convergence_raw.csv",conv)

    def vals(kind,key):return np.array([ffloat(r.get(key)) for r in dyn if r["kind"]==kind],float)
    def renvals(kind,key):return np.array([ffloat(r.get(key)) for r in ren if r["kind"]==kind],float)

    summary=dict(audit); hypotheses=[]
    def add(name,nv,cv,direction="greater",ci="ratio",primary=False):
        b=summarize_comparison(nv,cv,rng,direction,ci,args.bootstrap)
        for k,v in b.items():summary[f"{k}_{name}"]=v
        hypotheses.append({"N":N,"orbit":oid,"W":W,"metric":name,
                           "family":"primary" if primary else "secondary",
                           "direction":direction,"raw_p":b["p"],"cliff_delta":b["cliff_delta"],
                           "auc":b["auc"],"near_mean":b["near_mean"],"control_mean":b["control_mean"],
                           "effect":b["effect"],"effect_ci_low":b["effect_ci_low"],"effect_ci_high":b["effect_ci_high"]})

    add("tube_P_2_20",vals("near","tube_mean_2_20"),vals("control","tube_mean_2_20"),primary=True)
    add("tube_P_10_16",vals("near","tube_mean_10_16"),vals("control","tube_mean_10_16"),primary=True)
    add("tube_P_16_20",vals("near","tube_mean_16_20"),vals("control","tube_mean_16_20"),primary=True)
    add("tube_max_16_20",vals("near","tube_max_16_20"),vals("control","tube_max_16_20"))
    add("return_peak_1_5",vals("near","mean_peak_1_5"),vals("control","mean_peak_1_5"),primary=True)
    add("return_peak_6_10",vals("near","mean_peak_6_10"),vals("control","mean_peak_6_10"),primary=True)
    add("return_timing_1_5",vals("near","mean_abs_timing_offset_1_5"),vals("control","mean_abs_timing_offset_1_5"),direction="less",ci="difference",primary=True)
    add("return_contrast_1_5",vals("near","revival_contrast_1_5"),vals("control","revival_contrast_1_5"))
    add("F_harmonic_power",vals("near","F_harmonic_power_fraction"),vals("control","F_harmonic_power_fraction"),primary=True)
    add("tube_harmonic_power",vals("near","tube_harmonic_power_fraction"),vals("control","tube_harmonic_power_fraction"),primary=True)
    add("Z_harmonic_power",vals("near","Z_harmonic_power_fraction"),vals("control","Z_harmonic_power_fraction"))

    for key in ("L1","L2","L4"):
        nv,cv=renvals("near",key),renvals("control",key)
        # localization means control L > near L
        b=summarize_comparison(cv,nv,rng,"greater","ratio",args.bootstrap)
        summary[f"control_{key}"]=float(np.mean(cv)); summary[f"near_{key}"]=float(np.mean(nv))
        summary[f"localization_ratio_{key}"]=b["effect"]; summary[f"p_localized_{key}"]=b["p"]
        summary[f"localization_ratio_ci_low_{key}"]=b["effect_ci_low"]; summary[f"localization_ratio_ci_high_{key}"]=b["effect_ci_high"]
        hypotheses.append({"N":N,"orbit":oid,"W":W,"metric":f"Renyi_{key}",
                           "family":"primary" if key in ("L2","L4") else "secondary",
                           "direction":"control>near","raw_p":b["p"],"cliff_delta":b["cliff_delta"],"auc":b["auc"],
                           "near_mean":float(np.mean(nv)),"control_mean":float(np.mean(cv)),
                           "effect":b["effect"],"effect_ci_low":b["effect_ci_low"],"effect_ci_high":b["effect_ci_high"]})
    add("IPR2_norm",renvals("near","IPR2_norm"),renvals("control","IPR2_norm"))
    for a,b in STANDARD_WINDOWS:
        for key in ("C","R"):
            nv=np.array([ffloat(r[key]) for r in phase_rows if r["kind"]=="near" and int(r["window_start"])==a])
            cv=np.array([ffloat(r[key]) for r in phase_rows if r["kind"]=="control" and int(r["window_start"])==a])
            add(f"{key}_{a}_{b}",nv,cv)

    # Renyi convergence flag.
    conv_summary=[]
    for size in sorted(set(int(r["reference_size"]) for r in conv)):
        for key in ("L2","L4"):
            near_m=[]; ctrl_m=[]
            for kind,bucket in (("near",near_m),("control",ctrl_m)):
                samples=sorted(set(int(r["sample"]) for r in conv if r["kind"]==kind and int(r["reference_size"])==size))
                for s in samples:
                    vv=[ffloat(r[key]) for r in conv if r["kind"]==kind and int(r["reference_size"])==size and int(r["sample"])==s]
                    bucket.append(float(np.nanmean(vv)))
            conv_summary.append({"reference_size":size,"metric":key,"near_mean":float(np.nanmean(near_m)),
                                 "control_mean":float(np.nanmean(ctrl_m)),
                                 "localization_ratio":float(np.nanmean(ctrl_m)/(np.nanmean(near_m)+EPS))})
    write_csv(od/"renyi_convergence_summary.csv",conv_summary)
    for key in ("L2","L4"):
        rr=sorted([r for r in conv_summary if r["metric"]==key],key=lambda r:int(r["reference_size"]))
        rel=np.nan
        if len(rr)>=2:
            prev,last=float(rr[-2]["localization_ratio"]),float(rr[-1]["localization_ratio"])
            rel=abs(last-prev)/(abs(last)+EPS)
        summary[f"renyi_{key}_last_reference_relative_change"]=rel
        summary[f"renyi_{key}_converged_5pct"]=bool(np.isfinite(rel) and rel<=.05)

    write_csv(od/"hypothesis_tests_raw.csv",hypotheses); write_csv(od/"summary.csv",[summary])

    # Diagnostic plots.
    tnorm=times/T
    for col,ylabel,fname in [(0,"Product-state return fidelity","return_fidelity_vs_time.png"),(1,"Phase-averaged tube projection","tube_projection_vs_time.png")]:
        near_arr=np.asarray(time_series["near"],float)[:,:,col]; ctrl_arr=np.asarray(time_series["control"],float)[:,:,col]
        plt.figure(figsize=(7,4.8))
        for arr,label in ((ctrl_arr,"Full-energy control"),(near_arr,"Near asymmetric UPO")):
            m=np.mean(arr,axis=0); se=np.std(arr,axis=0,ddof=1)/math.sqrt(max(1,len(arr)))
            plt.plot(tnorm,m,label=label); plt.fill_between(tnorm,m-se,m+se,alpha=.18)
        plt.xlabel(r"$t/T$"); plt.ylabel(ylabel); plt.legend(); plt.tight_layout(); plt.savefig(od/fname,dpi=260); plt.close()

    write_json(done,{"complete":True,"completed_utc":utcnow(),"N":N,"orbit":oid,"W":W,
                     "near":args.near,"controls":args.controls,"reference_points":args.reference_points})
    log("METRICS COMPLETE",od)


# =============================================================================
# LONG FULL-SPACE FTLE
# =============================================================================


def ftle_checkpoints(model,R0,rng,checkpoints=(200,400,800,1200,1600),renorm_dt=10.0):
    checkpoints=sorted(float(x) for x in checkpoints); tmax=checkpoints[-1]
    B=model.tangent_basis(R0); q=rng.normal(size=model.PHYS_DIM); q/=np.linalg.norm(q); v=B@q
    R=np.asarray(R0,float).copy(); acc=0.0; t=0.0; out={}; next_idx=0
    D=model.BLOCH_DIM
    def aug_rhs(tloc,Y):
        rr=Y[:D]; vv=Y[D:]
        return np.concatenate([model.rhs(tloc,rr),model.jacobian(rr)@vv])
    while t < tmax-1e-12:
        target=min(t+renorm_dt,tmax)
        # land exactly on checkpoints to avoid interpolation of accumulated log.
        if next_idx<len(checkpoints) and checkpoints[next_idx]<target-1e-12:
            target=checkpoints[next_idx]
        dt=target-t
        sol=solve_ivp(aug_rhs,(0,dt),np.concatenate([R,v]),method="DOP853",rtol=2e-9,atol=1e-11)
        if not sol.success:return None
        y=sol.y[:,-1]; R=model.normalize_R(y[:D]); v=y[D:]
        for k in range(model.M):
            j=3*k; r=R[j:j+3]; v[j:j+3]-=np.dot(v[j:j+3],r)*r
        nv=np.linalg.norm(v)
        if nv<1e-300:return None
        acc+=math.log(nv); v/=nv; t=target
        while next_idx<len(checkpoints) and abs(t-checkpoints[next_idx])<1e-8:
            out[int(checkpoints[next_idx])]=float(acc/t); next_idx+=1
    return out


def run_chaos(args):
    N=int(args.N); W=float(args.W); root=Path(args.root)
    od=root/"CHAOS"/f"N{N}"/wtag(W); ensure(od)
    done=od/"DONE.json"
    if done.exists() and (od/"ftle_long_samples.csv").exists() and not args.force:
        log("chaos checkpoint exists:",od); return
    global _INTERRUPTION_FILE; _INTERRUPTION_FILE=od/"INTERRUPTED.json"
    model=HeteroModel(N,W,args.pattern,args.pattern_seed); E=target_energy(N)
    rng=np.random.default_rng(args.seed+888000+N*1000+int(round(W*1e6)))
    cps=tuple(args.ftle_checkpoints)
    rows=[]
    nsamp=args.chaos_samples
    for s in range(nsamp):
        R=sample_microcanonical_full_energy(model,E,rng)
        vals=ftle_checkpoints(model,R,rng,cps,args.ftle_renorm_dt)
        if vals is None:
            log("WARNING FTLE sample failed",s); continue
        row={"sample":s,"energy_error":model.energy(R)-E}
        for t,v in vals.items():row[f"ftle_{t}"]=v
        rows.append(row); log(f"CHAOS N={N} W={W:g} {s+1}/{nsamp}: {vals.get(int(cps[-1]),np.nan):.5g}")
    write_csv(od/"ftle_long_samples.csv",rows)
    last=int(cps[-1]); prev=int(cps[-2]) if len(cps)>1 else last
    a=np.array([ffloat(r.get(f"ftle_{last}")) for r in rows],float); a=a[np.isfinite(a)]
    b=np.array([ffloat(r.get(f"ftle_{prev}")) for r in rows],float); b=b[np.isfinite(b)]
    med=float(np.median(a)) if len(a) else np.nan; medprev=float(np.median(b)) if len(b) else np.nan
    summary={"N":N,"W":W,"n":len(rows),"checkpoints":list(cps),
             "mean_final":float(np.mean(a)) if len(a) else np.nan,"median_final":med,
             "std_final":float(np.std(a,ddof=1)) if len(a)>1 else np.nan,
             "positive_fraction_final":float(np.mean(a>1e-4)) if len(a) else np.nan,
             "median_abs_change_prev_to_final":abs(med-medprev) if np.isfinite(med+medprev) else np.nan,
             "median_rel_change_prev_to_final":abs(med-medprev)/(abs(med)+EPS) if np.isfinite(med+medprev) else np.nan,
             "rms_Ei":float(np.sqrt(np.mean(model.Evec**2)))}
    write_json(od/"summary.json",summary); write_json(done,{"complete":True,"completed_utc":utcnow(),**summary})


# =============================================================================
# CONTINUATION TASK
# =============================================================================


def run_continue(args):
    N=int(args.N); oid=int(args.orbit); root=Path(args.root); base_root=Path(args.base_root)
    ws=parse_ws(args.Ws)
    if 0.0 not in ws:ws=[0.0]+ws
    if any(w<0 for w in ws):raise ValueError("W must be nonnegative")
    bdir=root/"CONTINUATION"/f"N{N}"/f"UPO{oid}"; ensure(bdir)
    global _INTERRUPTION_FILE; _INTERRUPTION_FILE=bdir/"INTERRUPTED.json"
    E=target_energy(N)
    base=load_base_orbit(base_root,N,oid,args.pattern,args.pattern_seed)
    base_model=HeteroModel(N,0,args.pattern,args.pattern_seed)
    Rf=base_model.integrate_final(base["R0"],base["T"],rtol=3e-10,atol=2e-12)
    base["return_D"]=float(np.linalg.norm(Rf-base["R0"])); base["energy"]=base_model.energy(base["R0"]); base["energy_error"]=base["energy"]-E
    floq0=floquet_analysis(base_model,base["R0"],base["T"])
    _,tr0=base_model.integrate_grid(base["R0"],base["T"],500,rtol=2e-10,atol=2e-12)
    extra0={"canonical_env_permutation":base["canonical_env_permutation"],"gram":gram_drift_on_trajectory(base_model,tr0),
            "gram_identity":inhomogeneity_identity_check(base_model,base["R0"]),"excursion":orbit_excursion(base_model,base)}
    save_orbit_bundle(orbit_dir(root,N,oid,0.0),base_model,base,floq0,extra0)
    current=base
    trace_path=bdir/"continuation_trace.csv"

    for W in ws:
        W=float(W)
        if W==0:continue
        od=orbit_dir(root,N,oid,W)
        if (od/"orbit.json").exists() and not args.force:
            current=load_saved_orbit(root,N,oid,W,args.pattern,args.pattern_seed)
            log(f"Continuation checkpoint N={N} UPO={oid} W={W:g}; skipping")
            continue
        prev_model=HeteroModel(N,float(current["W"]),args.pattern,args.pattern_seed)
        try:
            new,trace=adaptive_continue(current,W,E,args.pattern,args.pattern_seed,trace_path,quick=args.quick,
                                        initial_step=args.cont_initial_step,max_step=args.cont_max_step,min_step=args.cont_min_step)
        except Exception as exc:
            write_json(bdir/"CONTINUATION_FAILED.json",{"N":N,"orbit":oid,"target_W":W,"last_W":current["W"],
                                                        "error":f"{type(exc).__name__}: {exc}","time":utcnow()})
            raise
        model=HeteroModel(N,W,args.pattern,args.pattern_seed)
        floq=floquet_analysis(model,new["R0"],new["T"])
        if floq is None:raise RuntimeError(f"Floquet failed N={N} UPO={oid} W={W}")
        _,tr=model.integrate_grid(new["R0"],new["T"],500,rtol=2e-10,atol=2e-12)
        branch_from_prev=best_phase_rms(prev_model,current,model,new,points=120 if args.quick else 240)
        branch_from_base=best_phase_rms(base_model,base,model,new,points=120 if args.quick else 240)
        extra={"gram":gram_drift_on_trajectory(model,tr),"gram_identity":inhomogeneity_identity_check(model,new["R0"]),
               "excursion":orbit_excursion(model,new),"branch_distance_from_previous":branch_from_prev,
               "branch_distance_from_W0":branch_from_base}
        save_orbit_bundle(od,model,new,floq,extra); current=new
        log(f"CONTINUED N={N} UPO={oid} W={W:g}: T={new['T']:.8f}, D={new['return_D']:.2e}, rho={floq['rho']:.5g}, lambda/omega={floq['lambda_over_omega']:.5g}")
    write_json(bdir/"DONE.json",{"complete":True,"N":N,"orbit":oid,"Ws":ws,"completed_utc":utcnow()})


# =============================================================================
# AGGREGATION / FDR / W-TRENDS
# =============================================================================


def read_metric_summary(root,N,oid,W):
    p=metric_dir(root,N,oid,W)/"summary.csv"
    return read_csv(p)[0] if p.exists() else None


def extract_effect(row,metric):
    if metric.startswith("Renyi_"):
        key=metric.split("_",1)[1]
        return ffloat(row.get(f"localization_ratio_{key}"))
    return ffloat(row.get(f"effect_{metric}"))


def run_aggregate(args):
    root=Path(args.root);comp=root/'COMPARISON';ensure(comp);Ns=[int(x) for x in args.Ns.split(',') if x.strip()];W=float(args.env_epsilon_rms)
    rows=[];tests=[];missing=[]
    for N in Ns:
        sp=root/'SEARCH'/f'N{N}'/'selected_independent_upos.csv'
        if not sp.exists() or len(read_csv(sp))<4:missing.append({'N':N,'stage':'search'})
        for oid in range(4):
            sm=read_metric_summary(root,N,oid,W)
            if sm is None:missing.append({'N':N,'orbit':oid,'stage':'metrics'});continue
            rr=dict(sm);rr['N']=N;rr['orbit']=oid;rr['environmental_epsilon_rms']=W;rows.append(rr)
            hp=metric_dir(root,N,oid,W)/'hypothesis_tests_raw.csv'
            if hp.exists():tests.extend(read_csv(hp))
    if missing:raise RuntimeError(f'Missing {len(missing)} required tasks; first={missing[:8]}')
    write_csv(comp/'ENV_ASYM_20_UPO_METRICS.csv',rows)
    primary=[t for t in tests if t.get('family')=='primary'];q=bh_adjust([ffloat(t.get('raw_p')) for t in primary])
    for t,qq in zip(primary,q):t['q_global_20UPO']=qq;t['significant_global_20UPO']=bool(np.isfinite(qq) and qq<ALPHA)
    write_csv(comp/'ENV_ASYM_PRIMARY_TESTS_FDR.csv',primary)
    sig={(int(t['N']),int(t['orbit']),t['metric']):bool(t['significant_global_20UPO']) for t in primary}
    nlevel=[]
    for N in Ns:
        rr=[r for r in rows if int(r['N'])==N];out={'N':N,'n_upos':len(rr),'environmental_epsilon_rms':W}
        for key in ('lambda_max_over_omega','gram_time_rms_drift'):
            a=np.array([ffloat(r.get(key)) for r in rr],float);a=a[np.isfinite(a)];out['mean_'+key]=float(np.mean(a)) if len(a) else np.nan;out['median_'+key]=float(np.median(a)) if len(a) else np.nan
        for metric in PRIMARY_METRICS:
            a=np.array([extract_effect(r,metric) for r in rr],float);a=a[np.isfinite(a)];out['mean_effect_'+metric]=float(np.mean(a)) if len(a) else np.nan;out['median_effect_'+metric]=float(np.median(a)) if len(a) else np.nan;out['n_sig_'+metric]=sum(sig.get((N,int(r['orbit']),metric),False) for r in rr)
        nlevel.append(out)
    write_csv(comp/'ENV_ASYM_N_LEVEL_SUMMARY.csv',nlevel)
    chaos=[]
    for N in Ns:
        qj=read_json(root/'CHAOS'/f'N{N}'/wtag(W)/'summary.json')
        if qj:chaos.append(qj)
        else:missing.append({'N':N,'stage':'chaos'})
    if len(chaos)!=len(Ns):raise RuntimeError('Missing chaos FTLE summaries')
    write_csv(comp/'ENV_ASYM_CHAOS_FTLE.csv',chaos)
    # Search/Floquet catalogue.
    cat=[]
    for N in Ns:
        for r in read_csv(root/'SEARCH'/f'N{N}'/'selected_independent_upos.csv'):
            cat.append({'N':N,**r})
    write_csv(comp/'ENV_ASYM_SELECTED_20_UPOS.csv',cat)
    # Preserve references for later epsilon=0/epsilon=1 comparison; do not mix control definitions silently.
    br=Path(args.base_root)/'COMPARISON'
    for fn in ('EPS1_FINAL_20_COLLECTIVE_FAMILY_METRICS.csv','EPSILON0_VS_EPSILON1_BY_N.csv','EPSILON0_VS_EPSILON1_PRIMARY_FDR_COUNTS.csv'):
        if (br/fn).exists():shutil.copy2(br/fn,comp/('REFERENCE_'+fn))
    lines=['SINGLE ENVIRONMENTAL-ASYMMETRY FINAL REPORT','',
           f'Central epsilon=1; environmental epsilon_i has zero mean and RMS={W:g}; D_i=Lambda_i=1.',
           f'Fixed E/(N+1)={REFERENCE_ENERGY_DENSITY:.15f}; N={Ns}; exactly four independently searched hyperbolic UPOs per N.',
           'Environment permutations are not used for UPO equivalence. Only phase origin and exact time reversal are quotiented.',
           'The same 24 near + 48 same-energy controls and the same primary dynamical metrics as the homogeneous study are used.',
           'Because Gram invariants are broken, fixed-collective-sector quantities are undefined; full-space Floquet and same-energy full-space FTLE are reported.', '']
    for r in nlevel:
        lines.append(f"N={r['N']}: mean lambda/omega={ffloat(r.get('mean_lambda_max_over_omega')):.6g}; GramRMS={ffloat(r.get('mean_gram_time_rms_drift')):.3e}; tube2-20={ffloat(r.get('mean_effect_tube_P_2_20')):.6g}; return1-5={ffloat(r.get('mean_effect_return_peak_1_5')):.6g}; return6-10={ffloat(r.get('mean_effect_return_peak_6_10')):.6g}; RenyiL2={ffloat(r.get('mean_effect_Renyi_L2')):.6g}")
    (comp/'ENV_ASYM_FINAL_REPORT.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    write_json(comp/'ENV_ASYM_VALIDATION.json',{'PASS':True,'Ns':Ns,'environmental_epsilon_rms':W,'n_upos':len(rows),'n_primary_tests':len(primary),'completed_utc':utcnow()})
    log('AGGREGATION COMPLETE',comp/'ENV_ASYM_FINAL_REPORT.txt')


# =============================================================================
# SMOKE TEST / PREFLIGHT
# =============================================================================


def run_smoke(args):
    root=Path(args.root);ensure(root);N=2;W=float(args.env_epsilon_rms)
    fixture=Path(__file__).with_name('smoke_known_N2_env0p1_orbit.json')
    if not fixture.exists():raise FileNotFoundError(fixture)
    j=read_json(fixture);model=HeteroModel(N,W,args.pattern,args.pattern_seed);E=target_energy(N)
    u=np.asarray(j['u'],float);T=float(j['T']);cfg=search_config(N,quick=False,required=1)
    o=_validate_search_orbit(model,u,T,E,cfg,'smoke_fixture')
    if o is None:raise RuntimeError('Known asymmetric smoke UPO failed validation')
    phase=periodic_phase_grid(model,o,60);rng=np.random.default_rng(MASTER_SEED);near=generate_near_state(model,phase[7],E,rng,1e-4);ctrl=make_away_control(model,E,rng,phase,.45,max_trials=1000)
    _,tr=model.integrate_grid(o['R0'],o['T'],240,rtol=3e-9,atol=2e-11);gd=gram_drift_on_trajectory(model,tr);fl=floquet_analysis(model,o['R0'],o['T'])
    # Exercise recurrence/refinement using the validated asymmetric orbit itself.
    tt,td=_integrate_dense(model,o['R0'],2.2*o['T'],.15);sec=_extract_section(model,tt,td,E);qc=dict(cfg);qc['COARSE_RADIUS']=.35;qc['T_MAX']=max(100.,1.4*o['T']);qc['CANDIDATES_PER_TRAJECTORY']=12;cands=_recurrence_candidates(sec,qc);refined=_refine_candidate(model,cands[0],E,qc) if cands else None
    chk={'return_D':o['return_D'],'energy_error':o['energy_error'],'gram_time_rms_drift':gd['gram_time_rms_drift'],'rho':float(fl['rho']),'lambda_over_omega':float(fl['lambda_over_omega']),'near_energy_error':float(model.energy(near)-E),'control_energy_error':float(model.energy(ctrl)-E),'section_points':len(sec),'recurrence_candidates':len(cands),'recurrence_refinement_pass':bool(refined is not None)}
    chk['PASS']=bool(chk['return_D']<5e-7 and abs(chk['energy_error'])<3e-8 and chk['gram_time_rms_drift']>1e-9 and chk['rho']>1.05 and abs(chk['near_energy_error'])<1e-8 and abs(chk['control_energy_error'])<1e-8 and chk['recurrence_refinement_pass'])
    write_json(root/'SMOKE_VALIDATION.json',chk);log('SMOKE',chk)
    if not chk['PASS']:raise RuntimeError('Smoke failed')


# =============================================================================
# CLI
# =============================================================================


def add_common_model(ap):
    ap.add_argument("--pattern",choices=["linear","random"],default="linear")
    ap.add_argument("--pattern-seed",type=int,default=314159)


def main():
    ap=argparse.ArgumentParser(description='Single environmental-asymmetry UPO/scarring pipeline')
    sub=ap.add_subparsers(dest='cmd',required=True)
    sr=sub.add_parser('search',help='find exactly four independent hyperbolic UPOs for one N')
    sr.add_argument('--root',default='ARTICLE_ENV_ASYM_SINGLE');sr.add_argument('--base-root',default='ARTICLE_EPS1_N246810');sr.add_argument('--N',type=int,required=True,choices=DEFAULT_NS);sr.add_argument('--env-epsilon-rms',type=float,default=FIXED_ENV_EPS_RMS);sr.add_argument('--required-upos',type=int,default=4);sr.add_argument('--seed',type=int,default=MASTER_SEED);sr.add_argument('--search-budget-hours',type=float,default=None,help='Operational checkpoint interval only');sr.add_argument('--force',action='store_true');sr.add_argument('--quick',action='store_true');add_common_model(sr)
    m=sub.add_parser('metrics',help='same 24-near/48-control metrics for one selected asymmetric UPO')
    m.add_argument('--root',default='ARTICLE_ENV_ASYM_SINGLE');m.add_argument('--N',type=int,required=True,choices=DEFAULT_NS);m.add_argument('--orbit',type=int,required=True,choices=range(4));m.add_argument('--W',type=float,default=FIXED_ENV_EPS_RMS)
    m.add_argument('--near',type=int,default=24);m.add_argument('--controls',type=int,default=48);m.add_argument('--periods',type=int,default=20);m.add_argument('--ppp',type=int,default=60);m.add_argument('--phase-points',type=int,default=360);m.add_argument('--near-amplitude',type=float,default=1e-4);m.add_argument('--control-max-tube',type=float,default=.20);m.add_argument('--reference-points',type=int,default=1800);m.add_argument('--renyi-stride',type=int,default=6);m.add_argument('--renyi-reference-sizes',type=lambda x:[int(q) for q in x.split(',')],default=[600,1200,1800]);m.add_argument('--renyi-convergence-reps',type=int,default=5);m.add_argument('--bootstrap',type=int,default=2000);m.add_argument('--seed',type=int,default=MASTER_SEED);m.add_argument('--force',action='store_true');m.add_argument('--quick',action='store_true');add_common_model(m)
    ch=sub.add_parser('chaos',help='same-energy full-space FTLE for one N')
    ch.add_argument('--root',default='ARTICLE_ENV_ASYM_SINGLE');ch.add_argument('--N',type=int,required=True,choices=DEFAULT_NS);ch.add_argument('--W',type=float,default=FIXED_ENV_EPS_RMS);ch.add_argument('--chaos-samples',type=int,default=24);ch.add_argument('--ftle-checkpoints',type=lambda x:[int(q) for q in x.split(',')],default=[200,400,800,1200,1600]);ch.add_argument('--ftle-renorm-dt',type=float,default=10.0);ch.add_argument('--seed',type=int,default=MASTER_SEED);ch.add_argument('--force',action='store_true');add_common_model(ch)
    ag=sub.add_parser('aggregate',help='aggregate the 20-UPO single-asymmetry dataset')
    ag.add_argument('--root',default='ARTICLE_ENV_ASYM_SINGLE');ag.add_argument('--base-root',default='ARTICLE_EPS1_N246810');ag.add_argument('--Ns',default=','.join(map(str,DEFAULT_NS)));ag.add_argument('--env-epsilon-rms',type=float,default=FIXED_ENV_EPS_RMS)
    sm=sub.add_parser('smoke');sm.add_argument('--root',default='ENV_ASYM_SMOKE');sm.add_argument('--base-root',default='ARTICLE_EPS1_N246810');sm.add_argument('--N',type=int,default=2,choices=DEFAULT_NS);sm.add_argument('--env-epsilon-rms',type=float,default=FIXED_ENV_EPS_RMS);add_common_model(sm)
    args=ap.parse_args()
    if args.cmd=='search':run_search(args)
    elif args.cmd=='metrics':run_metrics(args)
    elif args.cmd=='chaos':run_chaos(args)
    elif args.cmd=='aggregate':run_aggregate(args)
    elif args.cmd=='smoke':run_smoke(args)


if __name__=="__main__":
    main()
