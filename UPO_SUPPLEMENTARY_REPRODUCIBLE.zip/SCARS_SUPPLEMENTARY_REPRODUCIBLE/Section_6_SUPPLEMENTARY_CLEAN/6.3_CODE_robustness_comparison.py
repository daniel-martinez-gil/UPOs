#!/usr/bin/env python3
"""Section 6 final robustness comparison using the corrected homogeneous V2 baseline.

No expensive dynamics is recomputed here.  The script combines:
  * corrected homogeneous Section 3 V2 (FTLE + final collective Floquet),
  * corrected homogeneous Section 4 V2 (four final manuscript diagnostics),
  * already validated Section 6.1 central-bias results,
  * already validated Section 6.2 environmental-inhomogeneity results.

For significance counts, the final cleaned manuscript convention is used
consistently for all three models: raw one-sided Mann-Whitney p < 0.05.
The older internal FDR columns are read only as containers for the stored raw p
values; q-values are deliberately not used.
"""
import argparse
import csv
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

NS = [2, 4, 6, 8, 10]
METRICS = [
    ("tube_P_2_20", "Tube 2T-20T"),
    ("tube_P_16_20", "Tube 16T-20T"),
    ("return_peak_1_5", "Return 1T-5T"),
    ("return_timing_1_5", "Timing 1T-5T"),
]


def read_csv(path):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(path)
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_csv(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = []
    for r in rows:
        for k in r:
            if k not in fields:
                fields.append(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def f(x):
    return float(x)


def balanced(rows, name, nkey="N"):
    if len(rows) != 20:
        raise RuntimeError(f"{name}: expected 20 UPO rows, got {len(rows)}")
    counts = {N: sum(int(float(r[nkey])) == N for r in rows) for N in NS}
    if any(counts[N] != 4 for N in NS):
        raise RuntimeError(f"{name}: expected 4 UPOs per N, got {counts}")
    return counts


def mean_by_n(rows, field):
    out = {}
    for N in NS:
        vals = [f(r[field]) for r in rows if int(float(r["N"])) == N]
        if len(vals) != 4:
            raise RuntimeError(f"{field}: N={N} expected 4 values, got {len(vals)}")
        out[N] = float(np.mean(vals))
    return out


def count_raw_from_section4(rows, metric):
    key = f"p_{metric}"
    vals = [f(r[key]) for r in rows]
    if len(vals) != 20:
        raise RuntimeError(f"homogeneous {metric}: expected 20 p values")
    return int(np.sum(np.asarray(vals) < 0.05))


def count_raw_from_test_table(rows, metric, label):
    rr = [r for r in rows if r.get("metric") == metric]
    if len(rr) != 20:
        raise RuntimeError(f"{label} {metric}: expected 20 test rows, got {len(rr)}")
    return int(sum(f(r["raw_p"]) < 0.05 for r in rr))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--section3-root", required=True)
    ap.add_argument("--section4-root", required=True)
    ap.add_argument("--section61-root", required=True)
    ap.add_argument("--section62-root", required=True)
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--dpi", type=int, default=300)
    args = ap.parse_args()

    s3 = Path(args.section3_root).resolve()
    s4 = Path(args.section4_root).resolve()
    s61 = Path(args.section61_root).resolve()
    s62 = Path(args.section62_root).resolve()
    out = Path(args.output_dir).resolve()
    out.mkdir(parents=True, exist_ok=True)

    # ---------------- homogeneous V2 ----------------
    hom_floq = read_csv(s3 / "COLLECTIVE_COMPLETION" / "COMPARISON" /
                        "FIXED_SECTOR_FLOQUET_20_COLLECTIVE_FAMILIES.csv")
    hom_s4 = read_csv(s4 / "SECTION4_LOCALIZATION" / "COMPARISON" /
                      "SECTION4_PRIMARY_METRICS_20_UPOs.csv")
    balanced(hom_floq, "homogeneous Section 3 V2")
    balanced(hom_s4, "homogeneous Section 4 V2")

    summary_path = s3 / "SECTION3_INITIAL_SEARCH_SUMMARY.json"
    if not summary_path.exists():
        raise FileNotFoundError(summary_path)
    s3summary = json.load(summary_path.open())
    hom_ftle = {int(r["N"]): f(r["median_same_energy_FTLE"])
                for r in s3summary["results"]}
    if set(hom_ftle) != set(NS):
        raise RuntimeError(f"homogeneous FTLE N set mismatch: {sorted(hom_ftle)}")
    hom_chi = mean_by_n(hom_floq, "restricted_lambda_over_omega")
    hom_eff = {m: mean_by_n(hom_s4, f"effect_{m}") for m, _ in METRICS}

    # ---------------- central bias, already validated ----------------
    eps1_n = read_csv(s61 / "COMPARISON" / "EPS1_BALANCED_N_LEVEL_4x5.csv")
    if {int(r["N"]) for r in eps1_n} != set(NS):
        raise RuntimeError("central-bias N-level summary is incomplete")
    eps1_map = {int(r["N"]): r for r in eps1_n}
    central_ftle = {N: f(eps1_map[N]["broad_fullspace_ftle_median"]) for N in NS}
    central_chi = {N: f(eps1_map[N]["mean_restricted_lambda_over_omega"]) for N in NS}

    eps1_family = read_csv(s61 / "COMPARISON" / "EPS1_FINAL_20_COLLECTIVE_FAMILY_METRICS.csv")
    balanced(eps1_family, "central bias Section 6.1")
    central_eff = {m: mean_by_n(eps1_family, f"effect_{m}") for m, _ in METRICS}
    central_tests = read_csv(s61 / "FINAL_STANDARD_METRICS" / "COMPARISON" /
                             "PRIMARY_HYPOTHESIS_TESTS_FDR.csv")

    # ---------------- environmental asymmetry, already validated ----------------
    env_n = read_csv(s62 / "COMPARISON" / "ENV_ASYM_N_LEVEL_SUMMARY.csv")
    env_map = {int(r["N"]): r for r in env_n}
    if set(env_map) != set(NS):
        raise RuntimeError("environment-asymmetry N-level summary is incomplete")
    env_chaos = read_csv(s62 / "COMPARISON" / "ENV_ASYM_CHAOS_FTLE.csv")
    env_chaos_map = {int(r["N"]): r for r in env_chaos}
    if set(env_chaos_map) != set(NS):
        raise RuntimeError("environment-asymmetry chaos summary is incomplete")
    env_ftle = {N: f(env_chaos_map[N]["median_final"]) for N in NS}
    env_chi = {N: f(env_map[N]["mean_lambda_max_over_omega"]) for N in NS}
    env_eff = {m: {N: f(env_map[N][f"mean_effect_{m}"]) for N in NS}
               for m, _ in METRICS}
    env_tests = read_csv(s62 / "COMPARISON" / "ENV_ASYM_PRIMARY_TESTS_FDR.csv")

    # ---------------- unified raw-p significance counts ----------------
    count_rows = []
    counts = {"homogeneous": {}, "central_bias": {}, "environment_asymmetry": {}}
    for metric, label in METRICS:
        ch = count_raw_from_section4(hom_s4, metric)
        cc = count_raw_from_test_table(central_tests, metric, "central bias")
        ce = count_raw_from_test_table(env_tests, metric, "environment asymmetry")
        counts["homogeneous"][metric] = ch
        counts["central_bias"][metric] = cc
        counts["environment_asymmetry"][metric] = ce
        for model, n in [("homogeneous", ch), ("central_bias", cc),
                         ("environment_asymmetry", ce)]:
            count_rows.append({
                "model": model,
                "metric": metric,
                "label": label,
                "criterion": "raw one-sided Mann-Whitney p<0.05",
                "n_significant": n,
                "n_families": 20,
                "fraction_significant": n / 20.0,
            })
    write_csv(out / "ROBUSTNESS_V2_SIGNIFICANCE_COUNTS_RAW.csv", count_rows)

    # ---------------- N-level comparison ----------------
    byn = []
    for N in NS:
        row = {
            "N": N,
            "homogeneous_ftle_median": hom_ftle[N],
            "central_bias_ftle_median": central_ftle[N],
            "environment_asymmetry_ftle_median": env_ftle[N],
            "homogeneous_lambda_over_omega": hom_chi[N],
            "central_bias_lambda_over_omega": central_chi[N],
            "environment_asymmetry_lambda_over_omega_fullspace": env_chi[N],
        }
        for metric, _ in METRICS:
            row[f"homogeneous_mean_effect_{metric}"] = hom_eff[metric][N]
            row[f"central_bias_mean_effect_{metric}"] = central_eff[metric][N]
            row[f"environment_asymmetry_mean_effect_{metric}"] = env_eff[metric][N]
        byn.append(row)
    write_csv(out / "ROBUSTNESS_V2_BY_N.csv", byn)

    # ---------------- validation / concise scientific report ----------------
    central_lower_than_hom = [central_ftle[N] < hom_ftle[N] for N in NS]
    env_lower_than_hom = [env_ftle[N] < hom_ftle[N] for N in NS]
    env_gt_central = [env_ftle[N] > central_ftle[N] for N in NS]
    floquet_winner = {
        N: ("central_bias" if central_chi[N] > hom_chi[N] else "homogeneous")
        for N in NS
    }
    validation = {
        "PASS": True,
        "homogeneous_catalogue": "Section 3 V2 final collective representatives",
        "homogeneous_localization": "Section 4 V2 final collective representatives",
        "significance_criterion": "raw one-sided Mann-Whitney p<0.05",
        "Ns": NS,
        "n_families_per_model": 20,
        "central_bias_ftle_lower_than_homogeneous_all_N": all(central_lower_than_hom),
        "environment_asymmetry_ftle_lower_than_homogeneous_all_N": all(env_lower_than_hom),
        "environment_asymmetry_ftle_gt_central_bias_N": [N for N, ok in zip(NS, env_gt_central) if ok],
        "floquet_larger_model_by_N_hom_vs_central": floquet_winner,
        "significant_family_counts": counts,
    }
    with (out / "ROBUSTNESS_V2_VALIDATION.json").open("w", encoding="utf-8") as fobj:
        json.dump(validation, fobj, indent=2)

    lines = [
        "SECTION 6 ROBUSTNESS V2 - CORRECTED HOMOGENEOUS BASELINE\n\n",
        "Homogeneous input: corrected Section 3 V2 final collective catalogue + corrected Section 4 V2.\n",
        "Central-bias and environmental-asymmetry dynamics are reused from the already validated Section 6.1/6.2 calculations.\n",
        "Significance convention: raw one-sided Mann-Whitney p<0.05 for all three models, matching the cleaned final Section-4 manuscript workflow.\n\n",
        "SIGNIFICANT FAMILY COUNTS [tube2-20, tube16-20, return1-5, timing1-5]\n",
        f"homogeneous: { [counts['homogeneous'][m] for m,_ in METRICS] }\n",
        f"central bias: { [counts['central_bias'][m] for m,_ in METRICS] }\n",
        f"environmental asymmetry: { [counts['environment_asymmetry'][m] for m,_ in METRICS] }\n\n",
        "FTLE COMPARISON\n",
        f"central bias below homogeneous at all N: {all(central_lower_than_hom)}\n",
        f"environmental asymmetry below homogeneous at all N: {all(env_lower_than_hom)}\n",
        f"environmental asymmetry above central bias at N: {[N for N,ok in zip(NS,env_gt_central) if ok]}\n\n",
        "HOMOGENEOUS vs CENTRAL-BIAS FLOQUET lambda/omega\n",
    ]
    for N in NS:
        lines.append(f"N={N}: homogeneous={hom_chi[N]:.12g}; central={central_chi[N]:.12g}; larger={floquet_winner[N]}\n")
    (out / "ROBUSTNESS_V2_REPORT.txt").write_text("".join(lines), encoding="utf-8")

    # ---------------- figure ----------------
    Narr = np.asarray(NS)
    fig, axes = plt.subplots(1, 3, figsize=(13.6, 4.4), gridspec_kw={"width_ratios": [1, 1, 1.35]})
    ax1, ax2, ax3 = axes
    ax1.plot(Narr, [hom_ftle[N] for N in NS], marker="o", label="Homogeneous")
    ax1.plot(Narr, [central_ftle[N] for N in NS], marker="s", label="Central bias")
    ax1.plot(Narr, [env_ftle[N] for N in NS], marker="^", label="Environmental asymmetry")
    ax1.set_xlabel("Environment size $N$")
    ax1.set_ylabel("Median same-energy FTLE")
    ax1.set_xticks(NS)
    ax1.set_title("(a)")
    ax1.legend(fontsize=8)

    ax2.plot(Narr, [hom_chi[N] for N in NS], marker="o", label="Homogeneous")
    ax2.plot(Narr, [central_chi[N] for N in NS], marker="s", label="Central bias")
    ax2.plot(Narr, [env_chi[N] for N in NS], marker="^", label="Environmental asymmetry")
    ax2.set_xlabel("Environment size $N$")
    ax2.set_ylabel(r"Normalized UPO instability $\lambda/\omega$")
    ax2.set_xticks(NS)
    ax2.set_title("(b)")

    x = np.arange(len(METRICS))
    width = 0.24
    hv = np.array([counts["homogeneous"][m] for m,_ in METRICS], float)
    cv = np.array([counts["central_bias"][m] for m,_ in METRICS], float)
    ev = np.array([counts["environment_asymmetry"][m] for m,_ in METRICS], float)
    ax3.bar(x-width, 100*hv/20, width, label="Homogeneous")
    ax3.bar(x, 100*cv/20, width, label="Central bias")
    ax3.bar(x+width, 100*ev/20, width, label="Environmental asymmetry")
    ax3.set_xticks(x)
    ax3.set_xticklabels(["Tube\n2T-20T", "Tube\n16T-20T", "Return\n1T-5T", "Timing\n1T-5T"])
    ax3.set_ylim(0, 105)
    ax3.set_ylabel("Significant UPO families (%)\nraw one-sided MWU $p<0.05$")
    ax3.set_title("(c)")
    ax3.legend(fontsize=8)

    fig.tight_layout()
    fig.savefig(out / "robustness_summary_V2.png", dpi=args.dpi, bbox_inches="tight")
    fig.savefig(out / "robustness_summary_V2.pdf", bbox_inches="tight")
    plt.close(fig)

    print("SECTION 6 ROBUSTNESS V2 COMPLETE")
    print("Output:", out)
    print("Raw-p counts:")
    print("  homogeneous:", [counts["homogeneous"][m] for m,_ in METRICS])
    print("  central bias:", [counts["central_bias"][m] for m,_ in METRICS])
    print("  environmental asymmetry:", [counts["environment_asymmetry"][m] for m,_ in METRICS])
    print("Validation:", out / "ROBUSTNESS_V2_VALIDATION.json")


if __name__ == "__main__":
    main()
