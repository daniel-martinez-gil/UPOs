#!/usr/bin/env python3
import hashlib
import json
import os
import platform
import sys
from pathlib import Path

mods = {}
for name in ['numpy', 'scipy', 'matplotlib']:
    try:
        m = __import__(name)
        mods[name] = getattr(m, '__version__', 'unknown')
    except Exception as exc:
        mods[name] = f'ERROR: {exc}'

out = {
    'python': sys.version,
    'platform': platform.platform(),
    'packages': mods,
}

img_env = (os.environ.get('SCARS_CONTAINER_IMAGE') or os.environ.get('SCARS_APPTAINER_IMAGE') or '').strip()
if img_env:
    img = Path(img_env).expanduser().resolve()
    out['container_image'] = str(img)
    if img.exists():
        h = hashlib.sha256()
        with img.open('rb') as f:
            for block in iter(lambda: f.read(8 * 1024 * 1024), b''):
                h.update(block)
        out['container_sha256'] = h.hexdigest()
    else:
        out['container_sha256'] = 'IMAGE_NOT_FOUND'
    out['container_runtime'] = os.environ.get('SCARS_CONTAINER_RUNTIME', 'auto-detected')
else:
    out['execution_mode'] = 'host-python'

print(json.dumps(out, indent=2))
