#!/usr/bin/env bash
# Generic Python launcher for the reproducibility workflow.
# If SCARS_CONTAINER_IMAGE (or the legacy SCARS_APPTAINER_IMAGE alias) is set, run inside Apptainer/Singularity.
# Otherwise use the host Python interpreter.

PYTHON_BIN="${SCARS_PYTHON:-python3}"
IMG="${SCARS_CONTAINER_IMAGE:-${SCARS_APPTAINER_IMAGE:-}}"

if [ -n "$IMG" ]; then
  if [ ! -f "$IMG" ]; then
    echo "ERROR: container image not found: $IMG" >&2
    exit 2
  fi

  RUNTIME="${SCARS_CONTAINER_RUNTIME:-}"
  if [ -z "$RUNTIME" ]; then
    if command -v apptainer >/dev/null 2>&1; then
      RUNTIME="apptainer"
    elif command -v singularity >/dev/null 2>&1; then
      RUNTIME="singularity"
    else
      echo "ERROR: a container image is configured, but neither apptainer nor singularity is available." >&2
      exit 2
    fi
  fi

  BIND_ARGS=()
  if [ -n "${SCARS_PKG_DIR:-}" ] && [ -d "$SCARS_PKG_DIR" ]; then
    BIND_ARGS+=(--bind "$SCARS_PKG_DIR:$SCARS_PKG_DIR")
  fi
  if [ -n "${SCARS_REPRO_ROOT:-}" ] && [ -d "$SCARS_REPRO_ROOT" ]; then
    BIND_ARGS+=(--bind "$SCARS_REPRO_ROOT:$SCARS_REPRO_ROOT")
  fi

  "$RUNTIME" exec "${BIND_ARGS[@]}" "$IMG" python3 "$@"
else
  "$PYTHON_BIN" "$@"
fi
