#!/usr/bin/env python3
import argparse,csv,json,math,sys
from pathlib import Path

def rows(p):
    with open(p,newline='',encoding='utf-8') as f:return list(csv.DictReader(f))
def f(x):return float(x)
def close(a,b,atol=5e-4,rtol=5e-3):return abs(a-b)<=atol+rtol*abs(b)
def fail(msg,errs): print('FAIL:',msg);errs.append(msg)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--expected',required=True);a=ap.parse_args()
    root=Path(a.root);exp=json.load(open(a.expected));errs=[]
    # S3
    s3=root/'SECTION3';d=json.load(open(s3/'COLLECTIVE_COMPLETION/DONE.json'))
    for k in ['n_total_collective_families','families_per_N','fixed_sector_hyperbolic_rho_gt_1p05']:
        if int(d[k])!=int(exp['section3'][k]):fail(f'S3 {k}: {d[k]} != {exp["section3"][k]}',errs)
    rr=rows(s3/'COLLECTIVE_COMPLETION/COMPARISON/FIXED_SECTOR_FLOQUET_20_COLLECTIVE_FAMILIES.csv')
    for N,ev in exp['section3']['mean_chi_by_N'].items():
        vals=[f(r['restricted_lambda_over_omega']) for r in rr if int(r['N'])==int(N)]
        v=sum(vals)/len(vals)
        if not close(v,ev,1e-8,1e-6):fail(f'S3 mean chi N={N}: {v} != {ev}',errs)
    # S4
    s4=rows(root/'SECTION4/SECTION4_LOCALIZATION/COMPARISON/SECTION4_SIGNIFICANCE_SUMMARY.csv')
    mp={r['metric']:r for r in s4}
    for m,n in exp['section4']['counts'].items():
        got=int(mp[m]['n_significant_raw_p_lt_0p05'])
        if got!=n:fail(f'S4 {m} count {got} != {n}',errs)
    for m,v in exp['section4']['mean_effect'].items():
        got=f(mp[m]['mean_effect'])
        if not close(got,v,2e-6,2e-5):fail(f'S4 {m} mean_effect {got} != {v}',errs)
    # S5: compare rounded manuscript summary, allowing numerical integration noise
    s5=rows(root/'SECTION5/COMPARISON/SECTION5_ENERGY_SUMMARY_5x4.csv')
    if len(s5)!=5:fail(f'S5 row count {len(s5)} != 5',errs)
    # infer column names robustly
    for i,(e,ft,chi,tube,ret,timing) in enumerate(exp['section5']['rows']):
        r=s5[i]
        candidates={k.lower():k for k in r}
        def pick(parts):
            for k in r:
                kl=k.lower()
                if all(p in kl for p in parts):return f(r[k])
            raise KeyError(parts)
        ge=pick(['energy','density']); gft=pick(['ftle']); gchi=pick(['lambda','omega']); gt=pick(['tube','2_20']); gr=pick(['return','1_5'])
        if not close(ge,e,5e-4,0):fail(f'S5 e[{i}] {ge} != {e}',errs)
        for name,got,want,tol in [('FTLE',gft,ft,8e-4),('chi',gchi,chi,8e-4),('tube',gt,tube,8e-3),('return',gr,ret,8e-3)]:
            if not close(got,want,tol,0):fail(f'S5 {name}[{i}] {got} != {want}',errs)
    # S6.3
    v=json.load(open(root/'SECTION63/ROBUSTNESS_V2_VALIDATION.json'))
    if not v.get('PASS'):fail('S6.3 PASS is false',errs)
    order=['tube_P_2_20','tube_P_16_20','return_peak_1_5','return_timing_1_5']
    for model,key in [('homogeneous','homogeneous'),('central_bias','central_bias'),('environment_asymmetry','environmental_asymmetry')]:
        got=[int(v['significant_family_counts'][model][m]) for m in order]
        want=exp['section6']['counts'][key]
        if got!=want:fail(f'S6 counts {model}: {got} != {want}',errs)
    got={str(k):val for k,val in v['floquet_larger_model_by_N_hom_vs_central'].items()}
    if got!=exp['section6']['floquet_winner']:fail(f'S6 Floquet winners {got}',errs)
    for k in ['central_bias_ftle_lower_than_homogeneous_all_N','environment_asymmetry_ftle_lower_than_homogeneous_all_N']:
        if bool(v[k])!=bool(exp['section6'][k]):fail(f'S6 {k} mismatch',errs)
    if list(v['environment_asymmetry_ftle_gt_central_bias_N'])!=exp['section6']['environment_asymmetry_ftle_gt_central_bias_N']:fail('S6 env>central N mismatch',errs)
    out={'PASS':not errs,'errors':errs,'root':str(root.resolve())}
    (root/'FINAL_REPRODUCIBILITY_VALIDATION.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))
    return 0 if not errs else 2
if __name__=='__main__':sys.exit(main())
