#!/usr/bin/env bash

HERE="$(cd "$(dirname "$0")/.." && pwd)"
PARENT="$(cd "$HERE/.." && pwd)"
ROOT="${SCARS_REPRO_ROOT:-$PARENT/SCARS_REPRODUCTION_FINAL}"
JOBS="$HERE/REPRODUCE/jobs"
RUNPY="$HERE/REPRODUCE/run_python.sh"

mkdir -p "$ROOT/logs"

if ! command -v sbatch >/dev/null 2>&1; then
  echo "ERROR: Slurm command 'sbatch' was not found."
  echo "The automated workflow requires a Slurm cluster."
  exit 2
fi

export SCARS_PKG_DIR="$HERE"
export SCARS_REPRO_ROOT="$ROOT"

# Validate the selected Python execution environment before submitting jobs.
"$RUNPY" -c 'import numpy, scipy, matplotlib; print("SCARS Python environment OK:", numpy.__version__, scipy.__version__, matplotlib.__version__)'
rc=$?
if [ "$rc" -ne 0 ]; then
  echo "ERROR: the selected Python/container environment does not provide the required dependencies."
  exit "$rc"
fi

SBATCH_SITE=()
if [ -n "${SCARS_SLURM_PARTITION:-}" ]; then SBATCH_SITE+=(--partition="$SCARS_SLURM_PARTITION"); fi
if [ -n "${SCARS_SLURM_ACCOUNT:-}" ]; then SBATCH_SITE+=(--account="$SCARS_SLURM_ACCOUNT"); fi
if [ -n "${SCARS_SLURM_QOS:-}" ]; then SBATCH_SITE+=(--qos="$SCARS_SLURM_QOS"); fi

submit_job() {
  local var_name="$1"
  shift
  local out
  out=$(sbatch "${SBATCH_SITE[@]}" --parsable "$@")
  local rc=$?
  if [ "$rc" -ne 0 ] || [ -z "$out" ]; then
    echo "ERROR: Slurm submission failed for: $*" >&2
    return 2
  fi
  out=${out%%;*}
  printf -v "$var_name" '%s' "$out"
}

submit_job J3 -o "$ROOT/logs/S3_%j.out" -e "$ROOT/logs/S3_%j.err" "$JOBS/01_section3.slurm" || exit 2
submit_job J4 --dependency=afterok:$J3 -o "$ROOT/logs/S4_%j.out" -e "$ROOT/logs/S4_%j.err" "$JOBS/02_section4.slurm" || exit 2
submit_job J5E --dependency=afterok:$J3 -o "$ROOT/logs/S5E_%A_%a.out" -e "$ROOT/logs/S5E_%A_%a.err" "$JOBS/03_section5_energy.slurm" || exit 2
submit_job J5A --dependency=afterok:$J5E -o "$ROOT/logs/S5A_%j.out" -e "$ROOT/logs/S5A_%j.err" "$JOBS/04_section5_aggregate.slurm" || exit 2

submit_job J61 -o "$ROOT/logs/S61_%A_%a.out" -e "$ROOT/logs/S61_%A_%a.err" "$JOBS/05_section61_perN.slurm" || exit 2
submit_job J61A --dependency=afterok:$J61 -o "$ROOT/logs/S61A_%j.out" -e "$ROOT/logs/S61A_%j.err" "$JOBS/06_section61_aggregate.slurm" || exit 2

submit_job J62S --dependency=afterok:$J61A -o "$ROOT/logs/S62S_%A_%a.out" -e "$ROOT/logs/S62S_%A_%a.err" "$JOBS/07_section62_search.slurm" || exit 2
submit_job J62M --dependency=afterok:$J62S -o "$ROOT/logs/S62M_%A_%a.out" -e "$ROOT/logs/S62M_%A_%a.err" "$JOBS/08_section62_metrics.slurm" || exit 2
submit_job J62C --dependency=afterok:$J62S -o "$ROOT/logs/S62C_%A_%a.out" -e "$ROOT/logs/S62C_%A_%a.err" "$JOBS/09_section62_chaos.slurm" || exit 2
submit_job J62A --dependency=afterok:$J62M:$J62C -o "$ROOT/logs/S62A_%j.out" -e "$ROOT/logs/S62A_%j.err" "$JOBS/10_section62_aggregate.slurm" || exit 2

submit_job J63 --dependency=afterok:$J4:$J61A:$J62A -o "$ROOT/logs/S63_%j.out" -e "$ROOT/logs/S63_%j.err" "$JOBS/11_section63.slurm" || exit 2
submit_job JVAL --dependency=afterok:$J5A:$J63 -o "$ROOT/logs/VALIDATE_%j.out" -e "$ROOT/logs/VALIDATE_%j.err" "$JOBS/12_validate.slurm" || exit 2

cat > "$ROOT/JOB_IDS.txt" <<EOF2
SECTION3=$J3
SECTION4=$J4
SECTION5_ENERGY=$J5E
SECTION5_AGG=$J5A
SECTION61=$J61
SECTION61_AGG=$J61A
SECTION62_SEARCH=$J62S
SECTION62_METRICS=$J62M
SECTION62_CHAOS=$J62C
SECTION62_AGG=$J62A
SECTION63=$J63
FINAL_VALIDATE=$JVAL
EOF2

echo "Reproduction submitted."
cat "$ROOT/JOB_IDS.txt"
echo
echo "Results directory: $ROOT"
echo "Final success marker: $ROOT/FINAL_REPRODUCIBILITY_VALIDATION.json"
