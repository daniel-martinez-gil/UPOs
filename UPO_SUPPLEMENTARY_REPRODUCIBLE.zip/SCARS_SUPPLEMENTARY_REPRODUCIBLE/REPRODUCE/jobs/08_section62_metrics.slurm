#!/bin/bash
#SBATCH --job-name=SCARS_S62M
#SBATCH --array=0-19%5
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=20G
#SBATCH --time=1-12:00:00

PKG="${SCARS_PKG_DIR:-${SLURM_SUBMIT_DIR:-$PWD}}"
if [ ! -d "$PKG/REPRODUCE" ]; then
  echo "ERROR: package directory could not be determined. Run REPRODUCE/submit_reproduction.sh from the package root or set SCARS_PKG_DIR."
  exit 2
fi
ROOT="${SCARS_REPRO_ROOT:-$(cd "$PKG/.." && pwd)/SCARS_REPRODUCTION_FINAL}"
RUNPY="$PKG/REPRODUCE/run_python.sh"
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1
mkdir -p "$ROOT" "$ROOT/logs"

NS=(2 4 6 8 10)
IDX="$SLURM_ARRAY_TASK_ID"
NI=$((IDX / 4))
O=$((IDX % 4))
N="${NS[$NI]}"
CODE="$PKG/Section_6_SUPPLEMENTARY_CLEAN/6.2_CODE_environmental_inhomogeneity.py"
"$RUNPY" "$CODE" metrics --root "$ROOT/SECTION62" --N "$N" --orbit "$O" --W 0.1 --near 24 --controls 48 --periods 20 --ppp 60 --phase-points 360 --near-amplitude 1e-4 --control-max-tube 0.20 --reference-points 1800 --renyi-stride 6 --renyi-reference-sizes 600,1200,1800 --renyi-convergence-reps 5 --bootstrap 2000 --seed 20261001
rc=$?
if [ "$rc" -ne 0 ]; then false; fi
