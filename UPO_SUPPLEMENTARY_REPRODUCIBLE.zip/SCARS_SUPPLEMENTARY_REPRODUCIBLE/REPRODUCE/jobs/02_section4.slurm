#!/bin/bash
#SBATCH --job-name=SCARS_S4
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=32G
#SBATCH --time=1-12:00:00

PKG="${SCARS_PKG_DIR:-${SLURM_SUBMIT_DIR:-$PWD}}"
if [ ! -d "$PKG/REPRODUCE" ]; then
  echo "ERROR: package directory could not be determined. Run REPRODUCE/submit_reproduction.sh from the package root or set SCARS_PKG_DIR."
  exit 2
fi
ROOT="${SCARS_REPRO_ROOT:-$(cd "$PKG/.." && pwd)/SCARS_REPRODUCTION_FINAL}"
RUNPY="$PKG/REPRODUCE/run_python.sh"
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1
mkdir -p "$ROOT" "$ROOT/logs"

CORE="$PKG/Section_3_SUPPLEMENTARY_CLEAN/3.1-3.2_CODE_FTLE_and_UPO_search.py"
S4="$PKG/Section_4_SUPPLEMENTARY_CLEAN/4_CODE_UPO_localization_analysis.py"
"$RUNPY" "$S4" --section3-root "$ROOT/SECTION3" --core "$CORE" --output-root "$ROOT/SECTION4" --Ns 2,4,6,8,10 --near 24 --controls 48 --periods 20 --ppp 60 --phase-points 360 --near-amplitude 1e-4 --control-max-tube 0.20 --bootstrap 2000 --seed 927311 --force
rc=$?
if [ "$rc" -ne 0 ]; then false; fi
