#!/bin/bash
#SBATCH --job-name=SCARS_S3
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=32G
#SBATCH --time=4-23:00:00

PKG="${SCARS_PKG_DIR:-${SLURM_SUBMIT_DIR:-$PWD}}"
if [ ! -d "$PKG/REPRODUCE" ]; then
  echo "ERROR: package directory could not be determined. Run REPRODUCE/submit_reproduction.sh from the package root or set SCARS_PKG_DIR."
  exit 2
fi
ROOT="${SCARS_REPRO_ROOT:-$(cd "$PKG/.." && pwd)/SCARS_REPRODUCTION_FINAL}"
RUNPY="$PKG/REPRODUCE/run_python.sh"
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1
mkdir -p "$ROOT" "$ROOT/logs"

CORE="$PKG/Section_3_SUPPLEMENTARY_CLEAN/3.1-3.2_CODE_FTLE_and_UPO_search.py"
COLL="$PKG/Section_3_SUPPLEMENTARY_CLEAN/3.2-3.3_CODE_collective_UPO_completion_and_Floquet.py"
S3="$ROOT/SECTION3"

ok=1
while true; do
  "$RUNPY" "$CORE" --root "$S3" --Ns 2,4,6,8,10 --required-upos 4 --no-legacy --force-search --seed 20260923 --search-budget-hours 18
  rc=$?
  if [ "$rc" -eq 0 ]; then break; fi
  if [ "$rc" -eq 75 ]; then echo "Section 3 initial search checkpointed; resuming..."; continue; fi
  echo "FATAL: Section 3 initial search rc=$rc"; ok=0; break
done

if [ "$ok" -eq 1 ]; then
  while true; do
    "$RUNPY" "$COLL" --root "$S3" --core "$CORE" --target-collective-families 4 --collective-points 720 --restricted-rho-min 1.05 --search-budget-hours 18 --seed 927311
    rc=$?
    if [ "$rc" -eq 0 ]; then break; fi
    if [ "$rc" -eq 75 ]; then echo "Section 3 collective search checkpointed; resuming..."; continue; fi
    echo "FATAL: Section 3 collective stage rc=$rc"; ok=0; break
  done
fi

if [ "$ok" -ne 1 ]; then false; fi
