#!/bin/bash
#SBATCH --job-name=SCARS_S62C
#SBATCH --array=0-4
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=16G
#SBATCH --time=1-12:00:00

PKG="${SCARS_PKG_DIR:-${SLURM_SUBMIT_DIR:-$PWD}}"
if [ ! -d "$PKG/REPRODUCE" ]; then
  echo "ERROR: package directory could not be determined. Run REPRODUCE/submit_reproduction.sh from the package root or set SCARS_PKG_DIR."
  exit 2
fi
ROOT="${SCARS_REPRO_ROOT:-$(cd "$PKG/.." && pwd)/SCARS_REPRODUCTION_FINAL}"
RUNPY="$PKG/REPRODUCE/run_python.sh"
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1
mkdir -p "$ROOT" "$ROOT/logs"

NS=(2 4 6 8 10)
N="${NS[$SLURM_ARRAY_TASK_ID]}"
CODE="$PKG/Section_6_SUPPLEMENTARY_CLEAN/6.2_CODE_environmental_inhomogeneity.py"
"$RUNPY" "$CODE" chaos --root "$ROOT/SECTION62" --N "$N" --W 0.1 --chaos-samples 24 --ftle-checkpoints 200,400,800,1200,1600 --ftle-renorm-dt 10.0 --seed 20261001
rc=$?
if [ "$rc" -ne 0 ]; then false; fi
