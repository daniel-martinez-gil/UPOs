#!/bin/bash
#SBATCH --job-name=SCARS_S61A
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=16G
#SBATCH --time=06:00:00

PKG="${SCARS_PKG_DIR:-${SLURM_SUBMIT_DIR:-$PWD}}"
if [ ! -d "$PKG/REPRODUCE" ]; then
  echo "ERROR: package directory could not be determined. Run REPRODUCE/submit_reproduction.sh from the package root or set SCARS_PKG_DIR."
  exit 2
fi
ROOT="${SCARS_REPRO_ROOT:-$(cd "$PKG/.." && pwd)/SCARS_REPRODUCTION_FINAL}"
RUNPY="$PKG/REPRODUCE/run_python.sh"
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1
mkdir -p "$ROOT" "$ROOT/logs"

CORE="$PKG/Section_6_SUPPLEMENTARY_CLEAN/6.1a_CODE_central_bias_core.py"
MET="$PKG/Section_6_SUPPLEMENTARY_CLEAN/6.1b_CODE_central_bias_localization_metrics.py"
AGG="$PKG/Section_6_SUPPLEMENTARY_CLEAN/6.1d_CODE_central_bias_aggregation.py"
"$RUNPY" "$AGG" --root "$ROOT/SECTION61" --core "$CORE" --metrics "$MET"
rc=$?
if [ "$rc" -ne 0 ]; then false; fi
