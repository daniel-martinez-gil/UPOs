#!/bin/bash
#SBATCH --job-name=SCARS_VAL
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4G
#SBATCH --time=01:00:00

PKG="${SCARS_PKG_DIR:-${SLURM_SUBMIT_DIR:-$PWD}}"
if [ ! -d "$PKG/REPRODUCE" ]; then
  echo "ERROR: package directory could not be determined. Run REPRODUCE/submit_reproduction.sh from the package root or set SCARS_PKG_DIR."
  exit 2
fi
ROOT="${SCARS_REPRO_ROOT:-$(cd "$PKG/.." && pwd)/SCARS_REPRODUCTION_FINAL}"
RUNPY="$PKG/REPRODUCE/run_python.sh"
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1
mkdir -p "$ROOT" "$ROOT/logs"

"$RUNPY" "$PKG/REPRODUCE/capture_environment.py" > "$ROOT/ENVIRONMENT_VALIDATED.json"
"$RUNPY" "$PKG/REPRODUCE/validate_final_results.py" --root "$ROOT" --expected "$PKG/REPRODUCE/expected_results.json"
rc=$?
if [ "$rc" -ne 0 ]; then false; fi
