#!/bin/bash
#SBATCH --job-name=SCARS_S61
#SBATCH --array=0-4
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=32G
#SBATCH --time=3-12:00:00

PKG="${SCARS_PKG_DIR:-${SLURM_SUBMIT_DIR:-$PWD}}"
if [ ! -d "$PKG/REPRODUCE" ]; then
  echo "ERROR: package directory could not be determined. Run REPRODUCE/submit_reproduction.sh from the package root or set SCARS_PKG_DIR."
  exit 2
fi
ROOT="${SCARS_REPRO_ROOT:-$(cd "$PKG/.." && pwd)/SCARS_REPRODUCTION_FINAL}"
RUNPY="$PKG/REPRODUCE/run_python.sh"
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1
mkdir -p "$ROOT" "$ROOT/logs"

NS=(2 4 6 8 10)
N="${NS[$SLURM_ARRAY_TASK_ID]}"
CORE="$PKG/Section_6_SUPPLEMENTARY_CLEAN/6.1a_CODE_central_bias_core.py"
MET="$PKG/Section_6_SUPPLEMENTARY_CLEAN/6.1b_CODE_central_bias_localization_metrics.py"
PIPE="$PKG/Section_6_SUPPLEMENTARY_CLEAN/6.1c_CODE_central_bias_perN_pipeline.py"
ok=1
while true; do
  "$RUNPY" "$PIPE" --root "$ROOT/SECTION61" --core "$CORE" --metrics "$MET" --N "$N" --search-budget-hours 18 --restricted-rho-min 1.05 --sector-ftle-samples 24 --seed 20261001
  rc=$?
  if [ "$rc" -eq 0 ]; then break; fi
  if [ "$rc" -eq 75 ]; then echo "Section 6.1 N=$N checkpointed; resuming..."; continue; fi
  ok=0; echo "FATAL Section 6.1 N=$N rc=$rc"; break
done
if [ "$ok" -ne 1 ]; then false; fi
