#!/bin/bash
#SBATCH --job-name=SCARS_S62A
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=12G
#SBATCH --time=04:00:00

PKG="${SCARS_PKG_DIR:-${SLURM_SUBMIT_DIR:-$PWD}}"
if [ ! -d "$PKG/REPRODUCE" ]; then
  echo "ERROR: package directory could not be determined. Run REPRODUCE/submit_reproduction.sh from the package root or set SCARS_PKG_DIR."
  exit 2
fi
ROOT="${SCARS_REPRO_ROOT:-$(cd "$PKG/.." && pwd)/SCARS_REPRODUCTION_FINAL}"
RUNPY="$PKG/REPRODUCE/run_python.sh"
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1
mkdir -p "$ROOT" "$ROOT/logs"

CODE="$PKG/Section_6_SUPPLEMENTARY_CLEAN/6.2_CODE_environmental_inhomogeneity.py"
"$RUNPY" "$CODE" aggregate --root "$ROOT/SECTION62" --base-root "$ROOT/SECTION61" --Ns 2,4,6,8,10 --env-epsilon-rms 0.1
rc=$?
if [ "$rc" -ne 0 ]; then false; fi
