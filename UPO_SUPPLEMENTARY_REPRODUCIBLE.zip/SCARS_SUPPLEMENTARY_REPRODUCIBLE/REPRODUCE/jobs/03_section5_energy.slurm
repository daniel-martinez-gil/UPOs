#!/bin/bash
#SBATCH --job-name=SCARS_S5E
#SBATCH --array=0-4
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=24G
#SBATCH --time=2-12:00:00

PKG="${SCARS_PKG_DIR:-${SLURM_SUBMIT_DIR:-$PWD}}"
if [ ! -d "$PKG/REPRODUCE" ]; then
  echo "ERROR: package directory could not be determined. Run REPRODUCE/submit_reproduction.sh from the package root or set SCARS_PKG_DIR."
  exit 2
fi
ROOT="${SCARS_REPRO_ROOT:-$(cd "$PKG/.." && pwd)/SCARS_REPRODUCTION_FINAL}"
RUNPY="$PKG/REPRODUCE/run_python.sh"
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1
mkdir -p "$ROOT" "$ROOT/logs"

CORE="$PKG/Section_3_SUPPLEMENTARY_CLEAN/3.1-3.2_CODE_FTLE_and_UPO_search.py"
COLL="$PKG/Section_3_SUPPLEMENTARY_CLEAN/3.2-3.3_CODE_collective_UPO_completion_and_Floquet.py"
LOC="$PKG/Section_4_SUPPLEMENTARY_CLEAN/4_CODE_UPO_localization_analysis.py"
S5="$PKG/Section_5_SUPPLEMENTARY_CLEAN/5_CODE_energy_dependence.py"
REF="$ROOT/SECTION3/COLLECTIVE_COMPLETION/N10_SEARCH/N10_collective_representatives.csv"
I="$SLURM_ARRAY_TASK_ID"
ok=1
while true; do
  "$RUNPY" "$S5" --mode energy --energy-index "$I" --core "$CORE" --collective "$COLL" --localization "$LOC" --reference-orbits "$REF" --output-root "$ROOT/SECTION5" --seed 408731 --search-budget-hours 18 --sector-ftle-samples 8 --near 24 --controls 48 --ppp 60 --phase-points 360 --control-max-tube 0.20 --bootstrap 2000 --force
  rc=$?
  if [ "$rc" -eq 0 ]; then break; fi
  if [ "$rc" -eq 75 ]; then echo "Section 5 energy $I checkpointed; resuming..."; continue; fi
  ok=0; echo "FATAL Section 5 energy $I rc=$rc"; break
done
if [ "$ok" -ne 1 ]; then false; fi
