#!/bin/bash
#SBATCH --job-name=SCARS_S5A
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=8G
#SBATCH --time=02:00:00

PKG="${SCARS_PKG_DIR:-${SLURM_SUBMIT_DIR:-$PWD}}"
if [ ! -d "$PKG/REPRODUCE" ]; then
  echo "ERROR: package directory could not be determined. Run REPRODUCE/submit_reproduction.sh from the package root or set SCARS_PKG_DIR."
  exit 2
fi
ROOT="${SCARS_REPRO_ROOT:-$(cd "$PKG/.." && pwd)/SCARS_REPRODUCTION_FINAL}"
RUNPY="$PKG/REPRODUCE/run_python.sh"
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1
mkdir -p "$ROOT" "$ROOT/logs"

CORE="$PKG/Section_3_SUPPLEMENTARY_CLEAN/3.1-3.2_CODE_FTLE_and_UPO_search.py"
COLL="$PKG/Section_3_SUPPLEMENTARY_CLEAN/3.2-3.3_CODE_collective_UPO_completion_and_Floquet.py"
LOC="$PKG/Section_4_SUPPLEMENTARY_CLEAN/4_CODE_UPO_localization_analysis.py"
S5="$PKG/Section_5_SUPPLEMENTARY_CLEAN/5_CODE_energy_dependence.py"
"$RUNPY" "$S5" --mode aggregate --core "$CORE" --collective "$COLL" --localization "$LOC" --output-root "$ROOT/SECTION5"
rc=$?
if [ "$rc" -ne 0 ]; then false; fi
