#!/usr/bin/env python3
"""
Section 3.2-3.3: collective UPO completion and fixed-sector Floquet
==================================================================

Supplementary-code version extracted from the validated production script
scar_collective_completion.py (source SHA256 recorded in README).

This file performs only the Section-3 follow-up analysis:
  * identifies UPO equivalence at the collective (r0,S) level,
  * completes any N=2,4,6,8,10 catalogue that contains fewer than four distinct collective families,
  * computes Floquet multipliers restricted to the exact four-dimensional
    invariant manifold S^2 x S^2_|S|,
  * audits all N=2,4,6,8,10 catalogues at collective level, and
  * writes the final 20-family fixed-sector Floquet table.

The original production script also recalculated Section-4 localization
metrics for newly found N=10 UPOs and rebuilt FDR tables. Those later-section
operations are intentionally omitted here. Consequently this supplementary
script depends only on the first Section-3 script and no longer requires
scar_final_standard_metrics.py.

Dependencies: numpy, scipy. CPU only; no pandas.
"""

import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

import argparse
import csv
import hashlib
import importlib.util
import json
import math
import signal
import sys
import time
from pathlib import Path

import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import minimize_scalar


SCHEMA = "collective_completion_v1"
SYMS = ("I", "P", "T", "PT")


def ensure(p):
    Path(p).mkdir(parents=True, exist_ok=True)


def jdump(path, obj):
    path = Path(path)
    ensure(path.parent)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(_san(obj), f, indent=2, sort_keys=True)
    os.replace(tmp, path)


def _san(x):
    if isinstance(x, dict):
        return {str(k): _san(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_san(v) for v in x]
    if isinstance(x, np.ndarray):
        return _san(x.tolist())
    if isinstance(x, (np.floating, float)):
        v = float(x)
        return v if np.isfinite(v) else str(v)
    if isinstance(x, (np.integer, int)):
        return int(x)
    if isinstance(x, (np.bool_, bool)):
        return bool(x)
    if isinstance(x, complex):
        return {"real": float(x.real), "imag": float(x.imag)}
    return x


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_csv(path, rows):
    path = Path(path)
    ensure(path.parent)
    if not rows:
        with open(path, "w", encoding="utf-8") as f:
            f.write("")
        return
    fields = []
    for r in rows:
        for k in r:
            if k not in fields:
                fields.append(k)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: _csv_value(r.get(k, "")) for k in fields})
    os.replace(tmp, path)


def _csv_value(v):
    if isinstance(v, (list, tuple, np.ndarray, dict)):
        return json.dumps(_san(v), separators=(",", ":"))
    if isinstance(v, (np.floating, float)):
        return repr(float(v))
    if isinstance(v, (np.integer, int)):
        return str(int(v))
    if isinstance(v, (np.bool_, bool)):
        return "True" if bool(v) else "False"
    return v


def as_float(x, default=np.nan):
    try:
        return float(x)
    except Exception:
        return default


def load_module(name, path):
    path = str(Path(path).resolve())
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


class CollectiveHelpers:
    """Minimal collective-coordinate helpers needed by the Section-3 analysis."""

    @staticmethod
    def central_vector(core, R):
        R = np.asarray(R, float)
        return R[:3].copy()

    @staticmethod
    def env_collective(core, R):
        R = np.asarray(R, float)
        if core.N is None:
            raise RuntimeError("core.set_model(N) must be called before env_collective")
        env = R[3:].reshape(int(core.N), 3)
        return np.sum(env, axis=0)


# ---------------------------------------------------------------------------
# Fixed-sector collective Floquet calculation
# ---------------------------------------------------------------------------

def cross_matrix(a):
    ax, ay, az = map(float, a)
    return np.array([
        [0.0, -az, ay],
        [az, 0.0, -ax],
        [-ay, ax, 0.0],
    ])


def reduced_rhs6(t, y):
    r = np.asarray(y[:3], float)
    S = np.asarray(y[3:6], float)
    B0 = np.array([-2.0, 0.0, S[2]])
    Be = np.array([-2.0, 0.0, r[2]])
    return np.concatenate([np.cross(B0, r), np.cross(Be, S)])


def reduced_jacobian6(y):
    r = np.asarray(y[:3], float)
    S = np.asarray(y[3:6], float)
    B0 = np.array([-2.0, 0.0, S[2]])
    Be = np.array([-2.0, 0.0, r[2]])
    ez = np.array([0.0, 0.0, 1.0])
    J = np.zeros((6, 6), float)
    J[:3, :3] = cross_matrix(B0)
    J[3:, 3:] = cross_matrix(Be)
    # d[(B0 x r)]/d Sz = ez x r
    J[:3, 5] = np.cross(ez, r)
    # d[(Be x S)]/d z0 = ez x S
    J[3:, 2] = np.cross(ez, S)
    return J


def reduced_variational_rhs(t, Y):
    y = Y[:6]
    M = Y[6:].reshape(6, 6)
    f = reduced_rhs6(t, y)
    J = reduced_jacobian6(y)
    return np.concatenate([f, (J @ M).ravel()])


def tangent_pair(v):
    v = np.asarray(v, float)
    n = v / np.linalg.norm(v)
    axes = np.eye(3)
    a = axes[int(np.argmin(np.abs(axes @ n)))]
    e1 = np.cross(n, a)
    e1 /= np.linalg.norm(e1)
    e2 = np.cross(n, e1)
    e2 /= np.linalg.norm(e2)
    return e1, e2


def collective_tangent_basis(r, S):
    e1, e2 = tangent_pair(r)
    f1, f2 = tangent_pair(S)
    B = np.zeros((6, 4), float)
    B[:3, 0] = e1
    B[:3, 1] = e2
    B[3:, 2] = f1
    B[3:, 3] = f2
    return B


def induced_symplectic_form(B, r, S):
    """Symplectic form on S^2_1 x S^2_|S| in an arbitrary tangent basis.

    For a spin vector X of radius R with Lie-Poisson bracket, the orbit
    symplectic form is omega_X(u,v) = -X.(u x v)/R^2.  Start and end points of
    a periodic orbit coincide, so the same 4x4 form applies to the monodromy.
    """
    s = float(np.linalg.norm(S))
    Om = np.zeros((4, 4), float)
    for i in range(4):
        ui_r, ui_s = B[:3, i], B[3:, i]
        for j in range(4):
            vj_r, vj_s = B[:3, j], B[3:, j]
            wr = -float(np.dot(r, np.cross(ui_r, vj_r)))
            ws = -float(np.dot(S, np.cross(ui_s, vj_s))) / max(s * s, 1e-300)
            Om[i, j] = wr + ws
    return Om


def reciprocal_pair_error(eigvals):
    a = np.abs(np.asarray(eigvals, complex))
    a = a[np.isfinite(a) & (a > 1e-300)]
    if len(a) < 2:
        return np.nan
    logs = np.sort(np.log(a))
    return float(np.max(np.abs(logs + logs[::-1])))


def fixed_sector_floquet(core, metrics, orbit, rtol=1.5e-11, atol=1.5e-13):
    R0 = np.asarray(orbit["R0"], float)
    T = float(orbit["T"])
    r0 = metrics.central_vector(core, R0)
    S0 = metrics.env_collective(core, R0)
    snorm = float(np.linalg.norm(S0))
    if snorm < 1e-9:
        raise RuntimeError("Collective |S| is too small for a well-defined S^2 sector")

    y0 = np.concatenate([r0, S0])
    Y0 = np.concatenate([y0, np.eye(6).ravel()])
    sol = solve_ivp(
        reduced_variational_rhs,
        (0.0, T),
        Y0,
        method="DOP853",
        rtol=rtol,
        atol=atol,
    )
    if not sol.success:
        raise RuntimeError(sol.message)
    yf = sol.y[:, -1]
    yT = yf[:6]
    M6 = yf[6:].reshape(6, 6)

    B = collective_tangent_basis(r0, S0)
    M4 = B.T @ M6 @ B
    eig = np.linalg.eigvals(M4)
    # Autonomous 2-DOF Hamiltonian flow has a neutral multiplier pair at +1
    # (flow direction + energy partner). Remove that pair BEFORE defining the
    # Heller instability. Otherwise tiny numerical splitting of the neutral
    # pair can be mistaken for weak hyperbolicity.
    neutral_order = np.argsort(np.abs(eig - 1.0))
    neutral_idx = neutral_order[:2]
    active_idx = neutral_order[2:]
    neutral = eig[neutral_idx]
    nonneutral = eig[active_idx]
    # Sort only for reproducible serialization; the stability is defined from
    # the non-neutral pair.
    eig = eig[np.argsort(np.abs(eig))[::-1]]
    abs_active = np.abs(nonneutral)
    rho = float(np.max(abs_active))
    # Unit-circle elliptic pairs can lie at 1+roundoff. Clip negligible growth.
    if rho <= 1.0 + 1e-7:
        lam = 0.0
    else:
        lam = float(np.log(rho) / T)
    omega = 2.0 * np.pi / T

    positive_logs = np.log(abs_active[abs_active > 1.0 + 1e-7]) / T
    lam_sum = float(np.sum(positive_logs)) if len(positive_logs) else 0.0

    Om = induced_symplectic_form(B, r0, S0)
    sym_num = np.linalg.norm(M4.T @ Om @ M4 - Om, ord="fro")
    sym_den = max(np.linalg.norm(Om, ord="fro"), 1e-300)
    sym_err = float(sym_num / sym_den)

    # Independent direct reduced-orbit return check.
    ret = float(np.linalg.norm(yT - y0))
    norm_err_r = float(abs(np.linalg.norm(yT[:3]) - 1.0))
    norm_err_s = float(abs(np.linalg.norm(yT[3:]) - snorm))

    return {
        "restricted_return_D": ret,
        "restricted_rho": rho,
        "restricted_lambda": lam,
        "restricted_lambda_over_omega": float(lam / omega),
        "restricted_lambda_plus_sum": lam_sum,
        "restricted_heller_sum_over_2pi": float(lam_sum / omega),
        "restricted_det": float(np.linalg.det(M4)),
        "restricted_symplectic_error": sym_err,
        "restricted_reciprocal_pair_error": reciprocal_pair_error(eig),
        "restricted_n_positive": int(len(positive_logs)),
        "restricted_hyperbolic_rho_gt_1p05": bool(rho > 1.05),
        "restricted_neutral_pair_max_abs_mu_minus_1": float(np.max(np.abs(neutral - 1.0))),
        "restricted_nonneutral_abs_json": json.dumps([float(abs(z)) for z in nonneutral]),
        "restricted_eigvals_json": json.dumps([[float(z.real), float(z.imag)] for z in eig]),
        "restricted_norm_error_central": norm_err_r,
        "restricted_norm_error_collective": norm_err_s,
        "S_norm": snorm,
        "M4": M4,
        "eigvals4": eig,
    }


# ---------------------------------------------------------------------------
# Robust collective-family equivalence with continuous phase optimization
# ---------------------------------------------------------------------------

def collective_phase_trajectory(core, metrics, orbit, points=720):
    tr = core.phase_grid(orbit, points)
    out = np.empty((len(tr), 6), float)
    for k, R in enumerate(tr):
        out[k, :3] = metrics.central_vector(core, R)
        out[k, 3:] = metrics.env_collective(core, R)
    return out


def apply_collective_symmetry(A, sym):
    A = np.asarray(A, float).copy().reshape(-1, 2, 3)
    if sym in ("T", "PT"):
        A = A[::-1].copy()
    if sym == "P":
        A[:, :, 1] *= -1.0
        A[:, :, 2] *= -1.0
    elif sym == "T":
        A[:, :, 1] *= -1.0
    elif sym == "PT":
        A[:, :, 2] *= -1.0
    elif sym != "I":
        raise ValueError(sym)
    return A.reshape(-1, 6)


def periodic_interp_uniform(A, phases):
    A = np.asarray(A, float)
    P = len(A)
    x = np.mod(np.asarray(phases, float), 1.0) * P
    i0 = np.floor(x).astype(int) % P
    a = x - np.floor(x)
    i1 = (i0 + 1) % P
    return (1.0 - a)[:, None] * A[i0] + a[:, None] * A[i1]


def collective_distance_at_shift(A, B, shift, snorm):
    P = len(A)
    phases = np.arange(P, dtype=float) / P + float(shift)
    Br = periodic_interp_uniform(B, phases)
    A2 = A.copy()
    B2 = Br.copy()
    A2[:, 3:] /= max(snorm, 1e-12)
    B2[:, 3:] /= max(snorm, 1e-12)
    d = A2 - B2
    rms = float(np.sqrt(np.mean(d * d)))
    blocks = d.reshape(P, 2, 3)
    mx = float(np.max(np.linalg.norm(blocks, axis=2)))
    return rms, mx


def robust_collective_alignment(core, metrics, oa, ob, points=720,
                                period_rel_tol=5e-4, S_rel_tol=5e-5,
                                rms_tol=2e-4, max_tol=1e-3):
    Ta, Tb = float(oa["T"]), float(ob["T"])
    relT = abs(Ta - Tb) / max(min(Ta, Tb), 1e-12)
    sa = float(np.linalg.norm(metrics.env_collective(core, oa["R0"])))
    sb = float(np.linalg.norm(metrics.env_collective(core, ob["R0"])))
    relS = abs(sa - sb) / max(sa, sb, 1e-12)
    if relT > period_rel_tol or relS > S_rel_tol:
        return {
            "equivalent": False, "period_rel_diff": relT, "S_rel_diff": relS,
            "rms": np.nan, "max": np.nan, "phase_shift": np.nan, "symmetry": "",
        }

    A = collective_phase_trajectory(core, metrics, oa, points=points)
    B0 = collective_phase_trajectory(core, metrics, ob, points=points)
    # Use the average |S| in the normalized geometric comparison.
    s = 0.5 * (sa + sb)
    best = (np.inf, np.inf, np.nan, "")

    # Coarse discrete search, then bounded continuous refinement around the best
    # grid shift. This makes the independence audit insensitive to phase-grid
    # quantization.
    for sym in SYMS:
        B = apply_collective_symmetry(B0, sym)
        coarse_best = (np.inf, 0)
        for k in range(points):
            r, _ = collective_distance_at_shift(A, B, k / points, s)
            if r < coarse_best[0]:
                coarse_best = (r, k)
        k = coarse_best[1]
        center = k / points
        half = 1.5 / points

        def fun(u):
            return collective_distance_at_shift(A, B, u, s)[0]

        # Parameter is periodic. Minimize in an unwrapped interval; interpolation
        # itself wraps mod 1.
        res = minimize_scalar(fun, bounds=(center - half, center + half), method="bounded",
                              options={"xatol": 2e-10})
        shift = float(res.x % 1.0)
        rms, mx = collective_distance_at_shift(A, B, shift, s)
        if rms < best[0]:
            best = (rms, mx, shift, sym)

    eq = bool(best[0] < rms_tol and best[1] < max_tol)
    return {
        "equivalent": eq,
        "period_rel_diff": relT,
        "S_rel_diff": relS,
        "rms": float(best[0]),
        "max": float(best[1]),
        "phase_shift": float(best[2]),
        "symmetry": best[3],
    }


def robust_classify(core, metrics, orbits, outdir, prefix="collective", points=720):
    parent = list(range(len(orbits)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    pairs = []
    for i in range(len(orbits)):
        for j in range(i + 1, len(orbits)):
            d = robust_collective_alignment(core, metrics, orbits[i], orbits[j], points=points)
            pairs.append({"i": i, "j": j, **d})
            if d["equivalent"]:
                union(i, j)

    root_to_class = {}
    classes = []
    cmap = {}
    for i in range(len(orbits)):
        r = find(i)
        if r not in root_to_class:
            root_to_class[r] = len(root_to_class)
            classes.append([])
        cid = root_to_class[r]
        classes[cid].append(i)
        cmap[i] = cid

    rows = []
    for cid, members in enumerate(classes):
        for i in members:
            s = float(np.linalg.norm(metrics.env_collective(core, orbits[i]["R0"])))
            rows.append({
                "collective_class": cid,
                "orbit_index": i,
                "is_representative": bool(i == members[0]),
                "class_size": len(members),
                "T": float(orbits[i]["T"]),
                "rho_full": float(orbits[i].get("rho", np.nan)),
                "S_norm": s,
                "source": orbits[i].get("source", ""),
            })
    ensure(outdir)
    write_csv(Path(outdir) / f"{prefix}_equivalence_pairs.csv", pairs)
    write_csv(Path(outdir) / f"{prefix}_classes.csv", rows)
    return cmap, classes, pairs


# ---------------------------------------------------------------------------
# N=10 collective-family completion search
# ---------------------------------------------------------------------------

def candidate_key(core, epoch, idx, c):
    if hasattr(core, "_candidate_hash"):
        return f"{epoch}:{idx}:{core._candidate_hash(c)}"
    A = np.asarray(c["A"], float)
    h = hashlib.sha1(np.concatenate([np.round(A, 7), [round(float(c["T"]), 6)]]).tobytes()).hexdigest()[:20]
    return f"{epoch}:{idx}:{h}"


def save_rep_pool(core, path, reps):
    core.save_orbits(path, reps)


def load_rep_pool(core, path):
    return core.load_orbits(path) if Path(path).exists() else []


def seed_collective_representatives(core, metrics, root, search_dir, points, N):
    core.set_model(N)
    p = Path(root) / f"N{N}" / "selected_independent_upos.csv"
    current = core.load_orbits(p)
    cmap, classes, _ = robust_classify(core, metrics, current, search_dir,
                                        prefix=f"initial_N{N}_collective", points=points)
    reps = [current[members[0]] for members in classes]
    for q, o in enumerate(reps):
        o = dict(o)
        o["source"] = f"existing_N{N}_collective_rep_{q}"
        reps[q] = o
    return reps, current, cmap, classes


def reorder_candidates_for_collective_novelty(core, metrics, cands, reps):
    if not reps:
        return list(cands)
    repS = np.array([np.linalg.norm(metrics.env_collective(core, o["R0"])) for o in reps], float)
    repT = np.array([float(o["T"]) for o in reps], float)
    scored = []
    for c in cands:
        try:
            R = core.A_to_bloch(c["A"])
            s = np.linalg.norm(metrics.env_collective(core, R))
            t = float(c["T"])
            dS = float(np.min(np.abs(repS - s)) / 10.0)
            dT = float(np.min(np.abs(repT - t) / np.maximum(repT, 1e-9)))
            D = max(float(c.get("D", 1.0)), 1e-14)
            # Primary priority remains recurrence quality, but a modest novelty
            # bonus prevents the already-known S~4.9/T~11-21 families from
            # monopolizing every refinement epoch.
            score = math.log10(D) - 0.45 * min(dS, 0.5) - 0.20 * min(dT, 1.0)
        except Exception:
            score = 1e9
        scored.append((score, c))
    scored.sort(key=lambda x: x[0])
    return [c for _, c in scored]


def completion_search(core, metrics, root, outdir, args, N):
    core.set_model(N)
    target = core.target_energy_for_n(N)
    cfg = core.config_for_n(N, quick=False, required_upos=20)
    # Search only; stop based on collective classes rather than the core's
    # microscopic exact-symmetry count.
    cfg["SEARCH_BUDGET_HOURS"] = float(args.search_budget_hours)
    ensure(outdir)
    pool_path = Path(outdir) / f"N{N}_collective_representatives.csv"
    processed_path = Path(outdir) / "processed_candidates.csv"
    state_path = Path(outdir) / "search_state.json"
    complete_path = Path(outdir) / "SEARCH_COMPLETE.json"
    need_path = Path(outdir) / "SEARCH_NEEDS_RESUME.json"

    if pool_path.exists():
        reps = load_rep_pool(core, pool_path)
        # Revalidate every saved representative in case a previous run ended
        # between writes.
        valid = []
        for o in reps:
            v = core.validate_orbit(o, target, cfg)
            if v is not None:
                valid.append(v)
        reps = valid
    else:
        reps, _, _, _ = seed_collective_representatives(core, metrics, root, outdir, args.collective_points, N)
        # Existing reps must also be hyperbolic in the fixed sector to count.
        kept = []
        for o in reps:
            rf = fixed_sector_floquet(core, metrics, o)
            if rf["restricted_rho"] > args.restricted_rho_min:
                kept.append(o)
            else:
                print(f"WARNING existing N={N} collective representative T={o['T']:.9f} is not fixed-sector hyperbolic: rho={rf['restricted_rho']:.8g}", flush=True)
                kept.append(o)  # retain for audit; final report will flag it
        reps = kept
        save_rep_pool(core, pool_path, reps)

    # Collapse any accidental duplicates in the saved pool.
    _, classes, _ = robust_classify(core, metrics, reps, outdir,
                                     prefix=f"current_N{N}_collective", points=args.collective_points)
    reps = [reps[m[0]] for m in classes]
    save_rep_pool(core, pool_path, reps)

    if len(reps) >= args.target_collective_families:
        jdump(complete_path, {"n_collective_families": len(reps), "target": args.target_collective_families})
        if need_path.exists():
            need_path.unlink()
        return reps

    processed_rows = read_csv(processed_path) if processed_path.exists() else []
    processed = {r.get("candidate_key", "") for r in processed_rows}
    st = {}
    if state_path.exists():
        with open(state_path, encoding="utf-8") as f:
            st = json.load(f)
    epoch = int(st.get("epoch", 0))
    t0 = time.perf_counter()
    budget = float(args.search_budget_hours) * 3600.0

    while len(reps) < args.target_collective_families:
        if time.perf_counter() - t0 > budget:
            payload = {
                "epoch": epoch,
                "n_collective_families": len(reps),
                "target": args.target_collective_families,
                "message": "Re-submit the identical command. Search checkpoints are safe.",
            }
            jdump(need_path, payload)
            jdump(state_path, {"epoch": epoch})
            raise RuntimeError("SEARCH_BUDGET_REACHED_SAFE_RESUME")

        print("\n" + "=" * 88, flush=True)
        print(f"N={N} COLLECTIVE SEARCH EPOCH {epoch}: {len(reps)}/{args.target_collective_families} collective families", flush=True)
        print("=" * 88, flush=True)
        cands = core._generate_epoch_candidates(cfg, target, outdir, epoch, args.seed)
        cands = reorder_candidates_for_collective_novelty(core, metrics, cands, reps)

        for ci, c in enumerate(cands):
            key = candidate_key(core, epoch, ci, c)
            if key in processed:
                continue
            if time.perf_counter() - t0 > budget:
                jdump(state_path, {"epoch": epoch})
                jdump(need_path, {"epoch": epoch, "candidate_index": ci,
                                  "n_collective_families": len(reps), "target": args.target_collective_families})
                save_rep_pool(core, pool_path, reps)
                raise RuntimeError("SEARCH_BUDGET_REACHED_SAFE_RESUME")

            print(f"N={N} epoch {epoch} candidate {ci+1}/{len(cands)}: D0={float(c.get('D', np.nan)):.3e}, T0={float(c['T']):.6f}", flush=True)
            o, status = core._refine_candidate_final(c, cfg, target)
            row = {
                "candidate_key": key,
                "epoch": epoch,
                "candidate_index": ci,
                "D0": c.get("D", np.nan),
                "T0": c.get("T", np.nan),
                "refine_status": status,
            }

            if o is not None:
                row.update({
                    "T": float(o["T"]), "return_D": float(o["return_D"]),
                    "rho_full": float(o["rho"]),
                    "lambda_over_omega_full": float(o["lambda"] / (2 * np.pi / o["T"])),
                })
                if float(o["rho"]) < cfg["CLEAR_UPO_RHO"]:
                    row["decision"] = "reject_not_full_hyperbolic"
                else:
                    try:
                        rf = fixed_sector_floquet(core, metrics, o)
                        row.update({k: v for k, v in rf.items() if k not in ("M4", "eigvals4")})
                        if rf["restricted_rho"] <= args.restricted_rho_min:
                            row["decision"] = "reject_not_fixed_sector_hyperbolic"
                        else:
                            dup = None
                            for j, q in enumerate(reps):
                                al = robust_collective_alignment(core, metrics, q, o,
                                                                 points=args.collective_points)
                                if al["equivalent"]:
                                    dup = (j, al)
                                    break
                            if dup is not None:
                                row["decision"] = "reject_existing_collective_family"
                                row["duplicate_of_rep"] = dup[0]
                                row["equiv_rms"] = dup[1]["rms"]
                                row["equiv_max"] = dup[1]["max"]
                                row["equiv_symmetry"] = dup[1]["symmetry"]
                            else:
                                oo = dict(o)
                                oo["source"] = f"collective_completion_epoch{epoch}_candidate{ci}"
                                reps.append(oo)
                                save_rep_pool(core, pool_path, reps)
                                robust_classify(core, metrics, reps, outdir,
                                                prefix=f"current_N{N}_collective", points=args.collective_points)
                                row["decision"] = "ACCEPT_NEW_COLLECTIVE_FAMILY"
                                row["new_collective_count"] = len(reps)
                                print(f"*** ACCEPTED NEW COLLECTIVE FAMILY #{len(reps)}: T={o['T']:.10f}, full rho={o['rho']:.7g}, restricted rho={rf['restricted_rho']:.7g}, restricted lambda/omega={rf['restricted_lambda_over_omega']:.6g}", flush=True)
                    except Exception as exc:
                        row["decision"] = "reject_restricted_floquet_error"
                        row["restricted_error"] = f"{type(exc).__name__}: {exc}"
            else:
                row["decision"] = "reject_refinement_or_validation"

            processed_rows.append(row)
            processed.add(key)
            write_csv(processed_path, processed_rows)
            if len(reps) >= args.target_collective_families:
                break

        epoch += 1
        jdump(state_path, {"epoch": epoch})

    # Final high-resolution pairwise audit.
    cmap, classes, _ = robust_classify(core, metrics, reps, outdir,
                                        prefix=f"FINAL_N{N}_collective", points=max(args.collective_points, 1080))
    final_reps = [reps[m[0]] for m in classes]
    if len(final_reps) < args.target_collective_families:
        raise RuntimeError(f"Final high-resolution audit reduced N={N} to {len(final_reps)} collective families")
    final_reps = final_reps[:args.target_collective_families]
    save_rep_pool(core, pool_path, final_reps)
    jdump(complete_path, {
        "n_collective_families": len(final_reps),
        "target": args.target_collective_families,
        "periods": [float(o["T"]) for o in final_reps],
        "S_norms": [float(np.linalg.norm(metrics.env_collective(core, o["R0"]))) for o in final_reps],
    })
    if need_path.exists():
        need_path.unlink()
    return final_reps


# ---------------------------------------------------------------------------
# Reuse / extend standard-metrics analysis for the two newly found N=10 UPOs
# ---------------------------------------------------------------------------




# ---------------------------------------------------------------------------
# Final 20-family Section-3 table
# ---------------------------------------------------------------------------

def collective_representatives_existing_N(core, metrics, root, N, points, outroot):
    """Audit the four selected microscopic UPOs and return one rep per collective family."""
    core.set_model(N)
    path = Path(root) / f"N{N}" / "selected_independent_upos.csv"
    if not path.exists():
        raise FileNotFoundError(path)
    upos = core.load_orbits(path)
    cmap, classes, _ = robust_classify(
        core, metrics, upos, outroot,
        prefix=f"N{N}_FINAL_COLLECTIVE_AUDIT", points=points
    )
    reps = [upos[members[0]] for members in classes]
    if len(reps) != 4:
        raise RuntimeError(
            f"N={N}: expected four distinct collective families in the validated catalogue, got {len(reps)}"
        )
    return reps


def final_floquet_rows(core, metrics, root, reps_by_N, args):
    outroot = Path(root) / "COLLECTIVE_COMPLETION"
    comp = outroot / "COMPARISON"
    ensure(comp)
    rows = []

    for N in (2, 4, 6, 8, 10):
        reps = reps_by_N[N]
        if len(reps) != 4:
            raise RuntimeError(f"N={N}: expected four final collective representatives, got {len(reps)}")
        core.set_model(N)
        for cid, orbit in enumerate(reps):
            rf = fixed_sector_floquet(core, metrics, orbit)
            row = {
                "N": N,
                "collective_class": cid,
                "metric_upo_id": cid,
                "T": float(orbit["T"]),
                "rho_full": float(orbit.get("rho", np.nan)),
                "lambda_over_omega_full": float(
                    orbit.get("lambda", np.nan) / (2*np.pi/orbit["T"])
                ),
            }
            row.update({k: v for k, v in rf.items() if k not in ("M4", "eigvals4")})
            rows.append(row)

    if len(rows) != 20:
        raise RuntimeError(f"Expected 20 final collective families, got {len(rows)}")
    write_csv(comp / "FIXED_SECTOR_FLOQUET_20_COLLECTIVE_FAMILIES.csv", rows)
    return rows


def write_section3_report(root, rows):
    comp = Path(root) / "COLLECTIVE_COMPLETION" / "COMPARISON"
    byN = {}
    for r in rows:
        byN.setdefault(int(r["N"]), []).append(r)
    nh = sum(bool(r["restricted_hyperbolic_rho_gt_1p05"]) for r in rows)
    lines = [
        "SECTION 3 FINAL COLLECTIVE-UPO / FIXED-SECTOR FLOQUET VALIDATION\n\n",
        f"Final catalogue: {len(rows)} collective UPO families = 4 per N for N=2,4,6,8,10.\n",
        f"Fixed-sector rho > 1.05: {nh}/{len(rows)} representatives.\n",
        "Collective equivalence is tested using the central Bloch trajectory r0(t) and the collective environmental trajectory S(t), including time-origin shifts and exact I/P/T/PT symmetries.\n",
        "Fixed-sector Floquet is evaluated on S^2 x S^2_|S|.\n\n",
        "N-LEVEL FIXED-SECTOR SUMMARY\n",
    ]
    for N in sorted(byN):
        rr = byN[N]
        mean_chi = float(np.mean([float(x["restricted_lambda_over_omega"]) for x in rr]))
        periods = [float(x["T"]) for x in rr]
        n_h = sum(bool(x["restricted_hyperbolic_rho_gt_1p05"]) for x in rr)
        lines.append(
            f"N={N}: families=4; fixed-sector rho>1.05={n_h}/4; "
            f"mean(lambda_sec/omega)={mean_chi:.15g}; "
            f"periods={json.dumps(periods)}\n"
        )
    lines.append("\nSee FIXED_SECTOR_FLOQUET_20_COLLECTIVE_FAMILIES.csv for orbit-resolved values.\n")
    (comp / "SECTION3_FINAL_VALIDATION_REPORT.txt").write_text("".join(lines), encoding="utf-8")


def manifest(root):
    root = Path(root)
    rows = []
    for f in sorted(root.rglob("*")):
        if f.is_file() and f.name != "MANIFEST_SHA256.csv":
            try:
                rows.append({
                    "relative_path": str(f.relative_to(root)),
                    "bytes": f.stat().st_size,
                    "sha256": file_sha256(f),
                })
            except Exception:
                pass
    write_csv(root / "MANIFEST_SHA256.csv", rows)


def main():
    ap = argparse.ArgumentParser(
        description="Section 3.2-3.3: collective-family completion and fixed-sector Floquet"
    )
    ap.add_argument("--root", required=True, help="Output root produced by the first Section-3 script")
    ap.add_argument("--core", required=True, help="Path to 3.1-3.2_CODE_FTLE_and_UPO_search.py")
    ap.add_argument("--target-collective-families", type=int, default=4)
    ap.add_argument("--collective-points", type=int, default=720)
    ap.add_argument("--restricted-rho-min", type=float, default=1.05)
    ap.add_argument("--search-budget-hours", type=float, default=110.0)
    ap.add_argument("--seed", type=int, default=927311)
    args = ap.parse_args()

    if args.target_collective_families != 4:
        raise ValueError("The article design requires exactly four collective families for every N")

    root = Path(args.root).resolve()
    outroot = root / "COLLECTIVE_COMPLETION"

    core = load_module("section3_core", args.core)
    metrics = CollectiveHelpers

    jdump(outroot / "RUN_CONFIG.json", {
        "schema": "SECTION3_COLLECTIVE_COMPLETION_V1",
        "root": str(root),
        "core": str(Path(args.core).resolve()),
        "core_sha256": file_sha256(args.core),
        "target_collective_families_per_N": args.target_collective_families,
        "collective_points": args.collective_points,
        "restricted_rho_min": args.restricted_rho_min,
        "search_budget_hours": args.search_budget_hours,
        "seed": args.seed,
    })

    def on_signal(signum, frame):
        jdump(outroot / "INTERRUPTED.json", {"signal": signum, "time": time.time()})
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, on_signal)
    signal.signal(signal.SIGINT, on_signal)

    reps_by_N = {}
    for N in (2, 4, 6, 8, 10):
        search_dir = outroot / f"N{N}_SEARCH"
        ensure(search_dir)
        try:
            reps = completion_search(core, metrics, root, search_dir, args, N)
        except RuntimeError as exc:
            if "SEARCH_BUDGET_REACHED_SAFE_RESUME" in str(exc):
                print(f"N={N} SEARCH NEEDS SAFE RESUME. Re-submit the identical command.", flush=True)
                return 75
            raise

        if len(reps) != 4:
            raise RuntimeError(f"Expected exactly four final N={N} collective representatives, got {len(reps)}")

        core.set_model(N)
        _, classes, _ = robust_classify(
            core, metrics, reps, search_dir,
            prefix="FINAL_INDEPENDENCE_AUDIT", points=max(1080, args.collective_points)
        )
        if len(classes) != 4 or any(len(c) != 1 for c in classes):
            raise RuntimeError(f"Final N={N} collective independence audit failed: {classes}")
        reps_by_N[N] = reps

    rows = final_floquet_rows(core, metrics, root, reps_by_N, args)
    write_section3_report(root, rows)
    jdump(outroot / "DONE.json", {
        "status": "COMPLETE",
        "n_total_collective_families": 20,
        "families_per_N": 4,
        "fixed_sector_hyperbolic_rho_gt_1p05": int(sum(bool(r["restricted_hyperbolic_rho_gt_1p05"]) for r in rows)),
        "result": str(outroot / "COMPARISON" / "FIXED_SECTOR_FLOQUET_20_COLLECTIVE_FAMILIES.csv"),
    })
    if (outroot / "INTERRUPTED.json").exists():
        (outroot / "INTERRUPTED.json").unlink()
    manifest(outroot)

    print("SECTION 3 COLLECTIVE COMPLETION / FIXED-SECTOR FLOQUET COMPLETE", flush=True)
    print("Result:", outroot / "COMPARISON" / "FIXED_SECTOR_FLOQUET_20_COLLECTIVE_FAMILIES.csv", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
