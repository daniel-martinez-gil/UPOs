#!/usr/bin/env python3
"""
Section 3.1-3.2: same-energy FTLE and initial UPO search
=========================================================

Supplementary-code version extracted from the validated production pipeline
scar_article_final_N246810.py (source SHA256 recorded in README).

This file contains only the calculations needed for Section 3 before the
collective-family completion step:
  * the nonlinear homogeneous TLS model (epsilon = epsilon_i = 0),
  * same-energy sampling and finite-time Lyapunov exponents,
  * Poincare recurrence detection,
  * periodic-orbit refinement and strict reintegration validation,
  * full microscopic Floquet analysis,
  * exact microscopic UPO equivalence under time origin, environmental-TLS
    permutations, and the exact P/T/PT symmetries,
  * selection and storage of four validated microscopic UPO candidates per N.

The later localization, statistical and stationary-state analyses present in
the original production pipeline are intentionally omitted here because they
belong to later manuscript sections. The numerical routines retained below
are copied from the validated production code without changing their
scientific definitions.

Default article parameters:
  N = 2,4,6,8,10
  E/(N+1) = 0.8371173899705596...
  four microscopic exact-symmetry-inequivalent UPO candidates per N

Dependencies: numpy, scipy, matplotlib. CPU only; no pandas.
"""

import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

import argparse
import csv
import hashlib
import json
import math
import platform
import shutil
import signal
import sys
import time
import traceback
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from itertools import product
from pathlib import Path

import numpy as np
import scipy
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from scipy.integrate import solve_ivp
from scipy.optimize import brentq, least_squares, linear_sum_assignment, minimize_scalar
from scipy.spatial import cKDTree
from scipy.stats import wilcoxon, mannwhitneyu, spearmanr


# ============================================================================
# GLOBAL MODEL / NUMERICAL CONSTANTS
# ============================================================================

epsilon = 0.0
delta = 1.0
Ei = 0.0
Di = 1.0
Lambda = 1.0

REFERENCE_N2_ENERGY = 2.511352169911679
REFERENCE_ENERGY_DENSITY = REFERENCE_N2_ENERGY / 3.0
ALPHA = 0.05
MASTER_SEED = 20260923

# These are changed by set_model(N) before every N-specific stage.
N = None
M = None
BLOCH_DIM = None
PHYS_DIM = None

STANDARD_WINDOWS = [(2, 6), (6, 10), (10, 16)]
FINE_WINDOWS = [(2,4), (4,6), (6,8), (8,10), (10,12), (12,14),
                (14,16), (16,18), (18,20)]
PERTURBATION_SCALES = [1e-5, 1e-4, 1e-3]


class CandidateAbort(RuntimeError):
    pass


_INTERRUPTION_FILE = None


def utcnow():
    return datetime.now(timezone.utc).isoformat()


def p(*args):
    print(*args, flush=True)


def set_model(n):
    global N, M, BLOCH_DIM, PHYS_DIM
    N = int(n)
    M = N + 1
    BLOCH_DIM = 3 * M
    PHYS_DIM = 2 * M


def target_energy_for_n(n):
    return REFERENCE_ENERGY_DENSITY * (int(n) + 1)


def ensure_dir(path):
    Path(path).mkdir(parents=True, exist_ok=True)


def _json_sanitize(obj):
    if isinstance(obj, dict):
        return {str(k): _json_sanitize(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_json_sanitize(v) for v in obj]
    if isinstance(obj, np.generic):
        obj = obj.item()
    if isinstance(obj, float) and not np.isfinite(obj):
        return None
    return obj

def write_json(path, obj):
    path = Path(path)
    ensure_dir(path.parent)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(_json_sanitize(obj), f, indent=2, allow_nan=False)
    os.replace(tmp, path)


def read_json(path, default=None):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def stage_marker(outdir, stage):
    return Path(outdir) / f".{stage}.done.json"


def mark_stage(outdir, stage, payload=None):
    data = {"stage": stage, "completed_utc": utcnow()}
    if payload:
        data.update(payload)
    write_json(stage_marker(outdir, stage), data)


def stage_done(outdir, stage):
    return stage_marker(outdir, stage).exists()


def safe_wilcoxon(diff, alternative="greater"):
    diff = np.asarray(diff, dtype=float)
    diff = diff[np.isfinite(diff)]
    if len(diff) == 0 or np.all(np.abs(diff) < 1e-15):
        return 1.0
    try:
        return float(wilcoxon(diff, alternative=alternative, zero_method="wilcox").pvalue)
    except Exception:
        return 1.0


def safe_mannwhitney(x, y, alternative="greater"):
    x = np.asarray(x, float); y = np.asarray(y, float)
    x = x[np.isfinite(x)]; y = y[np.isfinite(y)]
    if len(x) == 0 or len(y) == 0:
        return 1.0
    try:
        return float(mannwhitneyu(x, y, alternative=alternative).pvalue)
    except Exception:
        return 1.0


def bootstrap_mean_ci(values, rng, nboot=2000, level=0.95):
    x = np.asarray(values, float)
    x = x[np.isfinite(x)]
    if len(x) == 0:
        return (np.nan, np.nan, np.nan)
    if len(x) == 1:
        return (float(x[0]), float(x[0]), float(x[0]))
    idx = rng.integers(0, len(x), size=(nboot, len(x)))
    means = x[idx].mean(axis=1)
    a = (1-level)/2
    return (float(np.mean(x)), float(np.quantile(means, a)),
            float(np.quantile(means, 1-a)))


def atomic_csv(path, fieldnames, rows):
    path = Path(path)
    ensure_dir(path.parent)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        for row in rows:
            w.writerow(row)
    os.replace(tmp, path)


def read_csv(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def interruption_handler(signum, frame):
    global _INTERRUPTION_FILE
    try:
        if _INTERRUPTION_FILE:
            write_json(_INTERRUPTION_FILE, {
                "interrupted_utc": utcnow(),
                "signal": int(signum),
                "message": "Safe interruption marker. Re-submit the same command to resume."
            })
    finally:
        raise SystemExit(128 + int(signum))


signal.signal(signal.SIGTERM, interruption_handler)
signal.signal(signal.SIGINT, interruption_handler)


# ============================================================================
# CONFIGURATION -- FINAL N=2,4,6,8,10 ARTICLE RUN
# ============================================================================

SCHEMA_VERSION = "N246810_FINAL_SYMMETRY_V1"
REQUIRED_INDEPENDENT_UPOS_DEFAULT = 4


class SearchIncomplete(RuntimeError):
    """Raised only after all current search work is checkpointed safely."""


def config_for_n(n, quick=False, required_upos=REQUIRED_INDEPENDENT_UPOS_DEFAULT):
    n = int(n)
    if quick:
        return {
            "CHAOS_SAMPLES": 4, "FTLE_TIME": 10.0, "FTLE_CHUNKS": 10,
            "COARSE_TRAJECTORIES_PER_EPOCH": 2, "COARSE_TIME": 90.0, "COARSE_DT": 0.35,
            "T_MIN": 4.0, "T_MAX": 70.0, "COARSE_RADIUS": 1.25,
            "CANDIDATES_PER_TRAJECTORY": 8, "CANDIDATES_PER_EPOCH": 14,
            "MAX_NFEV": 35, "POLISH_NFEV": 20,
            "MAX_RESIDUAL_CALLS": 180, "STAGNATION_CALLS": 80,
            "PERIODIC_TOL": 2e-5, "ENERGY_TOL_ORBIT": 2e-6,
            "MIN_EXCURSION": 0.04, "REQUIRED_INDEPENDENT_UPOS": max(1, min(required_upos,2)),
            "CLEAR_UPO_RHO": 1.05, "SEARCH_BUDGET_HOURS": 0.12,
            "DEDUP_PHASE_POINTS": 180, "DEDUP_VERIFY_POINTS": 24,
            "DEDUP_COARSE_SHIFTS": 36, "DEDUP_PERIOD_REL_TOL": 5e-4,
            "DEDUP_RMS_TOL": 6e-2, "DEDUP_MAX_TOL": 1.8e-1,
            "N_NEAR": 3, "N_GENERIC": 4, "N_PERIODS": 6,
            "POINTS_PER_PERIOD": 20, "PHASE_POINTS": 90,
            "N_SURROGATES": 20, "PERTURBATION_SCALE": 1e-4,
            "ROBUSTNESS_SAMPLES": 2,
            "FLOQUET_DET_TOL": 5e-2, "FLOQUET_RECIP_TOL": 8e-2,
        }

    # Deliberately generous CPU budgets. The search exits only after the required
    # number of symmetry-inequivalent hyperbolic families is reached. If a Slurm
    # wall-time interrupts it, every accepted orbit and every processed candidate
    # is already checkpointed and the exact same command resumes the search.
    table = {
        2: dict(CHAOS_SAMPLES=48, COARSE_TRAJECTORIES_PER_EPOCH=18,
                COARSE_TIME=1700.0, COARSE_DT=0.16, T_MAX=260.0,
                CANDIDATES_PER_EPOCH=180, SEARCH_BUDGET_HOURS=18.0),
        4: dict(CHAOS_SAMPLES=56, COARSE_TRAJECTORIES_PER_EPOCH=22,
                COARSE_TIME=2300.0, COARSE_DT=0.18, T_MAX=320.0,
                CANDIDATES_PER_EPOCH=220, SEARCH_BUDGET_HOURS=24.0),
        6: dict(CHAOS_SAMPLES=64, COARSE_TRAJECTORIES_PER_EPOCH=28,
                COARSE_TIME=3100.0, COARSE_DT=0.20, T_MAX=390.0,
                CANDIDATES_PER_EPOCH=260, SEARCH_BUDGET_HOURS=36.0),
        8: dict(CHAOS_SAMPLES=72, COARSE_TRAJECTORIES_PER_EPOCH=34,
                COARSE_TIME=4100.0, COARSE_DT=0.22, T_MAX=470.0,
                CANDIDATES_PER_EPOCH=320, SEARCH_BUDGET_HOURS=52.0),
        10: dict(CHAOS_SAMPLES=80, COARSE_TRAJECTORIES_PER_EPOCH=42,
                 COARSE_TIME=5200.0, COARSE_DT=0.24, T_MAX=560.0,
                 CANDIDATES_PER_EPOCH=380, SEARCH_BUDGET_HOURS=84.0),
    }
    t = table[n].copy()
    t.update({
        "FTLE_TIME": 140.0, "FTLE_CHUNKS": 140,
        "T_MIN": 5.0, "COARSE_RADIUS": 1.10,
        "CANDIDATES_PER_TRAJECTORY": 55,
        "MAX_NFEV": 320, "POLISH_NFEV": 190,
        "MAX_RESIDUAL_CALLS": 1200 + 50*n,
        "STAGNATION_CALLS": 420 + 20*n,
        "PERIODIC_TOL": 2e-7, "ENERGY_TOL_ORBIT": 2e-8,
        "MIN_EXCURSION": 0.08,
        "REQUIRED_INDEPENDENT_UPOS": int(required_upos),
        "CLEAR_UPO_RHO": 1.05,
        # Equivalence is tested after exact symmetry validation. The period gate
        # is intentionally tight because P/T/permutation/phase copies have the
        # same fundamental period; same-period but geometrically distinct orbits
        # are still retained by the trajectory-distance test.
        "DEDUP_PHASE_POINTS": 720,
        "DEDUP_VERIFY_POINTS": 72,
        "DEDUP_COARSE_SHIFTS": 96,
        "DEDUP_PERIOD_REL_TOL": 1e-4,
        "DEDUP_RMS_TOL": 2.0e-2,
        "DEDUP_MAX_TOL": 6.0e-2,
        "N_NEAR": 24,
        "N_GENERIC": 48,
        "N_PERIODS": 20,
        "POINTS_PER_PERIOD": 60,
        "PHASE_POINTS": 360,
        "N_SURROGATES": 500,
        "PERTURBATION_SCALE": 1e-4,
        "ROBUSTNESS_SAMPLES": 10,
        "FLOQUET_DET_TOL": 2e-2,
        "FLOQUET_RECIP_TOL": 3e-2,
    })
    return t


def classical_energy_bounds(n):
    """Exact classical energy bounds for epsilon=Ei=0, delta=Di=Lambda=1.

    At fixed central z, each environment TLS independently aligns with its
    effective field. The remaining one-dimensional maximization is robust and
    lets us report where the common fixed-density shell sits inside the full
    accessible energy interval for every N.
    """
    n=int(n)
    def emax_at_z(z):
        s=max(0.0,1.0-z*z)**0.5
        return 2*delta*s + n*math.sqrt((2*Di)**2 + (Lambda*z)**2)
    res=minimize_scalar(lambda z:-emax_at_z(z),bounds=(-1.0,1.0),method="bounded",
                        options={"xatol":1e-14})
    emax=float(-res.fun)
    return -emax, emax, float(res.x)


def energy_shell_diagnostics(n,target_energy):
    emin,emax,zstar=classical_energy_bounds(n)
    return {
        "N":int(n), "M":int(n)+1, "target_energy":float(target_energy),
        "energy_density":float(target_energy/(int(n)+1)),
        "Emin":emin, "Emax":emax, "E_over_Emax":float(target_energy/emax),
        "fraction_from_Emin":float((target_energy-emin)/(emax-emin)),
        "z_at_Emax":zstar,
    }

# ============================================================================
# MODEL: ACTION-ANGLE <-> BLOCH, EOM, JACOBIAN, ENERGY
# ============================================================================


def single_bloch(z, phi):
    s = np.sqrt(max(1.0 - z*z, 0.0))
    return np.array([s*np.cos(phi), s*np.sin(phi), z], dtype=float)


def A_to_bloch(A):
    R = list(single_bloch(A[0], A[1]))
    for i in range(N):
        R.extend(single_bloch(A[2+i], A[2+N+i]))
    return np.asarray(R, dtype=float)


def bloch_to_A(R):
    Z = float(R[2]); Phi = float(np.arctan2(R[1], R[0]))
    zs=[]; phis=[]
    for i in range(N):
        j=3+3*i
        zs.append(float(R[j+2]))
        phis.append(float(np.arctan2(R[j+1], R[j])))
    return np.array([Z,Phi,*zs,*phis],float)


def normalize_state(R):
    R=np.asarray(R,float).copy()
    for k in range(M):
        j=3*k; nr=np.linalg.norm(R[j:j+3])
        if nr < 1e-300:
            raise ValueError("zero Bloch vector")
        R[j:j+3] /= nr
    return R


def bloch_rhs(t,R):
    dR=np.zeros_like(R)
    x0,y0,Z=R[:3]
    env_z=np.array([R[3+3*i+2] for i in range(N)])
    Om0=2*epsilon + Lambda*np.sum(env_z)
    dR[0]=-Om0*y0
    dR[1]= Om0*x0 + 2*delta*Z
    dR[2]=-2*delta*y0
    for i in range(N):
        j=3+3*i; x,y,z=R[j:j+3]
        Omi=2*Ei + Lambda*Z
        dR[j]=-Omi*y
        dR[j+1]=Omi*x + 2*Di*z
        dR[j+2]=-2*Di*y
    return dR


def bloch_jacobian(R):
    J=np.zeros((BLOCH_DIM,BLOCH_DIM),float)
    x0,y0,Z=R[:3]
    env_z=np.array([R[3+3*i+2] for i in range(N)])
    Om0=2*epsilon + Lambda*np.sum(env_z)
    J[0,1]=-Om0
    J[1,0]= Om0; J[1,2]=2*delta
    J[2,1]=-2*delta
    for i in range(N):
        zi=3+3*i+2
        J[0,zi]=-Lambda*y0
        J[1,zi]= Lambda*x0
    for i in range(N):
        j=3+3*i; x,y,z=R[j:j+3]
        Omi=2*Ei + Lambda*Z
        J[j,j+1]=-Omi; J[j,2]=-Lambda*y
        J[j+1,j]=Omi; J[j+1,j+2]=2*Di; J[j+1,2]=Lambda*x
        J[j+2,j+1]=-2*Di
    return J


def energy_bloch(R):
    x0,y0,Z=R[:3]
    H=-2*delta*x0 + 2*epsilon*Z
    sz=0.0
    for i in range(N):
        j=3+3*i; x,y,z=R[j:j+3]
        H += -2*Di*x + 2*Ei*z
        sz += z
    H += Lambda*Z*sz
    return float(H)


def energy_A(A):
    return energy_bloch(A_to_bloch(A))


def energy_gradient(R):
    g=np.zeros_like(R); Z=R[2]
    env_z=np.array([R[3+3*i+2] for i in range(N)])
    g[0]=-2*delta; g[2]=2*epsilon + Lambda*np.sum(env_z)
    for i in range(N):
        j=3+3*i
        g[j]=-2*Di
        g[j+2]=2*Ei + Lambda*Z
    return g


def tangent_basis(R):
    B=np.zeros((BLOCH_DIM,PHYS_DIM),float)
    for k in range(M):
        j=3*k; r=R[j:j+3]/np.linalg.norm(R[j:j+3])
        ref=np.array([0.,0.,1.]) if abs(r[2])<0.9 else np.array([1.,0.,0.])
        e1=np.cross(ref,r); e1/=np.linalg.norm(e1)
        e2=np.cross(r,e1); e2/=np.linalg.norm(e2)
        B[j:j+3,2*k]=e1; B[j:j+3,2*k+1]=e2
    return B


def canonical_symplectic_matrix():
    S=np.zeros((PHYS_DIM,PHYS_DIM),float)
    J2=np.array([[0.,1.],[-1.,0.]])
    for k in range(M): S[2*k:2*k+2,2*k:2*k+2]=J2
    return S


# ============================================================================
# SAME-ENERGY SAMPLING
# ============================================================================


def roots_for_Z(zs,phis,target_energy,grid_points=260):
    def f(Z):
        return energy_A(np.array([Z,0.0,*zs,*phis],float))-target_energy
    grid=np.linspace(-0.99,0.99,grid_points)
    vals=np.array([f(z) for z in grid])
    roots=[]
    for k in range(len(grid)-1):
        a,b=grid[k],grid[k+1]; fa,fb=vals[k],vals[k+1]
        if not np.isfinite(fa+fb): continue
        if abs(fa)<1e-11: roots.append(a)
        if fa*fb<0:
            try: roots.append(brentq(f,a,b,xtol=1e-13,rtol=1e-13))
            except Exception: pass
    uniq=[]
    for r in roots:
        if all(abs(r-u)>1e-7 for u in uniq): uniq.append(r)
    return uniq


def random_same_energy_A(rng,target_energy,max_attempts=4000):
    for _ in range(max_attempts):
        zs=rng.uniform(-0.95,0.95,N)
        phis=rng.uniform(-np.pi,np.pi,N)
        roots=roots_for_Z(zs,phis,target_energy)
        if roots:
            Z=roots[int(rng.integers(len(roots)))]
            A=np.array([Z,0.0,*zs,*phis],float)
            if abs(energy_A(A)-target_energy)<2e-9:
                return A
    raise RuntimeError("could not sample requested energy shell")


# ============================================================================
# INTEGRATION / FTLE / ENERGY DRIFT
# ============================================================================


def integrate_final(R0,T,rtol=2e-10,atol=1e-11):
    sol=solve_ivp(bloch_rhs,(0,float(T)),R0,method="DOP853",rtol=rtol,atol=atol)
    return sol.y[:,-1] if sol.success else None


def integrate_grid(R0,total_time,nt,rtol=2e-9,atol=1e-11):
    tt=np.linspace(0,float(total_time),int(nt))
    sol=solve_ivp(bloch_rhs,(0,float(total_time)),R0,method="DOP853",
                  t_eval=tt,rtol=rtol,atol=atol)
    if not sol.success: raise RuntimeError(sol.message)
    return sol.t,sol.y.T


def energy_drift(traj):
    Es=np.array([energy_bloch(r) for r in traj])
    return float(np.max(np.abs(Es-Es[0]))), float(Es[0]), float(Es[-1])


def ftle_one_vector(R0,rng,total_time,chunks):
    B=tangent_basis(R0)
    v=B@ (lambda q:q/np.linalg.norm(q))(rng.normal(size=PHYS_DIM))
    R=R0.copy(); acc=0.0; dt=total_time/chunks
    def rhs(t,Y):
        rr=Y[:BLOCH_DIM]; vv=Y[BLOCH_DIM:]
        return np.concatenate([bloch_rhs(t,rr),bloch_jacobian(rr)@vv])
    for _ in range(chunks):
        sol=solve_ivp(rhs,(0,dt),np.concatenate([R,v]),method="DOP853",
                      rtol=2e-9,atol=1e-11)
        if not sol.success: return np.nan
        yf=sol.y[:,-1]; R=normalize_state(yf[:BLOCH_DIM]); v=yf[BLOCH_DIM:]
        for k in range(M):
            j=3*k; r=R[j:j+3]
            v[j:j+3]-=np.dot(v[j:j+3],r)*r
        nv=np.linalg.norm(v)
        if nv<1e-300: return -np.inf
        acc += np.log(nv); v/=nv
    return float(acc/total_time)


# ============================================================================
# FLOQUET -- canonical cross-check + Bloch fallback
# ============================================================================


def variational_rhs(t,Y):
    R=Y[:BLOCH_DIM]
    MM=Y[BLOCH_DIM:].reshape(BLOCH_DIM,BLOCH_DIM)
    return np.concatenate([bloch_rhs(t,R),(bloch_jacobian(R)@MM).ravel()])


def _canonical_from_bloch(R):
    u=np.empty(PHYS_DIM,float)
    for k in range(M):
        j=3*k
        u[2*k]=float(np.clip(R[j+2],-0.999999999999,0.999999999999))
        u[2*k+1]=float(np.arctan2(R[j+1],R[j]))
    return u


def _bloch_from_canonical(u):
    R=np.empty(BLOCH_DIM,float)
    for k in range(M):
        z=float(u[2*k]); ph=float(u[2*k+1]); s=math.sqrt(max(0.0,1-z*z))
        R[3*k:3*k+3]=(s*math.cos(ph),s*math.sin(ph),z)
    return R


def _canonical_rhs(t,u):
    du=np.zeros_like(u)
    Z,Phi=u[0],u[1]
    envz=np.array([u[2*(i+1)] for i in range(N)])
    s0=math.sqrt(max(1e-20,1-Z*Z))
    du[0]=-2*delta*s0*math.sin(Phi)
    du[1]=2*epsilon + 2*delta*(Z/s0)*math.cos(Phi) + Lambda*np.sum(envz)
    for i in range(N):
        k=2*(i+1); z,ph=u[k],u[k+1]; s=math.sqrt(max(1e-20,1-z*z))
        du[k]=-2*Di*s*math.sin(ph)
        du[k+1]=2*Ei + 2*Di*(z/s)*math.cos(ph) + Lambda*Z
    return du


def _canonical_jacobian(u):
    J=np.zeros((PHYS_DIM,PHYS_DIM),float)
    Z,Phi=u[0],u[1]; s0=math.sqrt(max(1e-20,1-Z*Z))
    J[0,0]=2*delta*(Z/s0)*math.sin(Phi)
    J[0,1]=-2*delta*s0*math.cos(Phi)
    J[1,0]=2*delta*math.cos(Phi)/(s0**3)
    J[1,1]=-2*delta*(Z/s0)*math.sin(Phi)
    for i in range(N):
        k=2*(i+1)
        J[1,k]=Lambda
        z,ph=u[k],u[k+1]; s=math.sqrt(max(1e-20,1-z*z))
        J[k,k]=2*Di*(z/s)*math.sin(ph)
        J[k,k+1]=-2*Di*s*math.cos(ph)
        J[k+1,k]=2*Di*math.cos(ph)/(s**3)
        J[k+1,k+1]=-2*Di*(z/s)*math.sin(ph)
        J[k+1,0]=Lambda
    return J


def _canonical_variational_rhs(t,Y):
    u=Y[:PHYS_DIM]; MM=Y[PHYS_DIM:].reshape(PHYS_DIM,PHYS_DIM)
    return np.concatenate([_canonical_rhs(t,u),(_canonical_jacobian(u)@MM).ravel()])


def reciprocal_pair_error(eigvals):
    a=np.abs(np.asarray(eigvals,complex)); a=a[np.isfinite(a)&(a>1e-300)]
    if len(a)<2:return np.nan
    logs=np.sort(np.log(a))
    return float(np.max(np.abs(logs + logs[::-1])))


def _floquet_bloch_fallback(R0,T):
    Y0=np.concatenate([R0,np.eye(BLOCH_DIM).ravel()])
    sol=solve_ivp(variational_rhs,(0,float(T)),Y0,method="DOP853",rtol=3e-11,atol=3e-13)
    if not sol.success:return None
    yf=sol.y[:,-1]; Rf=yf[:BLOCH_DIM]; MF=yf[BLOCH_DIM:].reshape(BLOCH_DIM,BLOCH_DIM)
    B=tangent_basis(R0); MP=B.T@MF@B
    eig=np.linalg.eigvals(MP); eig=eig[np.argsort(np.abs(eig))[::-1]]
    rho=float(np.max(np.abs(eig))); lam=float(np.log(max(rho,1e-300))/T)
    return {"return_D":float(np.linalg.norm(Rf-R0)),"rho":rho,"lambda":lam,
            "det":float(np.linalg.det(MP)),"symplectic_error":np.nan,
            "reciprocal_pair_error":reciprocal_pair_error(eig),"eigvals":eig,
            "Mphys":MP,"floquet_method":"bloch_tangent_fallback"}


def floquet_analysis(R0,T):
    """Primary Floquet calculation in true canonical (z,phi) coordinates.

    This avoids interpreting an arbitrary orthonormal Bloch tangent basis as a
    canonical one. If an orbit approaches a Bloch pole too closely, where the
    (z,phi) chart is singular, a constrained-Bloch tangent calculation is used
    as a documented fallback. Reciprocal-pair error is always reported.
    """
    try:
        # Ensure the canonical chart stays sufficiently far from singular poles.
        tt,tr=integrate_grid(R0,float(T),240,rtol=2e-10,atol=2e-12)
        pole_margin=float(np.min(1.0-np.abs(tr[:,2::3])))
        if pole_margin < 2e-7:
            raise FloatingPointError(f"canonical chart pole margin={pole_margin:.2e}")
        u0=_canonical_from_bloch(R0)
        Y0=np.concatenate([u0,np.eye(PHYS_DIM).ravel()])
        sol=solve_ivp(_canonical_variational_rhs,(0,float(T)),Y0,method="DOP853",
                      rtol=2e-11,atol=2e-13)
        if not sol.success:raise RuntimeError(sol.message)
        uf=sol.y[:PHYS_DIM,-1]; MC=sol.y[PHYS_DIM:,-1].reshape(PHYS_DIM,PHYS_DIM)
        eig=np.linalg.eigvals(MC); eig=eig[np.argsort(np.abs(eig))[::-1]]
        rho=float(np.max(np.abs(eig))); lam=float(np.log(max(rho,1e-300))/T)
        S=canonical_symplectic_matrix()
        Rf=_bloch_from_canonical(uf)
        return {"return_D":float(np.linalg.norm(Rf-R0)),"rho":rho,"lambda":lam,
                "det":float(np.linalg.det(MC)),
                "symplectic_error":float(np.max(np.abs(MC.T@S@MC-S))),
                "reciprocal_pair_error":reciprocal_pair_error(eig),"eigvals":eig,
                "Mphys":MC,"floquet_method":"canonical_action_angle",
                "canonical_pole_margin":pole_margin}
    except Exception as exc:
        out=_floquet_bloch_fallback(R0,T)
        if out is not None:
            out["canonical_failure"]=str(exc)
            out["canonical_pole_margin"]=np.nan
        return out

# ============================================================================
# CHAOS STAGE
# ============================================================================


def stage_chaos(cfg,target_energy,outdir,rng):
    if stage_done(outdir,"chaos"):
        p(f"N={N} chaos: checkpoint exists; skipping")
        return read_json(Path(outdir)/"chaos_summary.json",{})
    p(f"\n===== N={N}: CHAOS / FTLE =====")
    rows=[]; t0=time.perf_counter()
    for k in range(cfg["CHAOS_SAMPLES"]):
        try:
            A=random_same_energy_A(rng,target_energy); R=A_to_bloch(A)
            lam=ftle_one_vector(R,rng,cfg["FTLE_TIME"],cfg["FTLE_CHUNKS"])
            _,tr=integrate_grid(R,min(cfg["FTLE_TIME"],30.0),120,rtol=3e-9,atol=2e-11)
            drift,_,_=energy_drift(tr)
            rows.append({"sample":k,"ftle":lam,"energy_drift":drift,"A":A.tolist()})
            p(f"N={N} FTLE {k+1}/{cfg['CHAOS_SAMPLES']}: {lam:+.5e}, drift={drift:.2e}, elapsed={time.perf_counter()-t0:.1f}s")
        except Exception as exc:
            p(f"WARNING FTLE sample {k} skipped: {exc}")
    finite=np.array([r["ftle"] for r in rows if np.isfinite(r["ftle"])])
    summary={
        "N":N,"target_energy":target_energy,"energy_density":target_energy/M,
        "n_samples":len(rows),"mean_ftle":float(np.mean(finite)) if len(finite) else None,
        "median_ftle":float(np.median(finite)) if len(finite) else None,
        "max_ftle":float(np.max(finite)) if len(finite) else None,
        "fraction_positive":float(np.mean(finite>1e-4)) if len(finite) else None,
        "max_energy_drift":float(max([r["energy_drift"] for r in rows],default=np.nan)),
    }
    write_json(Path(outdir)/"chaos_summary.json",summary)
    fields=["sample","ftle","energy_drift","Z0","Phi0"]+[f"z{i+1}_0" for i in range(N)]+[f"phi{i+1}_0" for i in range(N)]
    table=[]
    for r in rows:
        A=r["A"]; row={"sample":r["sample"],"ftle":r["ftle"],"energy_drift":r["energy_drift"],"Z0":A[0],"Phi0":A[1]}
        for i in range(N): row[f"z{i+1}_0"]=A[2+i]; row[f"phi{i+1}_0"]=A[2+N+i]
        table.append(row)
    atomic_csv(Path(outdir)/"chaos_ftle.csv",fields,table)
    if len(finite):
        plt.figure(figsize=(7,5)); plt.hist(finite,bins=min(18,max(6,len(finite)//3))); plt.axvline(0,ls="--")
        plt.xlabel("Finite-time Lyapunov exponent"); plt.ylabel("Count"); plt.title(f"N={N} same-shell FTLE")
        plt.tight_layout(); plt.savefig(Path(outdir)/"ftle_histogram.png",dpi=300); plt.close()
    mark_stage(outdir,"chaos",summary)
    return summary

# ============================================================================
# POINCARE RECURRENCE SEARCH / REFINEMENT
# ============================================================================


def integrate_dense(R0,total_time,dt,rtol=2e-8,atol=1e-10):
    nt=int(np.floor(total_time/dt))+1
    tt=np.linspace(0,total_time,nt)
    sol=solve_ivp(bloch_rhs,(0,total_time),R0,method="DOP853",t_eval=tt,rtol=rtol,atol=atol)
    if not sol.success: raise RuntimeError(sol.message)
    return sol.t,sol.y.T


def section_state_exact_energy(Rinterp,target_energy):
    Rinterp=normalize_state(Rinterp)
    zs=[]; phis=[]
    for i in range(N):
        j=3+3*i; zs.append(float(Rinterp[j+2])); phis.append(float(np.arctan2(Rinterp[j+1],Rinterp[j])))
    roots=roots_for_Z(np.asarray(zs),np.asarray(phis),target_energy)
    if not roots: return None
    Z=min(roots,key=lambda z:abs(z-Rinterp[2]))
    A=np.array([Z,0.0,*zs,*phis],float)
    return A,A_to_bloch(A)


def extract_poincare_section(times,traj,target_energy):
    sec=[]; y=traj[:,1]
    for k in range(len(times)-1):
        if y[k] <= 0.0 < y[k+1]:
            dy=y[k+1]-y[k]; a=0 if abs(dy)<1e-15 else -y[k]/dy; a=float(np.clip(a,0,1))
            R=normalize_state((1-a)*traj[k]+a*traj[k+1]); t=(1-a)*times[k]+a*times[k+1]
            if R[0] <= 0: continue
            ex=section_state_exact_energy(R,target_energy)
            if ex is not None:
                A,RR=ex; sec.append({"t":float(t),"A":A,"R":RR})
    return sec


def recurrence_candidates_from_section(section,cfg):
    if len(section)<3: return []
    X=np.array([s["R"] for s in section]); ts=np.array([s["t"] for s in section]); tree=cKDTree(X)
    out=[]
    for i in range(len(section)):
        for j in tree.query_ball_point(X[i],r=cfg["COARSE_RADIUS"]):
            if j<=i: continue
            T=ts[j]-ts[i]
            if not(cfg["T_MIN"]<=T<=cfg["T_MAX"]): continue
            out.append({"A":section[i]["A"].copy(),"T":float(T),"D":float(np.linalg.norm(X[j]-X[i]))})
    out.sort(key=lambda c:c["D"])
    return out[:cfg["CANDIDATES_PER_TRAJECTORY"]]


def orbit_excursion(R0,T):
    try:
        _,tr=integrate_grid(R0,T,500,rtol=3e-10,atol=2e-11)
        return float(np.max(np.linalg.norm(tr-R0,axis=1)))
    except Exception: return np.nan


def reduce_period(R0,T,cfg):
    best=float(T)
    for q in range(2,13):
        t=T/q
        if t<cfg["T_MIN"]: continue
        Rf=integrate_final(R0,t,rtol=5e-10,atol=2e-11)
        if Rf is not None and np.linalg.norm(Rf-R0)<5*cfg["PERIODIC_TOL"]: best=min(best,t)
    return best


def params_to_A(x):
    return np.array([x[0],0.0,*x[1:1+N],*x[1+N:1+2*N]],float)


def candidate_to_x(c):
    A=c["A"]
    return np.array([A[0],*A[2:2+N],*A[2+N:2+2*N],c["T"]],float)


def recurrence_residual_factory(target_energy,cfg,print_every=100,rtol=4e-9,atol=2e-10):
    state={"calls":0,"best":np.inf,"last_improve":0}
    def residual(x):
        state["calls"]+=1
        if state["calls"]>cfg["MAX_RESIDUAL_CALLS"]:
            raise CandidateAbort("hard residual-call limit")
        A=params_to_A(x[:-1]); T=float(x[-1]); R0=A_to_bloch(A)
        Rf=integrate_final(R0,T,rtol=rtol,atol=atol)
        if Rf is None: return np.ones(BLOCH_DIM+1)*100
        rec=Rf-R0; dE=energy_bloch(R0)-target_energy
        score=float(np.linalg.norm(rec)+5*abs(dE))
        if score < state["best"]*0.995:
            state["best"]=score; state["last_improve"]=state["calls"]
        if state["calls"]>600 and state["calls"]-state["last_improve"]>cfg["STAGNATION_CALLS"] and state["best"]>5e-3:
            raise CandidateAbort(f"stagnation (best score {state['best']:.3e})")
        if state["calls"]%print_every==0:
            p(f"      eval {state['calls']:5d}: D={np.linalg.norm(rec):.3e}, dE={dE:+.2e}, T={T:.6f}")
        return np.concatenate([rec,[dE]])
    residual.state=state
    return residual


def orbit_to_row(idx,o):
    row={"orbit":idx,"T":o["T"],"return_D":o["return_D"],"energy":o["energy"],"energy_error":o["energy_error"],
         "excursion":o["excursion"],"max_mu":o["rho"],"floquet_lambda":o["lambda"],
         "lambda_over_omega":o["lambda"]/(2*np.pi/o["T"]),"det_M":o["det"],"symplectic_error":o.get("symplectic_error",np.nan),
         "reciprocal_pair_error":o.get("reciprocal_pair_error",np.nan),"floquet_method":o.get("floquet_method","unknown"),
         "canonical_pole_margin":o.get("canonical_pole_margin",np.nan),"source":o.get("source","search"),"Z0":o["A"][0]}
    for i in range(N): row[f"z{i+1}_0"]=o["A"][2+i]; row[f"phi{i+1}_0"]=o["A"][2+N+i]
    eig=np.asarray(o.get("eigvals",[]),complex)
    for k in range(PHYS_DIM):
        mu=eig[k] if k<len(eig) else np.nan+1j*np.nan
        row[f"mu{k+1}_real"]=float(np.real(mu)); row[f"mu{k+1}_imag"]=float(np.imag(mu))
    return row


def orbit_fields():
    return (["orbit","T","return_D","energy","energy_error","excursion","max_mu","floquet_lambda","lambda_over_omega","det_M","symplectic_error","reciprocal_pair_error","floquet_method","canonical_pole_margin","source","Z0"]+
            [f"z{i+1}_0" for i in range(N)]+[f"phi{i+1}_0" for i in range(N)]+
            [f"mu{k+1}_real" for k in range(PHYS_DIM)]+[f"mu{k+1}_imag" for k in range(PHYS_DIM)])


def save_orbits(path,orbits):
    atomic_csv(path,orbit_fields(),[orbit_to_row(i,o) for i,o in enumerate(orbits)])


def row_to_orbit(row):
    A=np.array([float(row["Z0"]),0.0]+[float(row[f"z{i+1}_0"]) for i in range(N)]+[float(row[f"phi{i+1}_0"]) for i in range(N)],float)
    eig=[]
    for k in range(PHYS_DIM):
        rk=f"mu{k+1}_real"; ik=f"mu{k+1}_imag"
        if rk in row and row[rk] not in (None,""):
            try:eig.append(complex(float(row[rk]),float(row[ik])))
            except Exception:pass
    return {"A":A,"R0":A_to_bloch(A),"T":float(row["T"]),"return_D":float(row.get("return_D",np.nan)),
            "energy":float(row.get("energy",np.nan)),"energy_error":float(row.get("energy_error",np.nan)),
            "excursion":float(row.get("excursion",np.nan)),"rho":float(row.get("max_mu",np.nan)),
            "lambda":float(row.get("floquet_lambda",np.nan)),"det":float(row.get("det_M",np.nan)),
            "symplectic_error":float(row.get("symplectic_error",np.nan) or np.nan),
            "reciprocal_pair_error":float(row.get("reciprocal_pair_error",np.nan) or np.nan),
            "floquet_method":row.get("floquet_method","legacy"),"canonical_pole_margin":float(row.get("canonical_pole_margin",np.nan) or np.nan),
            "eigvals":np.array(eig),"source":row.get("source","csv")}


def load_orbits(path):
    return [row_to_orbit(r) for r in read_csv(path)]


# ============================================================================
# EXACT-SYMMETRY UPO EQUIVALENCE / DEDUPLICATION
# ============================================================================

# Exact discrete symmetry family for epsilon=Ei=0 and identical environment TLSs:
#   I  : R(t)
#   P  : (x,y,z)->(x,-y,-z), forward time
#   T  : (x,y,z)(t)->(x,-y,z)(-t)
#   PT : (x,y,z)(t)->(x,y,-z)(-t)
# plus any fixed permutation of environment TLS labels and any phase origin.
SYMMETRY_NAMES=("I","P","T","PT")


def _apply_value_symmetry(arr,name):
    a=np.asarray(arr,float).copy()
    shp=a.shape; b=a.reshape((-1,M,3))
    if name=="P":
        b[:,:,1]*=-1; b[:,:,2]*=-1
    elif name=="T":
        b[:,:,1]*=-1
    elif name=="PT":
        b[:,:,2]*=-1
    elif name!="I":
        raise ValueError(name)
    return b.reshape(shp)


def _symmetry_direction(name):
    return -1.0 if name in ("T","PT") else 1.0


def _permute_environment(arr,perm):
    a=np.asarray(arr,float); out=a.copy(); flat=out.reshape((-1,M,3)); src=a.reshape((-1,M,3))
    flat[:,0,:]=src[:,0,:]
    for i,j in enumerate(np.asarray(perm,int)):
        flat[:,i+1,:]=src[:,j+1,:]
    return out


def _permute_state(R,perm):
    return _permute_environment(np.asarray(R,float)[None,:],perm)[0]


def validate_exact_symmetries(outdir,rng,ntrials=10):
    rows=[]; worst=0.0
    for q in range(ntrials):
        R=np.concatenate([rng.normal(size=3) for _ in range(M)]).astype(float)
        R=normalize_state(R); F=bloch_rhs(0,R); E=energy_bloch(R)
        for name in SYMMETRY_NAMES:
            S=_apply_value_symmetry(R,name); FS=bloch_rhs(0,S)
            if name in ("I","P"):
                rhs_expected=_apply_value_symmetry(F,name)
            else:
                rhs_expected=-_apply_value_symmetry(F,name)
            err=float(np.max(np.abs(FS-rhs_expected)))
            eerr=abs(energy_bloch(S)-E); worst=max(worst,err,eerr)
            rows.append({"trial":q,"symmetry":name,"rhs_covariance_error":err,"energy_error":eerr})
        perm=rng.permutation(N); Rp=_permute_state(R,perm); Fp=bloch_rhs(0,Rp)
        expected=_permute_state(F,perm); err=float(np.max(np.abs(Fp-expected))); eerr=abs(energy_bloch(Rp)-E)
        worst=max(worst,err,eerr); rows.append({"trial":q,"symmetry":"ENV_PERM","rhs_covariance_error":err,"energy_error":eerr})
    atomic_csv(Path(outdir)/"exact_symmetry_selftest.csv",["trial","symmetry","rhs_covariance_error","energy_error"],rows)
    write_json(Path(outdir)/"exact_symmetry_selftest.json",{"worst_error":worst,"ntrials":ntrials,"symmetries":list(SYMMETRY_NAMES)+["ENV_PERM"]})
    if worst>5e-10:
        raise RuntimeError(f"Exact-symmetry self-test failed: worst error {worst:.3e}")
    return worst


def phase_grid(orbit,points):
    key=f"phase_{points}"
    if key in orbit:return orbit[key]
    tt=np.linspace(0,orbit["T"],points,endpoint=False)
    sol=solve_ivp(bloch_rhs,(0,orbit["T"]),orbit["R0"],method="DOP853",t_eval=tt,rtol=2e-10,atol=2e-12)
    if not sol.success:raise RuntimeError(sol.message)
    orbit[key]=sol.y.T
    return orbit[key]


def _periodic_interp(traj,phases):
    traj=np.asarray(traj,float); K=len(traj); x=(np.asarray(phases,float)%1.0)*K
    i0=np.floor(x).astype(int)%K; f=x-np.floor(x); i1=(i0+1)%K
    out=(1-f)[:,None]*traj[i0]+f[:,None]*traj[i1]
    # Linear interpolation leaves each Bloch sphere slightly inside the unit
    # sphere; normalize only for distance evaluation.
    for k in range(M):
        j=3*k; nr=np.linalg.norm(out[:,j:j+3],axis=1); out[:,j:j+3]/=nr[:,None]
    return out


def _alignment_at_shift(ta,tb,shift,sym,verify_phases):
    A=_periodic_interp(ta,verify_phases)
    phases=(shift+_symmetry_direction(sym)*verify_phases)%1.0
    B=_apply_value_symmetry(_periodic_interp(tb,phases),sym)
    ea=A[:,3:].reshape(len(A),N,3); eb=B[:,3:].reshape(len(B),N,3)
    cost=np.mean(np.sum((ea[:,:,None,:]-eb[:,None,:,:])**2,axis=3),axis=0)
    rr,cc=linear_sum_assignment(cost); perm=np.empty(N,dtype=int); perm[rr]=cc
    sys2=np.sum((A[:,:3]-B[:,:3])**2,axis=1)
    env2=np.sum((ea-eb[:,perm,:])**2,axis=(1,2))
    per_time=np.sqrt((sys2+env2)/M)
    return float(np.sqrt(np.mean(per_time**2))),float(np.max(per_time)),perm


def best_family_alignment(a,b,cfg,require_same_period=True):
    rel=abs(a["T"]-b["T"])/min(a["T"],b["T"])
    if require_same_period and rel>cfg["DEDUP_PERIOD_REL_TOL"]:
        return {"equivalent":False,"period_rel_diff":rel,"trajectory_rms":np.nan,"trajectory_max":np.nan,
                "shift_phase":np.nan,"perm":"","symmetry":"PERIOD_MISMATCH","rho_rel_diff":np.nan}
    K=cfg["DEDUP_PHASE_POINTS"]; ta=phase_grid(a,K); tb=phase_grid(b,K)
    V=cfg["DEDUP_VERIFY_POINTS"]; verify=np.linspace(0,1,V,endpoint=False)
    coarse=cfg["DEDUP_COARSE_SHIFTS"]; step=1.0/coarse
    best=(np.inf,np.inf,None,None,None)
    for sym in SYMMETRY_NAMES:
        scores=[]
        for s in range(coarse):
            u=s/coarse; rms,mx,perm=_alignment_at_shift(ta,tb,u,sym,verify); scores.append((rms,mx,u,perm))
        # Refine the three best coarse phase origins continuously.
        for rms0,mx0,u0,perm0 in sorted(scores,key=lambda x:x[0])[:3]:
            def obj(dx):
                return _alignment_at_shift(ta,tb,(u0+dx)%1.0,sym,verify)[0]
            try:
                res=minimize_scalar(obj,bounds=(-step,step),method="bounded",options={"xatol":2e-7})
                u=(u0+float(res.x))%1.0; rms,mx,perm=_alignment_at_shift(ta,tb,u,sym,verify)
            except Exception:
                u=u0; rms,mx,perm=rms0,mx0,perm0
            if rms<best[0]:best=(rms,mx,u,perm,sym)
    rms,mx,u,perm,sym=best
    rho_rel=abs(a.get("rho",np.nan)-b.get("rho",np.nan))/max(1.0,abs(a.get("rho",1.0)),abs(b.get("rho",1.0)))
    eq=bool((not require_same_period or rel<=cfg["DEDUP_PERIOD_REL_TOL"]) and
            rms<cfg["DEDUP_RMS_TOL"] and mx<cfg["DEDUP_MAX_TOL"])
    return {"equivalent":eq,"period_rel_diff":rel,"trajectory_rms":rms,"trajectory_max":mx,
            "shift_phase":u,"perm":" ".join(map(str,perm.tolist())),"symmetry":sym,"rho_rel_diff":rho_rel}


def orbit_equivalence(a,b,cfg):
    return best_family_alignment(a,b,cfg,require_same_period=True)


def deduplicate_orbits(orbits,cfg,outdir,label="clear"):
    L=len(orbits); parent=list(range(L))
    def find(x):
        while parent[x]!=x:
            parent[x]=parent[parent[x]]; x=parent[x]
        return x
    def union(a,b):
        ra,rb=find(a),find(b)
        if ra!=rb:parent[rb]=ra
    pairrows=[]
    for i in range(L):
        for j in range(i+1,L):
            try:info=orbit_equivalence(orbits[i],orbits[j],cfg)
            except Exception as exc:
                info={"equivalent":False,"period_rel_diff":np.nan,"trajectory_rms":np.nan,"trajectory_max":np.nan,
                      "shift_phase":np.nan,"perm":"","symmetry":"ERROR","rho_rel_diff":np.nan,"error":str(exc)}
            pairrows.append({"i":i,"j":j,**info})
            if info["equivalent"]:union(i,j)
    groups=defaultdict(list)
    for i in range(L):groups[find(i)].append(i)
    comps=sorted(groups.values(),key=min); reps=[]; membership=[]
    for cid,ids in enumerate(comps):
        members=[orbits[i] for i in ids]
        rep=min(members,key=lambda o:(o.get("return_D",np.inf),o.get("reciprocal_pair_error",np.inf),-o.get("rho",1.0)))
        reps.append(rep)
        for i in ids:
            o=orbits[i]; membership.append({"class_id":cid,"member_index":i,"is_representative":bool(o is rep),
                "T":o["T"],"rho":o["rho"],"return_D":o["return_D"],"source":o.get("source","")})
    pf=["i","j","equivalent","period_rel_diff","trajectory_rms","trajectory_max","shift_phase","perm","symmetry","rho_rel_diff","error"]
    atomic_csv(Path(outdir)/f"{label}_orbit_equivalence_pairs.csv",pf,pairrows)
    atomic_csv(Path(outdir)/f"{label}_orbit_classes.csv",["class_id","member_index","is_representative","T","rho","return_D","source"],membership)
    return reps,[[orbits[i] for i in ids] for ids in comps]


def validate_orbit(o,target_energy,cfg):
    R0=normalize_state(o["R0"]); T=reduce_period(R0,o["T"],cfg)
    Rf=integrate_final(R0,T,rtol=5e-12,atol=5e-13)
    if Rf is None:return None
    D=float(np.linalg.norm(Rf-R0)); E=energy_bloch(R0); dE=E-target_energy; exc=orbit_excursion(R0,T)
    if D>max(8*cfg["PERIODIC_TOL"],2e-6) or abs(dE)>max(8*cfg["ENERGY_TOL_ORBIT"],2e-7) or not np.isfinite(exc) or exc<cfg["MIN_EXCURSION"]:
        return None
    F=floquet_analysis(R0,T)
    if F is None:return None
    if not np.isfinite(F["rho"]) or not np.isfinite(F["det"]):return None
    # Numerical Hamiltonian sanity checks. These thresholds are validation
    # guards, not definitions of hyperbolicity.
    deterr=abs(math.log(max(abs(F["det"]),1e-300)))
    rerr=F.get("reciprocal_pair_error",np.nan)
    if deterr>cfg["FLOQUET_DET_TOL"] or (np.isfinite(rerr) and rerr>cfg["FLOQUET_RECIP_TOL"]):
        return None
    oo=dict(o); oo["R0"]=R0; oo["A"]=bloch_to_A(R0); oo.update(F)
    oo.update({"T":T,"return_D":D,"energy":E,"energy_error":dE,"excursion":exc})
    return oo


def import_legacy_clear(legacy_path,target_energy,cfg,outdir):
    if not legacy_path or not Path(legacy_path).exists(): return []
    p(f"N={N}: importing legacy clear-UPO candidates from {legacy_path}")
    try: rows=read_csv(legacy_path)
    except Exception as exc:
        p("legacy import failed:",exc); return []
    candidates=[]
    for row in rows:
        try:
            if float(row.get("max_mu",0))<cfg["CLEAR_UPO_RHO"]: continue
            o=row_to_orbit(row); o["source"]=f"legacy:{legacy_path}"
            v=validate_orbit(o,target_energy,cfg)
            if v is not None:
                candidates.append(v); p(f"  validated T={v['T']:.6f}, rho={v['rho']:.6f}, D={v['return_D']:.2e}")
            else: p(f"  rejected legacy T={o['T']:.6f}: failed current validation")
        except Exception as exc: p("  legacy row skipped:",exc)
    save_orbits(Path(outdir)/"legacy_validated_clear_upos.csv",candidates)
    return candidates


def checkpoint_candidates(path,candidates):
    fields=["rank","D","T","Z0"]+[f"z{i+1}_0" for i in range(N)]+[f"phi{i+1}_0" for i in range(N)]
    rows=[]
    for k,c in enumerate(candidates):
        A=c["A"]; r={"rank":k,"D":c["D"],"T":c["T"],"Z0":A[0]}
        for i in range(N): r[f"z{i+1}_0"]=A[2+i]; r[f"phi{i+1}_0"]=A[2+N+i]
        rows.append(r)
    atomic_csv(path,fields,rows)


def _candidate_hash(c):
    A=np.asarray(c["A"],float)
    vals=np.concatenate([np.round(A,7),[round(float(c["T"]),6)]])
    return hashlib.sha1(vals.tobytes()).hexdigest()[:20]


def _load_candidate_file(path):
    out=[]
    for row in read_csv(path):
        A=np.array([float(row["Z0"]),0.0]+[float(row[f"z{i+1}_0"]) for i in range(N)]+[float(row[f"phi{i+1}_0"]) for i in range(N)],float)
        out.append({"A":A,"T":float(row["T"]),"D":float(row["D"])})
    return out


def _diversify_candidates(cands,cfg):
    # Prevent the smallest-return candidates from a single orbit/period family
    # monopolising an epoch. Keep several candidates per period bin, then fill
    # remaining slots globally by recurrence distance.
    cands=sorted(cands,key=lambda c:c["D"]); out=[]; perbin=defaultdict(int)
    width=max(3.0,0.025*cfg["T_MAX"]); cap=4
    used=set()
    for c in cands:
        b=int(c["T"]//width)
        if perbin[b]>=cap:continue
        h=_candidate_hash(c)
        if h in used:continue
        out.append(c); used.add(h); perbin[b]+=1
        if len(out)>=cfg["CANDIDATES_PER_EPOCH"]:return out
    for c in cands:
        h=_candidate_hash(c)
        if h not in used:
            out.append(c); used.add(h)
            if len(out)>=cfg["CANDIDATES_PER_EPOCH"]:break
    return out


def _epoch_local_cfg(cfg,epoch):
    c=dict(cfg); mode=epoch%4
    # Sweep short, medium, long and full-period recurrence windows repeatedly.
    if mode==0:c["T_MIN"],c["T_MAX"]=cfg["T_MIN"],min(cfg["T_MAX"],90+12*N)
    elif mode==1:c["T_MIN"],c["T_MAX"]=max(cfg["T_MIN"],40.0),min(cfg["T_MAX"],210+12*N)
    elif mode==2:c["T_MIN"],c["T_MAX"]=max(cfg["T_MIN"],100.0),cfg["T_MAX"]
    else:c["T_MIN"],c["T_MAX"]=cfg["T_MIN"],cfg["T_MAX"]
    c["COARSE_RADIUS"]=cfg["COARSE_RADIUS"]*[0.85,1.0,1.15,1.30][mode]
    return c


def _generate_epoch_candidates(cfg,target_energy,outdir,epoch,master_seed):
    path=Path(outdir)/f"search_epoch_{epoch:03d}_candidates.csv"
    if path.exists():return _load_candidate_file(path)
    ecfg=_epoch_local_cfg(cfg,epoch); erng=np.random.default_rng(master_seed+N*100000+epoch*1009)
    allc=[]
    p(f"N={N} generating search epoch {epoch}: T=[{ecfg['T_MIN']:.1f},{ecfg['T_MAX']:.1f}], radius={ecfg['COARSE_RADIUS']:.3f}")
    for q in range(cfg["COARSE_TRAJECTORIES_PER_EPOCH"]):
        try:
            A=random_same_energy_A(erng,target_energy); R=A_to_bloch(A)
            tt,tr=integrate_dense(R,cfg["COARSE_TIME"],cfg["COARSE_DT"])
            sec=extract_poincare_section(tt,tr,target_energy); cc=recurrence_candidates_from_section(sec,ecfg)
            allc.extend(cc)
            p(f"  epoch {epoch} coarse {q+1}/{cfg['COARSE_TRAJECTORIES_PER_EPOCH']}: section={len(sec)}, recurrences={len(cc)}")
        except Exception as exc:p(f"  WARNING coarse trajectory skipped: {exc}")
    selected=_diversify_candidates(allc,cfg)
    checkpoint_candidates(path,selected)
    return selected


def _refine_candidate_final(c,cfg,target_energy):
    state_bound=0.999999
    lower=np.array([-state_bound]+[-state_bound]*N+[-10*np.pi]*N+[cfg["T_MIN"]],float)
    upper=np.array([ state_bound]+[ state_bound]*N+[ 10*np.pi]*N+[cfg["T_MAX"]],float)
    x0=np.minimum(np.maximum(candidate_to_x(c),lower+1e-10),upper-1e-10)
    try:
        resfun=recurrence_residual_factory(target_energy,cfg,150,4e-9,2e-10)
        result=least_squares(resfun,x0,bounds=(lower,upper),method="trf",xtol=2e-10,ftol=2e-10,gtol=2e-10,
                             max_nfev=cfg["MAX_NFEV"],x_scale="jac")
        A1=params_to_A(result.x[:-1]); R1=A_to_bloch(A1); Rf=integrate_final(R1,float(result.x[-1]),rtol=3e-9,atol=2e-10)
        D1=np.linalg.norm(Rf-R1) if Rf is not None else np.inf
        if D1<2e-3 and abs(energy_bloch(R1)-target_energy)<2e-4:
            pcfg=dict(cfg); pcfg["MAX_RESIDUAL_CALLS"]=max(3000,cfg["MAX_RESIDUAL_CALLS"]); pcfg["STAGNATION_CALLS"]=max(1200,cfg["STAGNATION_CALLS"])
            polish=recurrence_residual_factory(target_energy,pcfg,250,1.5e-11,8e-13)
            result=least_squares(polish,result.x,bounds=(lower,upper),method="trf",xtol=3e-13,ftol=3e-13,gtol=3e-13,
                                 max_nfev=cfg["POLISH_NFEV"],x_scale="jac")
    except CandidateAbort as exc:return None,"aborted:"+str(exc)
    except Exception as exc:return None,f"error:{type(exc).__name__}:{exc}"
    try:
        A=params_to_A(result.x[:-1]); base={"A":A,"R0":A_to_bloch(A),"T":float(result.x[-1]),"source":"search"}
        val=validate_orbit(base,target_energy,cfg)
        if val is None:return None,"validation_failed"
        return val,"accepted"
    except Exception as exc:return None,f"post_error:{type(exc).__name__}:{exc}"


def search_periodic_orbits(cfg,target_energy,outdir,rng,seed_orbits=None,force_search=False):
    """Adaptive, resumable search that does not declare success below the
    requested number of exact-symmetry-inequivalent hyperbolic UPO families."""
    outdir=Path(outdir); raw_path=outdir/"periodic_orbits_all_valid.csv"; state_path=outdir/"search_state.json"
    done=stage_marker(outdir,"search_final_v1")
    found=[]
    if raw_path.exists():
        try:found=load_orbits(raw_path)
        except Exception:found=[]
    # Merge validated legacy seeds, preserving all symmetry copies for audit.
    for o in (seed_orbits or []):
        if not any(abs(o["T"]-x["T"])/min(o["T"],x["T"])<1e-10 and np.linalg.norm(o["R0"]-x["R0"])<1e-8 for x in found):
            found.append(o)
    save_orbits(raw_path,found)
    clear=[o for o in found if o["rho"]>=cfg["CLEAR_UPO_RHO"]]
    reps,classes=deduplicate_orbits(clear,cfg,outdir,"search_current_clear") if clear else ([],[])
    if len(reps)>=cfg["REQUIRED_INDEPENDENT_UPOS"] and not force_search:
        mark_stage(outdir,"search_final_v1",{"independent_clear_families":len(reps),"status":"complete_from_seeds_or_resume"})
        return found

    st=read_json(state_path,{}) or {}; epoch=int(st.get("epoch",0))
    processed_rows=read_csv(outdir/"search_processed_candidates.csv") if (outdir/"search_processed_candidates.csv").exists() else []
    processed={r["candidate_key"] for r in processed_rows}
    start=time.perf_counter(); budget=cfg["SEARCH_BUDGET_HOURS"]*3600
    while True:
        clear=[o for o in found if o["rho"]>=cfg["CLEAR_UPO_RHO"]]
        reps,classes=deduplicate_orbits(clear,cfg,outdir,"search_current_clear") if clear else ([],[])
        save_orbits(outdir/"independent_clear_upos_current.csv",reps)
        p(f"N={N}: exact-symmetry independent clear UPO families = {len(reps)}/{cfg['REQUIRED_INDEPENDENT_UPOS']}")
        if len(reps)>=cfg["REQUIRED_INDEPENDENT_UPOS"]:
            mark_stage(outdir,"search_final_v1",{"independent_clear_families":len(reps),"epochs_completed":epoch})
            if (outdir/"SEARCH_NEEDS_RESUME.json").exists():(outdir/"SEARCH_NEEDS_RESUME.json").unlink()
            return found
        if time.perf_counter()-start>budget:
            payload={"N":N,"time":utcnow(),"epoch":epoch,"independent_clear_families":len(reps),
                     "required":cfg["REQUIRED_INDEPENDENT_UPOS"],"message":"Re-submit the identical command; search resumes from checkpoints."}
            write_json(outdir/"SEARCH_NEEDS_RESUME.json",payload); write_json(state_path,{"epoch":epoch})
            raise SearchIncomplete(f"N={N}: search budget reached with {len(reps)}/{cfg['REQUIRED_INDEPENDENT_UPOS']} families; safe resume required")
        cands=_generate_epoch_candidates(cfg,target_energy,outdir,epoch,MASTER_SEED)
        for ci,c in enumerate(cands):
            key=f"{epoch}:{ci}:{_candidate_hash(c)}"
            if key in processed:continue
            if time.perf_counter()-start>budget:
                write_json(state_path,{"epoch":epoch}); save_orbits(raw_path,found)
                write_json(outdir/"SEARCH_NEEDS_RESUME.json",{"N":N,"epoch":epoch,"candidate_index":ci,"time":utcnow()})
                raise SearchIncomplete(f"N={N}: safe search checkpoint at epoch {epoch}, candidate {ci}")
            p(f"\nN={N} EPOCH {epoch} candidate {ci+1}/{len(cands)} D0={c['D']:.3e} T0={c['T']:.6f}")
            o,status=_refine_candidate_final(c,cfg,target_energy)
            row={"candidate_key":key,"epoch":epoch,"candidate_index":ci,"D0":c["D"],"T0":c["T"],"status":status,"time":utcnow()}
            if o is not None:
                row.update({"T":o["T"],"D":o["return_D"],"rho":o["rho"],"lambda_over_omega":o["lambda"]/(2*np.pi/o["T"]),"floquet_method":o.get("floquet_method","")})
                found.append(o); save_orbits(raw_path,found)
                p(f"  VALID orbit: T={o['T']:.9f}, D={o['return_D']:.2e}, rho={o['rho']:.7g}, lambda/omega={row['lambda_over_omega']:.5g}, method={o.get('floquet_method')}")
            processed_rows.append(row); processed.add(key)
            fields=[]
            for r in processed_rows:
                for k in r:
                    if k not in fields:fields.append(k)
            atomic_csv(outdir/"search_processed_candidates.csv",fields,processed_rows)
            clear=[x for x in found if x["rho"]>=cfg["CLEAR_UPO_RHO"]]
            reps,_=deduplicate_orbits(clear,cfg,outdir,"search_current_clear") if clear else ([],[])
            if len(reps)>=cfg["REQUIRED_INDEPENDENT_UPOS"]:break
        epoch+=1; write_json(state_path,{"epoch":epoch})




def write_manifest(root):
    root=Path(root); rows=[]
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.name=="MANIFEST_SHA256.csv":continue
        h=hashlib.sha256()
        try:
            with open(path,"rb") as f:
                for chunk in iter(lambda:f.read(1024*1024),b""):h.update(chunk)
            rows.append({"file":str(path.relative_to(root)),"bytes":path.stat().st_size,"sha256":h.hexdigest()})
        except Exception:pass
    atomic_csv(root/"MANIFEST_SHA256.csv",["file","bytes","sha256"],rows)

def _legacy_catalog_paths(n,base):
    b=Path(base); c=[
        b/"ARTICLE_N248"/f"N{n}"/"periodic_orbits_raw.csv",
        b/"ARTICLE_N248"/f"N{n}"/"periodic_orbits_all_valid.csv",
        b/"ARTICLE_N248"/f"N{n}"/"independent_clear_upos.csv",
        b/f"N{n}_scar_results"/f"N{n}_same_energy_upos.csv",
        b/f"N{n}_scar_results"/"independent_clear_upos.csv",
        b/f"N{n}_same_energy_upos.csv",
    ]
    return [x for x in c if x.exists()]


def import_all_legacy_candidates(n,base,target,cfg,outdir):
    accepted=[]; audit=[]
    for path in _legacy_catalog_paths(n,base):
        p(f"N={n}: revalidating seed catalogue {path}")
        try:rows=read_csv(path)
        except Exception as exc:
            audit.append({"file":str(path),"row":"ALL","status":"read_error","note":str(exc)}); continue
        for ri,row in enumerate(rows):
            try:
                o=row_to_orbit(row); o["source"]=f"legacy:{path}"; v=validate_orbit(o,target,cfg)
                if v is None:audit.append({"file":str(path),"row":ri,"status":"rejected","note":"current validation failed"}); continue
                # Keep only clear candidates as search seeds; marginal orbits are not useful for the required catalogue.
                if v["rho"]>=cfg["CLEAR_UPO_RHO"]:
                    accepted.append(v); audit.append({"file":str(path),"row":ri,"status":"accepted_clear","T":v["T"],"rho":v["rho"]})
            except Exception as exc:audit.append({"file":str(path),"row":ri,"status":"error","note":str(exc)})
    # Remove literal duplicates but intentionally retain symmetry copies here;
    # the exact family quotient is documented by deduplicate_orbits.
    uniq=[]
    for o in accepted:
        if not any(abs(o["T"]-q["T"])/min(o["T"],q["T"])<1e-11 and np.linalg.norm(o["R0"]-q["R0"])<1e-9 for q in uniq):uniq.append(o)
    if audit:
        fields=[]
        for r in audit:
            for k in r:
                if k not in fields:fields.append(k)
        atomic_csv(Path(outdir)/"legacy_revalidation_audit.csv",fields,audit)
    save_orbits(Path(outdir)/"legacy_revalidated_clear_candidates.csv",uniq)
    return uniq


def _choose_exactly_required(reps,cfg):
    req=cfg["REQUIRED_INDEPENDENT_UPOS"]
    if len(reps)<req:raise RuntimeError(f"Only {len(reps)} independent families; {req} required")
    if len(reps)==req:return list(reps)
    # Deterministic diversity selection in period and local instability only;
    # no scar/localization outcome enters the selection.
    feats=np.array([[math.log(max(o["T"],1e-9)),math.log1p(max(o["lambda"]/(2*np.pi/o["T"]),0))] for o in reps])
    mu=feats.mean(0); sd=np.where(feats.std(0)>1e-12,feats.std(0),1); z=(feats-mu)/sd
    chosen=[int(np.argmin(feats[:,1])),int(np.argmax(feats[:,1]))]
    chosen=list(dict.fromkeys(chosen))
    while len(chosen)<req:
        remaining=[i for i in range(len(reps)) if i not in chosen]
        d=[min(np.linalg.norm(z[i]-z[j]) for j in chosen) for i in remaining]; chosen.append(remaining[int(np.argmax(d))])
    return [reps[i] for i in chosen[:req]]


def prepare_n_environment(outdir,n,cfg,target,args):
    ensure_dir(outdir); shell=energy_shell_diagnostics(n,target); write_json(Path(outdir)/"energy_shell.json",shell)
    write_json(Path(outdir)/"run_config.json",{"schema":SCHEMA_VERSION,"N":n,"M":n+1,"epsilon":epsilon,"delta":delta,"Ei":Ei,"Di":Di,"Lambda":Lambda,"target_energy":target,"energy_density":target/(n+1),"master_seed":args.seed,"quick":args.quick,"settings":cfg,"standard_windows":STANDARD_WINDOWS,"fine_windows":FINE_WINDOWS,"perturbation_scales":PERTURBATION_SCALES})
    write_json(Path(outdir)/"environment.json",{"generated_utc":utcnow(),"hostname":platform.node(),"python":platform.python_version(),"numpy":np.__version__,"scipy":scipy.__version__,"matplotlib":matplotlib.__version__,"slurm_job_id":os.environ.get("SLURM_JOB_ID"),"slurm_job_name":os.environ.get("SLURM_JOB_NAME")})



def run_one_n(n, root, args):
    """Run only the Section-3 FTLE/UPO stages for one environment size."""
    set_model(n)
    outdir = Path(root) / f"N{n}"
    cfg = config_for_n(n, args.quick, args.required_upos)
    if getattr(args, "search_budget_hours", None) is not None:
        cfg["SEARCH_BUDGET_HOURS"] = float(args.search_budget_hours)
    target = target_energy_for_n(n)
    ensure_dir(outdir)
    prepare_n_environment(outdir, n, cfg, target, args)
    rng = np.random.default_rng(args.seed + 1000*n)

    p("\n" + "="*96)
    p(f"SECTION 3 PIPELINE N={n}: E={target:.12f}, E/(N+1)={target/(n+1):.12f}")
    p("="*96)

    validate_exact_symmetries(outdir, np.random.default_rng(args.seed + 777*n))
    stage_chaos(cfg, target, outdir, rng)

    use_legacy = (not args.no_legacy) and bool(args.legacy_base)
    seeds = import_all_legacy_candidates(n, args.legacy_base, target, cfg, outdir) if use_legacy else []
    found = search_periodic_orbits(cfg, target, outdir, rng, seeds, force_search=args.force_search)
    clear = [o for o in found if o["rho"] >= cfg["CLEAR_UPO_RHO"]]
    reps, classes = deduplicate_orbits(clear, cfg, outdir, "FINAL_exact_symmetry_clear")
    if len(reps) < cfg["REQUIRED_INDEPENDENT_UPOS"]:
        raise SearchIncomplete(
            f"N={n}: final exact-symmetry audit has {len(reps)}/{cfg['REQUIRED_INDEPENDENT_UPOS']} families"
        )

    selected = _choose_exactly_required(reps, cfg)
    save_orbits(outdir / "all_independent_clear_upos.csv", reps)
    save_orbits(outdir / "selected_independent_upos.csv", selected)
    save_orbits(outdir / "independent_clear_upos.csv", selected)
    write_json(outdir / "upo_family_summary.json", {
        "raw_valid_periodic_orbits": len(found),
        "clear_candidates": len(clear),
        "independent_exact_symmetry_families": len(reps),
        "selected_for_collective_audit": len(selected),
        "family_sizes": [len(c) for c in classes],
        "required": cfg["REQUIRED_INDEPENDENT_UPOS"],
    })

    # Final validation archive for the selected microscopic candidates.
    fb = {}
    vr = []
    for i, o in enumerate(selected):
        v = validate_orbit(o, target, cfg)
        if v is None:
            raise RuntimeError(f"Selected UPO {i} failed final revalidation")
        selected[i] = v
        tt, tr = integrate_grid(v["R0"], v["T"], 1400, rtol=1.5e-10, atol=1e-12)
        drift, _, _ = energy_drift(tr)
        fb[f"orbit_time_{i}"] = tt
        fb[f"orbit_traj_{i}"] = tr
        fb[f"monodromy_{i}"] = v["Mphys"]
        fb[f"eigvals_{i}"] = v["eigvals"]
        vr.append({
            "orbit": i,
            "T": v["T"],
            "return_D": v["return_D"],
            "energy": v["energy"],
            "energy_drift_over_period": drift,
            "rho": v["rho"],
            "lambda": v["lambda"],
            "lambda_over_omega": v["lambda"]/(2*np.pi/v["T"]),
            "det_M": v["det"],
            "symplectic_error": v.get("symplectic_error"),
            "reciprocal_pair_error": v.get("reciprocal_pair_error"),
            "floquet_method": v.get("floquet_method"),
            "canonical_pole_margin": v.get("canonical_pole_margin"),
        })
    save_orbits(outdir / "selected_independent_upos.csv", selected)
    save_orbits(outdir / "independent_clear_upos.csv", selected)
    np.savez_compressed(outdir / "selected_upo_full_data.npz", **fb)
    atomic_csv(outdir / "selected_upo_validation.csv", list(vr[0].keys()), vr)


def write_section3_summary(root, Ns):
    rows = []
    for n in Ns:
        nd = Path(root) / f"N{n}"
        chaos = read_json(nd / "chaos_summary.json") if (nd / "chaos_summary.json").exists() else {}
        upos = read_csv(nd / "selected_upo_validation.csv") if (nd / "selected_upo_validation.csv").exists() else []
        rows.append({
            "N": n,
            "median_same_energy_FTLE": chaos.get("median_ftle", np.nan),
            "n_selected_microscopic_upos": len(upos),
            "periods": [float(r["T"]) for r in upos] if upos else [],
        })
    write_json(Path(root) / "SECTION3_INITIAL_SEARCH_SUMMARY.json", {
        "reference_energy_density": REFERENCE_ENERGY_DENSITY,
        "results": rows,
        "note": "Final collective-family independence and fixed-sector Floquet are applied by the second Section-3 script.",
    })


def main():
    parser = argparse.ArgumentParser(
        description="Section 3.1-3.2: same-energy FTLE and initial validated UPO search"
    )
    parser.add_argument("--root", default="SECTION3_RESULTS")
    parser.add_argument("--Ns", default="2,4,6,8,10")
    parser.add_argument("--required-upos", type=int, default=4)
    parser.add_argument(
        "--legacy-base", default="",
        help="Optional directory containing prior candidate catalogues. Every imported orbit is fully revalidated."
    )
    parser.add_argument("--no-legacy", action="store_true")
    parser.add_argument("--force-search", action="store_true")
    parser.add_argument("--quick", action="store_true", help="Smoke test only; not article quality")
    parser.add_argument("--seed", type=int, default=MASTER_SEED)
    parser.add_argument("--search-budget-hours", type=float, default=None,
                        help="Operational checkpoint interval only; does not change the scientific search criteria")
    args = parser.parse_args()

    Ns = sorted(set(int(x) for x in args.Ns.split(",") if x.strip()))
    if any(n not in (2,4,6,8,10) for n in Ns):
        raise ValueError("Supported N values are 2,4,6,8,10")
    if not args.quick and args.required_upos != 4:
        raise ValueError("The article calculation requires exactly four selected UPO candidates per N")

    root = Path(args.root).resolve()
    ensure_dir(root)
    global _INTERRUPTION_FILE
    _INTERRUPTION_FILE = root / "INTERRUPTED.json"
    write_json(root / "MASTER_CONFIG.json", {
        "schema": "SECTION3_SUPPLEMENTARY_V1",
        "Ns": Ns,
        "required_upos": args.required_upos,
        "seed": args.seed,
        "quick": args.quick,
        "legacy_base": args.legacy_base,
        "reference_energy_density": REFERENCE_ENERGY_DENSITY,
        "scope": "Section 3 FTLE and initial microscopic UPO search only",
    })

    try:
        for n in Ns:
            run_one_n(n, root, args)
        write_section3_summary(root, Ns)
        write_manifest(root)
        write_json(root / "SECTION3_INITIAL_SEARCH_COMPLETE.json", {
            "status": "COMPLETE", "Ns": Ns, "required_upos": args.required_upos
        })
        p("\nSECTION 3 INITIAL FTLE/UPO SEARCH COMPLETE")
        p("Next: run 3.2-3.3_CODE_collective_UPO_completion_and_Floquet.py on the same --root.")
    except SearchIncomplete as exc:
        write_json(root / "SECTION3_NEEDS_RESUME.json", {
            "message": str(exc),
            "instruction": "Re-submit the identical command; checkpoints are preserved."
        })
        raise SystemExit(75)


if __name__ == "__main__":
    main()
