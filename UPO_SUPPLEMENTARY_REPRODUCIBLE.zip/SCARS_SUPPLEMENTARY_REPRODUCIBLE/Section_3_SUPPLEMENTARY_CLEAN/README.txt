SECTION 3 SUPPLEMENTARY CODE
============================

Purpose
-------
Reproduce the same-energy chaoticity analysis, UPO search, collective-family completion and
fixed-sector Floquet analysis used in Section 3 of the manuscript.

Files
-----
3.1-3.2_CODE_FTLE_and_UPO_search.py
    Same-energy FTLE calculation and initial microscopic UPO search/refinement.

3.2-3.3_CODE_collective_UPO_completion_and_Floquet.py
    Collective-family audit/completion and fixed-sector Floquet analysis.

README_Why_two_codes.txt
    Explanation of why both scripts are required.

SOURCE_PROVENANCE_SHA256.txt
    Provenance hashes for the original production sources and the reduced Section-3 sources.

Scientific provenance
---------------------
The supplementary scripts are reduced versions of the validated production sources. Scientific
definitions for the retained FTLE, UPO search/refinement, collective-equivalence and fixed-sector
Floquet calculations are unchanged. Later-section routines were removed from these Section-3 files.

Dependencies
------------
Python 3, NumPy, SciPy and Matplotlib. No pandas dependency.

Execution
---------
The recommended public execution path is the complete workflow in ../REPRODUCE/:

    bash ../REPRODUCE/submit_reproduction.sh

The Section-3 scripts may also be run directly for development or inspection:

1) Initial FTLE/UPO search:

    python3 3.1-3.2_CODE_FTLE_and_UPO_search.py --root SECTION3_RESULTS

2) Collective completion and fixed-sector Floquet:

    python3 3.2-3.3_CODE_collective_UPO_completion_and_Floquet.py \
        --root SECTION3_RESULTS \
        --core 3.1-3.2_CODE_FTLE_and_UPO_search.py

Both stages are checkpointed and resumable. Full manuscript-quality searches are computationally
expensive.

Validated target
----------------
The complete reproduction is checked against ../REPRODUCE/expected_results.json. The final Section-3
target contains 20 collective UPO families, four for each N=2,4,6,8,10, with 19/20 representatives
satisfying the fixed-sector hyperbolicity threshold rho_sec > 1.05.

Static result snapshots from earlier development runs are intentionally not used as inputs. The
published workflow regenerates the catalogue from scratch and the final validator checks the result.
