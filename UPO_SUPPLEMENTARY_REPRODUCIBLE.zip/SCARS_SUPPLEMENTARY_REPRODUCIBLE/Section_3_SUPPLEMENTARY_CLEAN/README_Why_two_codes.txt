WHY TWO PYTHON CODES ARE REQUIRED FOR SECTION 3

Section 3 uses two Python scripts because the calculation has two scientifically distinct stages.

1. 3.1-3.2_CODE_FTLE_and_UPO_search.py

This script performs the same-energy chaoticity analysis and the initial periodic-orbit search. It:
- generates trajectories at the target energy for N = 2, 4, 6, 8, and 10;
- calculates the finite-time Lyapunov exponents used in Section 3.1;
- detects close recurrences on the Poincare section;
- refines recurrence candidates into closed periodic solutions;
- validates the periodic orbits through return error, energy conservation, and full microscopic Floquet analysis;
- removes equivalent microscopic solutions related by time origin, environmental-TLS permutations, and the exact P/T/PT symmetries.

The output is therefore the validated microscopic UPO candidate catalogue together with the same-energy FTLE results.

2. 3.2-3.3_CODE_collective_UPO_completion_and_Floquet.py

Microscopically different periodic solutions can still generate the same collective trajectory described by the central Bloch vector r0 and the collective environmental vector S. Such solutions must not be counted as independent dynamical UPO families.

The second script therefore:
- compares the UPOs at the collective (r0,S) level;
- identifies microscopic solutions corresponding to the same collective trajectory;
- completes the N=10 catalogue with additional independent collective families when required;
- verifies four distinct collective families for each N;
- calculates Floquet stability within the exact invariant manifold S^2 x S^2_|S|;
- writes the final 20-family fixed-sector Floquet table used in Section 3.3.

The two scripts are complementary. The first performs the FTLE calculation and the original recurrence/refinement search. The second applies the final collective-family independence criterion and the fixed-sector Floquet analysis.

The supplementary version of the second script has been reduced to Section-3 operations only. It no longer recalculates localization metrics or FDR statistics from later sections and therefore does not depend on scar_final_standard_metrics.py.
