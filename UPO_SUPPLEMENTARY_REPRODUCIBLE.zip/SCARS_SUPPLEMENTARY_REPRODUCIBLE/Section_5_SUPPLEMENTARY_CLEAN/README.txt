FINAL REPRODUCIBILITY NOTE
--------------------------
Static result snapshots from earlier development runs are intentionally not included in this final package.
Run the workflow under ../REPRODUCE/ to generate the authoritative results from scratch, then validate them against ../REPRODUCE/expected_results.json.

SECTION 5 SUPPLEMENTARY CODE
============================

Purpose
-------
Reproduce Section 5: Energy dependence of chaos and UPO-associated localization.

This folder intentionally contains only ONE new Python script:
  5_CODE_energy_dependence.py

Sections 3 and 4 already define the dynamical core, UPO refinement,
collective-family equivalence, fixed-sector Floquet calculation, and
near-UPO/reference localization protocol. Section 5 reuses those exact
Supplementary implementations instead of duplicating them.

Required Supplementary dependencies
-----------------------------------
From Section 3:
  3.1-3.2_CODE_FTLE_and_UPO_search.py
  3.2-3.3_CODE_collective_UPO_completion_and_Floquet.py

From Section 4:
  4_CODE_UPO_localization_analysis.py

Files in this package
---------------------
5_CODE_energy_dependence.py
    Section-5-specific five-energy scan at N=10. It constructs the energy
    shells, finds four collectively inequivalent UPO families at each energy,
    computes fixed-sector FTLE and Floquet instability, applies the Section-4
    localization protocol, and builds the final 5x4 output dataset.

README_Why_one_code.txt
    Explanation of why the historical duplicate-correction script is not
    included in the published Supplementary workflow.

SOURCE_PROVENANCE_SHA256.txt
    SHA256 provenance of the original production files and the clean
    supplementary implementation.

Scientific workflow
-------------------
At fixed N=10 the code constructs five energy shells centered on the
reference energy density e=0.8371173899705596. Four collectively inequivalent
UPO families are selected at every energy.

For each selected family the code evaluates:
  - fixed-sector FTLE;
  - fixed-sector Floquet instability chi_UPO=lambda_sec/omega;
  - tube-localization enhancement over 2T-20T;
  - late tube localization over 16T-20T;
  - return-fidelity enhancement over 1T-5T;
  - recurrence timing over 1T-5T.

The final manuscript significance criterion is raw one-sided
Mann-Whitney p_MW < 0.05.

Final collective-family criterion
---------------------------------
The historical production run initially admitted a numerically split
duplicate at the highest energy. A later audit identified it and replaced it.

The Supplementary code incorporates that FINAL criterion during the search,
rather than reproducing the old catalogue and then running a correction.

The original strict collective criterion is always retained. For orbits with
period and |S| agreeing within 1e-5 relative, the code additionally requires
a high-resolution check at 1080 and 2160 phase points with:
  rms < 5e-4
  max < 3e-3

Therefore no separate "duplicate correction" script is required.

Recommended execution
---------------------
The recommended public execution path is the automated workflow from the package root:

    bash REPRODUCE/submit_reproduction.sh

This automatically runs Section 5 after the required Section-3 catalogue has been generated.
No manually prepared input catalogue or private path is required.

Direct execution
----------------
The Section-5 script can also be run manually. From this directory, first define the locations of
the reproduced Section-3 results and the desired Section-5 output directory, for example:

    S3=/path/to/SCARS_REPRODUCTION_FINAL/SECTION3
    S5OUT=/path/to/SCARS_REPRODUCTION_FINAL/SECTION5

Validate the interfaces:

    python3 5_CODE_energy_dependence.py \
      --mode validate \
      --core ../Section_3_SUPPLEMENTARY_CLEAN/3.1-3.2_CODE_FTLE_and_UPO_search.py \
      --collective ../Section_3_SUPPLEMENTARY_CLEAN/3.2-3.3_CODE_collective_UPO_completion_and_Floquet.py \
      --localization ../Section_4_SUPPLEMENTARY_CLEAN/4_CODE_UPO_localization_analysis.py

Run the five energy calculations (they may be submitted independently):

    for I in 0 1 2 3 4; do
      python3 5_CODE_energy_dependence.py \
        --mode energy \
        --energy-index "$I" \
        --core ../Section_3_SUPPLEMENTARY_CLEAN/3.1-3.2_CODE_FTLE_and_UPO_search.py \
        --collective ../Section_3_SUPPLEMENTARY_CLEAN/3.2-3.3_CODE_collective_UPO_completion_and_Floquet.py \
        --localization ../Section_4_SUPPLEMENTARY_CLEAN/4_CODE_UPO_localization_analysis.py \
        --reference-orbits "$S3/COLLECTIVE_COMPLETION/N10_SEARCH/N10_collective_representatives.csv" \
        --output-root "$S5OUT"
    done

After all five energy calculations finish:

    python3 5_CODE_energy_dependence.py \
      --mode aggregate \
      --core ../Section_3_SUPPLEMENTARY_CLEAN/3.1-3.2_CODE_FTLE_and_UPO_search.py \
      --collective ../Section_3_SUPPLEMENTARY_CLEAN/3.2-3.3_CODE_collective_UPO_completion_and_Floquet.py \
      --localization ../Section_4_SUPPLEMENTARY_CLEAN/4_CODE_UPO_localization_analysis.py \
      --output-root "$S5OUT"

Searches are checkpointed. If an energy search reaches its configured search budget, rerun the
same command to continue from the checkpoint.

Main generated outputs
----------------------
Under the selected Section-5 output root, the main aggregated files are written to COMPARISON/:
  SECTION5_ORBIT_METRICS_20_UPOs.csv
  SECTION5_ENERGY_SUMMARY_5x4.csv
  SECTION5_FINAL_REPORT.txt
  Fig_energy_dependence_4panel.pdf

Dependencies
------------
Python 3, NumPy, SciPy, Matplotlib. No pandas dependency in the Supplementary code.
