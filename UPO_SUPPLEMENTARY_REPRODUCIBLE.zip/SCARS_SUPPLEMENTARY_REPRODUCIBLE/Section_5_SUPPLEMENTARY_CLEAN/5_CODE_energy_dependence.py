#!/usr/bin/env python3
"""
5_CODE_energy_dependence.py
===========================

Supplementary implementation of Section 5:
"Energy dependence of chaos and UPO-associated localization".

This script contains only the Section-5-specific workflow.  It deliberately
reuses the final Supplementary implementations from Sections 3 and 4:

  Section 3 core:
    3.1-3.2_CODE_FTLE_and_UPO_search.py

  Section 3 collective-family / fixed-sector Floquet code:
    3.2-3.3_CODE_collective_UPO_completion_and_Floquet.py

  Section 4 localization code:
    4_CODE_UPO_localization_analysis.py

Scientific design
-----------------
* N = 10 is fixed.
* Five energy shells are chosen symmetrically in normalized global-shell
  position around the reference energy density e=0.8371173899705596.
* Four independent collective UPO families are required at every energy.
* UPO search/refinement and fixed-sector Floquet definitions are exactly those
  used in Section 3.
* Near-UPO/reference ensembles and the four primary localization observables
  are exactly those used in Section 4.
* Fixed-sector FTLE is evaluated separately around every selected UPO sector.
* The final table uses raw one-sided Mann-Whitney p-values, p_MW < 0.05.

Important catalogue criterion
-----------------------------
The production history revealed that the highest-energy shell originally
contained two numerically split representations of the same collective UPO.
The Supplementary implementation does not reproduce that historical mistake
and then patch it.  Instead, the final enhanced collective-equivalence audit
is applied during the search at every energy:

  - the original strict collective-equivalence criterion is retained;
  - if periods and |S| agree within 1e-5 relative, equivalence is also tested
    at 1080 and 2160 phase points using rms < 5e-4 and max < 3e-3.

Thus the four families selected at each energy already satisfy the final
independence criterion used for the manuscript.

Full article-quality searches are computationally expensive and checkpointed.
CPU only. Dependencies: Python 3, NumPy, SciPy and Matplotlib.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import math
import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

import numpy as np
from scipy.integrate import solve_ivp

SCHEMA = "SECTION5_ENERGY_DEPENDENCE_V1"
N_FIXED = 10
N_FAMILIES = 4
REFERENCE_ENERGY_DENSITY = 2.511352169911679 / 3.0
RESTRICTED_RHO_MIN = 1.05


class SearchBudgetReached(RuntimeError):
    pass


# ---------------------------------------------------------------------------
# I/O
# ---------------------------------------------------------------------------

def ensure(path):
    Path(path).mkdir(parents=True, exist_ok=True)


def san(x):
    if isinstance(x, dict):
        return {str(k): san(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [san(v) for v in x]
    if isinstance(x, np.ndarray):
        return san(x.tolist())
    if isinstance(x, np.generic):
        return san(x.item())
    if isinstance(x, complex):
        return {"real": float(x.real), "imag": float(x.imag)}
    if isinstance(x, float) and not np.isfinite(x):
        return None
    return x


def write_json(path, obj):
    path = Path(path)
    ensure(path.parent)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(san(obj), f, indent=2, sort_keys=True, allow_nan=False)
    os.replace(tmp, path)


def read_json(path, default=None):
    path = Path(path)
    if not path.exists():
        return default
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def write_csv(path, rows):
    path = Path(path)
    ensure(path.parent)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for row in rows:
            w.writerow({k: row.get(k, "") for k in fields})
    os.replace(tmp, path)


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def as_float(x, default=np.nan):
    try:
        y = float(x)
        return y if np.isfinite(y) else default
    except Exception:
        return default


def load_module(name, path):
    path = str(Path(path).resolve())
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def energy_label(i, e):
    return f"E{i}_e{e:.9f}".replace(".", "p")


# ---------------------------------------------------------------------------
# Small adapter required by the Section-3 collective code
# ---------------------------------------------------------------------------

def central_vector(core, R):
    return np.asarray(R, float).reshape(core.M, 3)[0].copy()


def env_collective(core, R):
    return np.sum(np.asarray(R, float).reshape(core.M, 3)[1:], axis=0)


def helper_adapter(localization):
    return SimpleNamespace(
        central_vector=central_vector,
        env_collective=env_collective,
        central_on_energy=localization.central_on_energy,
        compose_state=localization.compose_state,
        sample_microcanonical_sector_state=localization.sample_microcanonical_sector_state,
    )


# ---------------------------------------------------------------------------
# Energy grid
# ---------------------------------------------------------------------------

def build_energy_grid(core):
    core.set_model(N_FIXED)
    emin, emax, zstar = core.classical_energy_bounds(N_FIXED)
    Eref = (N_FIXED + 1) * REFERENCE_ENERGY_DENSITY
    xiref = (Eref - emin) / (emax - emin)
    offsets = [-0.15, -0.075, 0.0, 0.075, 0.15]
    xis = [float(xiref + dx) for dx in offsets]
    if min(xis) <= 0.0 or max(xis) >= 1.0:
        raise RuntimeError(f"Requested energy scan leaves accessible shell: {xis}")
    rows = []
    for i, xi in enumerate(xis):
        E = emin + xi * (emax - emin)
        rows.append({
            "energy_index": i,
            "xi_global": xi,
            "target_energy": E,
            "energy_density": E / (N_FIXED + 1),
            "Emin": emin,
            "Emax": emax,
            "zstar_Emax": zstar,
            "is_reference": bool(abs(E - Eref) < 1e-9),
        })
    return rows


# ---------------------------------------------------------------------------
# Efficient exact-energy sampler used only for search/chaos trajectories
# ---------------------------------------------------------------------------

def adaptive_same_energy_A(core, localization, rng, target_energy, max_attempts=50000):
    _, emax, _ = core.classical_energy_bounds(core.N)
    ratio = min(0.999, abs(float(target_energy)) / max(emax, 1e-12))
    sign = 1.0 if target_energy >= 0 else -1.0
    base = 0.15 + 7.5 * ratio**1.7

    for attempt in range(int(max_attempts)):
        if attempt % 11 == 0:
            kappa = max(0.02, 0.35 * base)
        else:
            kappa = max(0.02, base * math.exp(float(rng.normal(scale=0.45))))
        tilt = float(rng.uniform(-0.55, 0.55))
        mean = np.array([-sign, 0.0, tilt], float)
        mean /= np.linalg.norm(mean)

        env = []
        for _ in range(core.N):
            v = kappa * mean + rng.normal(size=3)
            nv = np.linalg.norm(v)
            if nv < 1e-14:
                break
            env.append(v / nv)
        if len(env) != core.N:
            continue

        env = np.asarray(env, float)
        c = localization.central_on_energy(env, target_energy, rng, target=None)
        if c is None:
            continue
        R = localization.compose_state(c, env)
        if abs(core.energy_bloch(R) - target_energy) < 3e-10:
            return core.bloch_to_A(R)

    raise RuntimeError(f"adaptive exact-energy sampler failed for E={target_energy}")


def install_adaptive_sampler(core, localization):
    core.random_same_energy_A = (
        lambda rng, target_energy, max_attempts=4000:
        adaptive_same_energy_A(
            core, localization, rng, target_energy,
            max_attempts=max(20000, int(max_attempts))
        )
    )


# ---------------------------------------------------------------------------
# Final collective-equivalence criterion
# ---------------------------------------------------------------------------

def install_enhanced_collective_equivalence(coll):
    """Install the final collective-family criterion used for the manuscript."""
    original = coll.robust_collective_alignment

    def enhanced(core, helpers, oa, ob, points=720, **kwargs):
        base = original(core, helpers, oa, ob, points=points, **kwargs)
        base["equivalence_mode"] = "strict" if base.get("equivalent") else "none"
        if base.get("equivalent"):
            return base

        relT = float(base.get("period_rel_diff", np.inf))
        relS = float(base.get("S_rel_diff", np.inf))
        if relT > 1.0e-5 or relS > 1.0e-5:
            return base

        hi1 = original(
            core, helpers, oa, ob, points=max(1080, int(points)),
            period_rel_tol=1.0e-5, S_rel_tol=1.0e-5,
            rms_tol=5.0e-4, max_tol=3.0e-3,
        )
        if not hi1.get("equivalent"):
            base.update({
                "enhanced_rms_1080": hi1.get("rms"),
                "enhanced_max_1080": hi1.get("max"),
            })
            return base

        hi2 = original(
            core, helpers, oa, ob, points=2160,
            period_rel_tol=1.0e-5, S_rel_tol=1.0e-5,
            rms_tol=5.0e-4, max_tol=3.0e-3,
        )
        if not hi2.get("equivalent"):
            base.update({
                "enhanced_rms_1080": hi1.get("rms"),
                "enhanced_max_1080": hi1.get("max"),
                "enhanced_rms_2160": hi2.get("rms"),
                "enhanced_max_2160": hi2.get("max"),
            })
            return base

        out = dict(hi2)
        out.update({
            "equivalent": True,
            "equivalence_mode": "enhanced_near_identical_collective",
            "enhanced_rms_1080": float(hi1["rms"]),
            "enhanced_max_1080": float(hi1["max"]),
            "enhanced_rms_2160": float(hi2["rms"]),
            "enhanced_max_2160": float(hi2["max"]),
        })
        return out

    coll.robust_collective_alignment = enhanced
    return original


# ---------------------------------------------------------------------------
# Four-family UPO search
# ---------------------------------------------------------------------------

def load_reference_reps(core, path, target):
    if not path or not Path(path).exists():
        return []
    reps = core.load_orbits(path)
    cfg = core.config_for_n(N_FIXED, quick=False, required_upos=4)
    out = []
    for orbit in reps:
        v = core.validate_orbit(orbit, target, cfg)
        if v is not None:
            out.append(v)
    return out


def collapse_collective(core, helpers, coll, reps, outdir, prefix, points=720):
    if not reps:
        return []
    _, classes, _ = coll.robust_classify(
        core, helpers, reps, outdir, prefix=prefix, points=points
    )
    # Prefer the best-closed microscopic representative of each class.
    result = []
    for members in classes:
        best = min(members, key=lambda j: float(reps[j].get("return_D", np.inf)))
        result.append(reps[best])
    return result


def custom_search(core, helpers, coll, target, outdir, rng, args, seed_reps=None):
    outdir = Path(outdir)
    ensure(outdir)
    pool_path = outdir / "collective_hyperbolic_pool.csv"
    processed_path = outdir / "processed_candidates.csv"
    state_path = outdir / "search_state.json"

    cfg = core.config_for_n(N_FIXED, quick=False, required_upos=20)
    cfg["SEARCH_BUDGET_HOURS"] = float(args.search_budget_hours)
    cfg["T_MAX"] = max(float(cfg["T_MAX"]), 620.0)

    reps = core.load_orbits(pool_path) if pool_path.exists() else []
    valid = []
    for orbit in reps:
        v = core.validate_orbit(orbit, target, cfg)
        if v is None:
            continue
        try:
            rf = coll.fixed_sector_floquet(core, helpers, v)
            if rf["restricted_rho"] > RESTRICTED_RHO_MIN:
                v["fixed_sector"] = rf
                valid.append(v)
        except Exception:
            pass

    reps = collapse_collective(
        core, helpers, coll, valid, outdir, "RESUME_AUDIT", 1080
    )

    for orbit in seed_reps or []:
        try:
            v = core.validate_orbit(orbit, target, cfg)
            if v is None:
                continue
            rf = coll.fixed_sector_floquet(core, helpers, v)
            if rf["restricted_rho"] <= RESTRICTED_RHO_MIN:
                continue
            duplicate = any(
                coll.robust_collective_alignment(
                    core, helpers, q, v, points=1080
                )["equivalent"]
                for q in reps
            )
            if not duplicate:
                v["source"] = "validated_reference_N10_energy"
                v["fixed_sector"] = rf
                reps.append(v)
        except Exception as exc:
            print(f"WARNING reference seed rejected: {exc}", flush=True)

    reps = collapse_collective(
        core, helpers, coll, reps, outdir, "SEEDED_AUDIT", 1080
    )
    core.save_orbits(pool_path, reps)

    processed_rows = read_csv(processed_path) if processed_path.exists() else []
    processed = {r.get("candidate_key", "") for r in processed_rows}
    state = read_json(state_path, {}) or {}
    epoch = int(state.get("epoch", 0))
    start = time.perf_counter()
    budget = float(args.search_budget_hours) * 3600.0

    while True:
        reps = collapse_collective(
            core, helpers, coll, reps, outdir, "CURRENT_COLLECTIVE_AUDIT", 1080
        )
        core.save_orbits(pool_path, reps)
        print(f"Collective fixed-sector hyperbolic families: {len(reps)}/4", flush=True)

        if len(reps) >= N_FAMILIES:
            candidate = reps[:N_FAMILIES]
            _, c1080, _ = coll.robust_classify(
                core, helpers, candidate, outdir,
                prefix="FINAL_AUDIT_1080", points=1080,
            )
            _, c2160, _ = coll.robust_classify(
                core, helpers, candidate, outdir,
                prefix="FINAL_AUDIT_2160", points=2160,
            )
            if (
                len(c1080) == N_FAMILIES and
                len(c2160) == N_FAMILIES and
                all(len(c) == 1 for c in c1080) and
                all(len(c) == 1 for c in c2160)
            ):
                return candidate
            reps = collapse_collective(
                core, helpers, coll, candidate, outdir,
                "FINAL_AUDIT_COLLAPSED", 2160,
            )
            core.save_orbits(pool_path, reps)

        if time.perf_counter() - start > budget:
            write_json(
                outdir / "SEARCH_NEEDS_RESUME.json",
                {
                    "epoch": epoch,
                    "n_families": len(reps),
                    "target": N_FAMILIES,
                    "message": "Re-submit the same energy task; checkpoints are safe.",
                },
            )
            write_json(state_path, {"epoch": epoch})
            raise SearchBudgetReached

        print("\n" + "=" * 88, flush=True)
        print(f"ENERGY SEARCH EPOCH {epoch} -- {len(reps)}/4", flush=True)
        print("=" * 88, flush=True)

        candidates = core._generate_epoch_candidates(
            cfg, target, outdir, epoch, int(args.seed)
        )
        try:
            candidates = coll.reorder_candidates_for_collective_novelty(
                core, helpers, candidates, reps
            )
        except Exception:
            pass

        for ci, cand in enumerate(candidates):
            key = f"{epoch}:{ci}:{core._candidate_hash(cand)}"
            if key in processed:
                continue
            if time.perf_counter() - start > budget:
                write_json(state_path, {"epoch": epoch})
                raise SearchBudgetReached

            orbit, status = core._refine_candidate_final(cand, cfg, target)
            row = {
                "candidate_key": key,
                "epoch": epoch,
                "candidate_index": ci,
                "D0": cand.get("D", np.nan),
                "T0": cand.get("T", np.nan),
                "status": status,
            }

            if orbit is not None:
                row.update({
                    "T": orbit["T"],
                    "return_D": orbit["return_D"],
                    "rho_full": orbit["rho"],
                })
                try:
                    rf = coll.fixed_sector_floquet(core, helpers, orbit)
                    row.update({
                        "restricted_rho": rf["restricted_rho"],
                        "restricted_lambda_over_omega":
                            rf["restricted_lambda_over_omega"],
                    })
                    if rf["restricted_rho"] <= RESTRICTED_RHO_MIN:
                        row["decision"] = "reject_not_fixed_sector_hyperbolic"
                    else:
                        duplicate = None
                        for j, q in enumerate(reps):
                            al = coll.robust_collective_alignment(
                                core, helpers, q, orbit, points=1080
                            )
                            if al["equivalent"]:
                                duplicate = (j, al)
                                break
                        if duplicate is not None:
                            row["decision"] = "reject_collective_duplicate"
                            row["duplicate_of"] = duplicate[0]
                            row["equiv_rms"] = duplicate[1].get("rms", np.nan)
                            row["equiv_max"] = duplicate[1].get("max", np.nan)
                            row["equivalence_mode"] = duplicate[1].get(
                                "equivalence_mode", ""
                            )
                        else:
                            orbit["source"] = (
                                f"energy_scan_epoch{epoch}_candidate{ci}"
                            )
                            orbit["fixed_sector"] = rf
                            reps.append(orbit)
                            core.save_orbits(pool_path, reps)
                            row["decision"] = "ACCEPT_NEW_COLLECTIVE_HYPERBOLIC"
                            row["new_count"] = len(reps)
                            print(
                                f"*** ACCEPTED #{len(reps)}: "
                                f"T={orbit['T']:.9f}, "
                                f"rho_sec={rf['restricted_rho']:.6g}, "
                                f"chi={rf['restricted_lambda_over_omega']:.6g}",
                                flush=True,
                            )
                except Exception as exc:
                    row["decision"] = "reject_fixed_sector_floquet_error"
                    row["error"] = f"{type(exc).__name__}:{exc}"
            else:
                row["decision"] = "reject_refinement"

            processed_rows.append(row)
            processed.add(key)
            write_csv(processed_path, processed_rows)
            if len(reps) >= N_FAMILIES:
                break

        epoch += 1
        write_json(state_path, {"epoch": epoch})


# ---------------------------------------------------------------------------
# Fixed-sector FTLE
# ---------------------------------------------------------------------------

def project_tangent_energy(y, v):
    y = np.asarray(y, float)
    v = np.asarray(v, float).copy()
    r, S = y[:3], y[3:]
    v[:3] -= np.dot(v[:3], r) / max(np.dot(r, r), 1e-300) * r
    v[3:] -= np.dot(v[3:], S) / max(np.dot(S, S), 1e-300) * S
    g = np.array([-2.0, 0.0, S[2], -2.0, 0.0, r[2]], float)
    g[:3] -= np.dot(g[:3], r) / max(np.dot(r, r), 1e-300) * r
    g[3:] -= np.dot(g[3:], S) / max(np.dot(S, S), 1e-300) * S
    gg = np.dot(g, g)
    if gg > 1e-20:
        v -= np.dot(v, g) / gg * g
    return v


def fixed_sector_ftle(helpers, coll, core, R0, rng, total=120.0, chunks=60):
    y = np.concatenate([
        helpers.central_vector(core, R0),
        helpers.env_collective(core, R0),
    ])
    v = project_tangent_energy(y, rng.normal(size=6))
    v /= np.linalg.norm(v)
    acc = 0.0
    dt = total / chunks
    t0 = 0.0

    for _ in range(chunks):
        def rhs(t, Y):
            yy = Y[:6]
            vv = Y[6:]
            return np.concatenate([
                coll.reduced_rhs6(t, yy),
                coll.reduced_jacobian6(yy) @ vv,
            ])

        sol = solve_ivp(
            rhs,
            (t0, t0 + dt),
            np.concatenate([y, v]),
            method="DOP853",
            rtol=3e-9,
            atol=2e-11,
        )
        if not sol.success:
            raise RuntimeError(sol.message)

        y = sol.y[:6, -1]
        v = project_tangent_energy(y, sol.y[6:, -1])
        norm = np.linalg.norm(v)
        acc += math.log(norm)
        v /= norm
        t0 += dt

    return float(acc / total)


def run_sector_ftle(
    core, localization, helpers, coll, orbit, target, outdir, rng, nsamples=8
):
    path = Path(outdir) / "fixed_sector_ftle_samples.csv"
    rows = read_csv(path) if path.exists() else []
    done = {int(r["sample"]) for r in rows}

    for i in range(nsamples):
        if i in done:
            continue
        R = localization.sample_microcanonical_sector_state(
            core, orbit["R0"], target, rng
        )
        lam = fixed_sector_ftle(helpers, coll, core, R, rng)
        rows.append({
            "sample": i,
            "ftle_sector": lam,
            "energy": core.energy_bloch(R),
        })
        write_csv(path, rows)
        print(f"    sector FTLE {i+1}/{nsamples}: {lam:+.5e}", flush=True)

    vals = np.array([as_float(r["ftle_sector"]) for r in rows], float)
    return {
        "sector_ftle_mean": float(np.mean(vals)),
        "sector_ftle_median": float(np.median(vals)),
        "sector_ftle_std": (
            float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0
        ),
        "sector_ftle_positive_fraction": float(np.mean(vals > 0)),
        "sector_ftle_n": len(vals),
    }


# ---------------------------------------------------------------------------
# Section-4 localization protocol at an arbitrary energy
# ---------------------------------------------------------------------------

def localization_args(args, seed):
    return SimpleNamespace(
        near=int(args.near),
        controls=int(args.controls),
        periods=20,
        ppp=int(args.ppp),
        phase_points=int(args.phase_points),
        near_amplitude=1e-4,
        control_max_tube=float(args.control_max_tube),
        bootstrap=int(args.bootstrap),
        seed=int(seed),
        force=bool(args.force),
        save_time_series=False,
        plots=False,
    )


def analyze_energy_upo(
    core, localization, orbit, target, outroot, energy_index, oid, args
):
    out = Path(outroot) / "LOCALIZATION" / f"UPO{oid}"
    ensure(out)
    summary_path = out / "summary.csv"
    if summary_path.exists() and not args.force:
        return read_csv(summary_path)[0]

    a = localization_args(args, int(args.seed) + energy_index * 1000 + oid)
    rng = np.random.default_rng(a.seed + 100000 * N_FIXED + oid)
    T = float(orbit["T"])
    phase = core.phase_grid(orbit, a.phase_points)

    values = {"near": [], "control": []}
    ic_rows = []
    for kind, count in (("control", a.controls), ("near", a.near)):
        for sample in range(count):
            base = phase[int(rng.integers(0, len(phase)))]
            if kind == "control":
                R = localization.make_away_same_sector(
                    core, base, target, rng, phase, a.control_max_tube
                )
            else:
                R = localization.make_near_same_sector(
                    core, base, target, rng, a.near_amplitude
                )

            times, traj = localization.integrate_for_periods(
                core, R, T, a.periods, a.ppp
            )
            m, _, _ = localization.trajectory_metrics(
                core, traj, times, phase, T, a.ppp
            )
            values[kind].append(m)
            ic_rows.append({
                "kind": kind,
                "sample": sample,
                "energy": float(core.energy_bloch(R)),
                "energy_error": float(abs(core.energy_bloch(R) - target)),
                "initial_max_tube_overlap":
                    localization.max_tube_overlap(core, R, phase),
            })
            print(
                f"E={energy_index} UPO={oid} {kind} {sample+1}/{count}",
                flush=True,
            )

    write_csv(out / "initial_conditions.csv", ic_rows)

    raw = []
    for kind in ("near", "control"):
        for sample, m in enumerate(values[kind]):
            raw.append({"kind": kind, "sample": sample, **m})
    write_csv(out / "trajectory_metrics.csv", raw)

    row = {
        "N": N_FIXED,
        "orbit": oid,
        "T": T,
        "target_energy": target,
    }
    specs = [
        ("tube_P_2_20", "greater", "ratio"),
        ("tube_P_16_20", "greater", "ratio"),
        ("return_peak_1_5", "greater", "ratio"),
        ("return_timing_1_5", "less", "difference"),
    ]
    for key, alternative, effect_kind in specs:
        result = localization.comparison(
            [x[key] for x in values["near"]],
            [x[key] for x in values["control"]],
            alternative,
            effect_kind,
            rng,
            a.bootstrap,
        )
        row.update({
            f"near_{key}": result["near_mean"],
            f"control_{key}": result["control_mean"],
            f"effect_{key}": result["effect"],
            f"effect_ci_low_{key}": result["effect_ci_low"],
            f"effect_ci_high_{key}": result["effect_ci_high"],
            f"p_{key}": result["p"],
            f"cliff_delta_{key}": result["cliff_delta"],
            f"auc_{key}": result["auc"],
        })

    write_csv(summary_path, [row])
    write_json(out / "DONE.json", {
        "status": "COMPLETE",
        "energy_index": energy_index,
        "orbit": oid,
    })
    return row


# ---------------------------------------------------------------------------
# One energy shell
# ---------------------------------------------------------------------------

def run_energy(args):
    core = load_module("section5_core", args.core)
    coll = load_module("section5_collective", args.collective)
    localization = load_module("section5_localization", args.localization)
    helpers = helper_adapter(localization)

    core.set_model(N_FIXED)
    install_adaptive_sampler(core, localization)
    install_enhanced_collective_equivalence(coll)
    grid = build_energy_grid(core)

    i = int(args.energy_index)
    if i < 0 or i >= len(grid):
        raise ValueError("--energy-index must be 0..4")

    g = grid[i]
    target = float(g["target_energy"])
    density = float(g["energy_density"])
    out = Path(args.output_root) / energy_label(i, density)
    ensure(out)

    if (out / "DONE.json").exists() and not args.force:
        print(f"Energy {i} already complete", flush=True)
        return 0

    write_json(out / "ENERGY_CONFIG.json", {
        **g,
        "schema": SCHEMA,
        "N": N_FIXED,
        "required_families": N_FAMILIES,
        "restricted_rho_min": RESTRICTED_RHO_MIN,
        "final_collective_equivalence": {
            "period_rel_tol": 1e-5,
            "S_rel_tol": 1e-5,
            "rms_tol": 5e-4,
            "max_tol": 3e-3,
            "required_resolutions": [1080, 2160],
        },
        "core_sha256": file_sha256(args.core),
        "collective_sha256": file_sha256(args.collective),
        "localization_sha256": file_sha256(args.localization),
    })

    rng = np.random.default_rng(int(args.seed) + i * 100003)
    seeds = []
    if g["is_reference"]:
        seeds = load_reference_reps(core, args.reference_orbits, target)
        print(
            f"Reference energy: loaded {len(seeds)} validated N=10 seeds",
            flush=True,
        )

    try:
        reps = custom_search(
            core, helpers, coll, target, out / "SEARCH", rng, args, seeds
        )
    except SearchBudgetReached:
        write_json(
            out / "NEEDS_RESUME.json",
            {
                "energy_index": i,
                "message": "Re-submit this same energy index; search is checkpointed.",
            },
        )
        return 75

    if len(reps) != 4:
        raise RuntimeError(f"Expected four final collective families, got {len(reps)}")

    # Final high-resolution audit before any expensive observables are computed.
    _, c1080, _ = coll.robust_classify(
        core, helpers, reps, out / "FINAL_INDEPENDENCE_AUDIT",
        prefix="FINAL_1080", points=1080,
    )
    _, c2160, _ = coll.robust_classify(
        core, helpers, reps, out / "FINAL_INDEPENDENCE_AUDIT",
        prefix="FINAL_2160", points=2160,
    )
    if (
        len(c1080) != 4 or len(c2160) != 4 or
        any(len(c) != 1 for c in c1080) or
        any(len(c) != 1 for c in c2160)
    ):
        raise RuntimeError(
            f"Final independence audit failed: 1080={c1080}, 2160={c2160}"
        )

    core.save_orbits(out / "SELECTED_4_COLLECTIVE_UPOS.csv", reps)

    rows = []
    for oid, orbit in enumerate(reps):
        print(
            f"\nENERGY {i} UPO {oid}/3: T={float(orbit['T']):.9f}",
            flush=True,
        )
        rf = coll.fixed_sector_floquet(core, helpers, orbit)
        if rf["restricted_rho"] <= RESTRICTED_RHO_MIN:
            raise RuntimeError("Final UPO lost fixed-sector hyperbolicity")

        udir = out / f"UPO{oid}"
        ensure(udir)
        ft = run_sector_ftle(
            core, localization, helpers, coll, orbit, target,
            udir, rng, nsamples=int(args.sector_ftle_samples),
        )
        locrow = analyze_energy_upo(
            core, localization, orbit, target, out, i, oid, args
        )

        row = {
            "energy_index": i,
            "xi_global": g["xi_global"],
            "energy_density": density,
            "target_energy": target,
            "orbit": oid,
            "T": float(orbit["T"]),
            "rho_full": float(orbit.get("rho", np.nan)),
            "restricted_rho": rf["restricted_rho"],
            "restricted_lambda": rf["restricted_lambda"],
            "restricted_lambda_over_omega":
                rf["restricted_lambda_over_omega"],
            **ft,
        }
        for key, value in locrow.items():
            if key not in {"N", "orbit", "T", "target_energy"}:
                row[key] = value
        rows.append(row)
        write_csv(out / "ENERGY_UPO_SUMMARIES.csv", rows)

    write_json(out / "DONE.json", {
        "status": "COMPLETE",
        "energy_index": i,
        "energy_density": density,
        "target_energy": target,
        "n_upos": 4,
        "collective_independence_1080": c1080,
        "collective_independence_2160": c2160,
    })
    stale = out / "NEEDS_RESUME.json"
    if stale.exists():
        stale.unlink()

    print("ENERGY JOB COMPLETE", flush=True)
    return 0


# ---------------------------------------------------------------------------
# Final 5 x 4 aggregation used by the manuscript
# ---------------------------------------------------------------------------

def aggregate(args):
    core = load_module("section5_aggregate_core", args.core)
    grid = build_energy_grid(core)
    root = Path(args.output_root)
    comp = root / "COMPARISON"
    ensure(comp)

    allrows = []
    levels = []

    for g in grid:
        i = int(g["energy_index"])
        ed = root / energy_label(i, float(g["energy_density"]))
        p = ed / "ENERGY_UPO_SUMMARIES.csv"
        if not p.exists():
            raise FileNotFoundError(
                f"Missing energy result {p}. Complete all five energy jobs first."
            )

        rows = read_csv(p)
        if len(rows) != 4:
            raise RuntimeError(f"Energy {i}: expected four UPO rows, found {len(rows)}")

        for row in rows:
            allrows.append(row)

        def vals(key):
            return np.array([as_float(r[key]) for r in rows], float)

        level = {
            "energy_index": i,
            "xi_global": float(g["xi_global"]),
            "energy_density": float(g["energy_density"]),
            "target_energy": float(g["target_energy"]),
            "n_upos": 4,
            "mean_sector_ftle_median":
                float(np.mean(vals("sector_ftle_median"))),
            "mean_restricted_lambda_over_omega":
                float(np.mean(vals("restricted_lambda_over_omega"))),
            "mean_effect_tube_P_2_20":
                float(np.mean(vals("effect_tube_P_2_20"))),
            "mean_effect_return_peak_1_5":
                float(np.mean(vals("effect_return_peak_1_5"))),
            "significant_tube_P_2_20":
                int(np.sum(vals("p_tube_P_2_20") < 0.05)),
            "significant_tube_P_16_20":
                int(np.sum(vals("p_tube_P_16_20") < 0.05)),
            "significant_return_peak_1_5":
                int(np.sum(vals("p_return_peak_1_5") < 0.05)),
            "significant_return_timing_1_5":
                int(np.sum(vals("p_return_timing_1_5") < 0.05)),
        }
        levels.append(level)

    if len(allrows) != 20:
        raise RuntimeError(f"Expected 20 final energy-scan UPO rows, got {len(allrows)}")

    write_csv(comp / "SECTION5_ORBIT_METRICS_20_UPOs.csv", allrows)
    write_csv(comp / "SECTION5_ENERGY_SUMMARY_5x4.csv", levels)

    report = [
        "SECTION 5 ENERGY-DEPENDENCE VALIDATION\n\n",
        "N=10; five energy densities; four independent collective UPO families per energy.\n",
        "Collective-family independence is checked with the final enhanced two-resolution criterion before metrics are evaluated.\n",
        "Statistical significance in the manuscript uses raw one-sided Mann-Whitney p<0.05.\n\n",
    ]
    for row in levels:
        report.append(
            f"E{row['energy_index']}: e={row['energy_density']:.12g}; "
            f"mean sector FTLE={row['mean_sector_ftle_median']:.12g}; "
            f"mean chi={row['mean_restricted_lambda_over_omega']:.12g}; "
            f"mean tube[2,20]={row['mean_effect_tube_P_2_20']:.12g}; "
            f"mean return[1,5]={row['mean_effect_return_peak_1_5']:.12g}; "
            f"timing significant={row['significant_return_timing_1_5']}/4\n"
        )
    (comp / "SECTION5_FINAL_REPORT.txt").write_text(
        "".join(report), encoding="utf-8"
    )

    # Reproduce the four-panel manuscript summary figure.
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        e = np.array([r["energy_density"] for r in levels], float)
        series = [
            ("mean_sector_ftle_median",
             r"$\langle\widetilde{\lambda}_{FT}^{(sec)}\rangle$"),
            ("mean_restricted_lambda_over_omega",
             r"$\langle\chi_{UPO}\rangle$"),
            ("mean_effect_tube_P_2_20",
             r"$\langle\mathcal{P}_{tube}^{[2,20]}\rangle$"),
            ("mean_effect_return_peak_1_5",
             r"$\langle\mathcal{P}_{F}^{1:5}\rangle$"),
        ]
        fig, axes = plt.subplots(2, 2, figsize=(8.0, 6.5))
        for ax, (key, ylabel) in zip(axes.ravel(), series):
            ax.plot(e, [float(r[key]) for r in levels], marker="o")
            ax.set_xlabel("Energy density e")
            ax.set_ylabel(ylabel)
        fig.tight_layout()
        fig.savefig(comp / "Fig_energy_dependence_4panel.pdf")
        plt.close(fig)
    except Exception as exc:
        print(f"WARNING: figure generation skipped: {exc}", flush=True)

    write_json(comp / "DONE.json", {
        "status": "COMPLETE",
        "n_energies": 5,
        "families_per_energy": 4,
        "n_total_families": 20,
    })

    print("SECTION 5 ENERGY AGGREGATION COMPLETE", flush=True)
    return 0


def validate_modules(args):
    core = load_module("section5_validation_core", args.core)
    coll = load_module("section5_validation_collective", args.collective)
    localization = load_module("section5_validation_localization", args.localization)
    helpers = helper_adapter(localization)
    install_enhanced_collective_equivalence(coll)
    core.set_model(N_FIXED)
    grid = build_energy_grid(core)

    required_core = [
        "classical_energy_bounds", "config_for_n", "validate_orbit",
        "_generate_epoch_candidates", "_refine_candidate_final", "save_orbits",
        "load_orbits", "phase_grid", "energy_bloch",
    ]
    required_coll = [
        "fixed_sector_floquet", "robust_collective_alignment",
        "robust_classify", "reorder_candidates_for_collective_novelty",
        "reduced_rhs6", "reduced_jacobian6",
    ]
    required_loc = [
        "central_on_energy", "compose_state",
        "sample_microcanonical_sector_state", "make_near_same_sector",
        "make_away_same_sector", "integrate_for_periods",
        "trajectory_metrics", "comparison", "max_tube_overlap",
    ]
    for mod, names, label in (
        (core, required_core, "core"),
        (coll, required_coll, "collective"),
        (localization, required_loc, "localization"),
    ):
        missing = [x for x in names if not hasattr(mod, x)]
        if missing:
            raise RuntimeError(f"{label} module missing required functions: {missing}")

    print("SECTION 5 MODULE VALIDATION PASS")
    for row in grid:
        print(
            f"E{row['energy_index']}: "
            f"e={row['energy_density']:.12f}, "
            f"xi={row['xi_global']:.12f}"
        )
    return 0


def main():
    ap = argparse.ArgumentParser(
        description="Section 5 energy-dependence calculation at N=10"
    )
    ap.add_argument(
        "--mode", choices=["energy", "aggregate", "validate"], required=True
    )
    ap.add_argument(
        "--core", required=True,
        help="Path to Section-3 3.1-3.2_CODE_FTLE_and_UPO_search.py",
    )
    ap.add_argument(
        "--collective", required=True,
        help="Path to Section-3 3.2-3.3_CODE_collective_UPO_completion_and_Floquet.py",
    )
    ap.add_argument(
        "--localization", required=True,
        help="Path to Section-4 4_CODE_UPO_localization_analysis.py",
    )
    ap.add_argument("--output-root", default="SECTION5_RESULTS")
    ap.add_argument(
        "--reference-orbits", default=None,
        help="Final N=10 collective representatives produced by Section 3",
    )
    ap.add_argument("--energy-index", type=int, default=None)
    ap.add_argument("--seed", type=int, default=408731)
    ap.add_argument("--search-budget-hours", type=float, default=112.0)
    ap.add_argument("--sector-ftle-samples", type=int, default=8)
    ap.add_argument("--near", type=int, default=24)
    ap.add_argument("--controls", type=int, default=48)
    ap.add_argument("--ppp", type=int, default=60)
    ap.add_argument("--phase-points", type=int, default=360)
    ap.add_argument("--control-max-tube", type=float, default=0.20)
    ap.add_argument("--bootstrap", type=int, default=2000)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    if args.mode == "validate":
        return validate_modules(args)
    if args.mode == "energy":
        if args.energy_index is None:
            raise ValueError("--energy-index is required in energy mode")
        if args.energy_index == 2 and not args.reference_orbits:
            raise ValueError(
                "Reference-energy job E2 requires --reference-orbits from Section 3"
            )
        return run_energy(args)
    return aggregate(args)


if __name__ == "__main__":
    sys.exit(main())
