WHY ONLY ONE NEW PYTHON CODE IS REQUIRED FOR SECTION 5

Section 5 does not introduce a new dynamical model or new localization
observable. It changes one control parameter: the energy density, while
keeping N=10 fixed.

The numerical ingredients needed by the energy scan have already been
defined and validated in the preceding Supplementary sections:

- Section 3 provides the nonlinear dynamics, recurrence search, UPO
  refinement, collective-family equivalence and fixed-sector Floquet analysis.

- Section 4 provides the invariant-sector near-UPO/reference construction,
  tube localization, return fidelity, recurrence timing and Mann-Whitney
  statistical comparisons.

The Section-5 code therefore contains only the new energy-scan logic:
- construction of the five energy shells;
- efficient exact-energy sampling across the wider energy range;
- search for four independent collective UPO families at each energy;
- fixed-sector FTLE around each selected UPO sector;
- application of the Section-4 observables at each energy;
- aggregation of the five energies into the final 5 x 4 dataset and
  four-panel energy-dependence figure.

WHY THE HISTORICAL DUPLICATE-CORRECTION SCRIPT IS NOT INCLUDED

During development, the initial highest-energy catalogue contained two
numerically split representations of the same collective periodic orbit.
The script fix_N10_energy_E4_duplicate.py was then used to detect this,
remove one representative, search for a replacement, and rebuild the final
dataset.

That history is retained in the source provenance, but it is not an
appropriate execution path for published Supplementary Code.

The clean Section-5 implementation instead incorporates the final enhanced
collective-equivalence criterion before an orbit is accepted. The highest
energy is therefore treated in exactly the same workflow as the other four
energies, with the stricter final independence audit applied from the start.

Consequently, the published workflow is:

five energy shells
    -> UPO search/refinement
    -> final collective-independence test
    -> four independent families per energy
    -> fixed-sector FTLE and Floquet
    -> Section-4 localization metrics
    -> final 5 x 4 energy summary

rather than:

energy scan
    -> catalogue containing a duplicate
    -> separate correction script
    -> replacement UPO
    -> rebuilt results

The single Section-5 script therefore represents the final scientific
procedure directly, while the original source hashes preserve traceability
to the production calculations.
